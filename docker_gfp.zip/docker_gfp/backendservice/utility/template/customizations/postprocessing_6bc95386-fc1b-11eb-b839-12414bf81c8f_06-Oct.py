import re
import copy
from dateutil import parser
from datetime import date
months = ['JAN', "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]

'''
import json
mapping_file = "/home/akshatha/standard_demo_forms/generic_form_parser_configs/SJN_without_post.json"
with open(mapping_file) as json_file:
    pvi_json = json.load(json_file)
ws1 = "/home/akshatha/standard_demo_forms/generic_form_parser_configs/ws1.json"
with open(ws1) as ws1_file:
    extracted_json = json.load(ws1_file)
'''

# Function to change all the values to none in any dictionary or List
def change_reference_values_to_none(pvi_json):
    for key, value in pvi_json.items():
        if isinstance(value, dict):
            change_reference_values_to_none(value)
        elif isinstance(value, list):
            for val in value:
                change_reference_values_to_none(val)
        else:
            pvi_json.update({key: None})
    return pvi_json


# Function to process date in DD-MMM-YYYY Format (supported by application)
def process_date(any_date):
    if any_date not in [None, '']:
        if len(any_date.split()) == 3:
            date_day, date_month, date_year = any_date.split()
            if date_month.lower() == 'unk':
                any_date = date_year
            elif date_day.lower() == 'un':
                any_date = date_month + '-' + date_year
            elif len(date_day) == 1:
                date_day = '0' + date_day
                any_date = date_day + '-' + date_month + '-' + date_year
            else:
                any_date = date_day + '-' + date_month + '-' + date_year
        elif len(any_date.split()) == 2:
            date_month, date_year = any_date.split()
            if date_month.lower() == 'unk':
                any_date = date_year
            else:
                any_date = date_month + '-' + date_year
        else:
            any_date = any_date.strip()
    return any_date


def get_concom_final_data_list(extracted_json):
    try:
        data = [x['value'] for x in extracted_json if x['AnnotID'] == '10096'][0]
        new_data = []
        if data:
            for each in data:
                if len(each) >= 17:
                    new_data.append(each)
        if new_data:
            for each in new_data:
                if len(each) > 17 and each[0] in [None, '']:
                    each.pop(0)
        data_list = []
        for each in new_data:
            if len(each) >= 17 and str(each[0]).isdigit():
                data_list.append(each)
    except:
        data_list = []
    return data_list


# Function to filter out concomitant products based on date difference with ae onset date
def process_concomitant_products_filtering(pvi_json, extracted_json):
    final_concom_data = get_concom_final_data_list(extracted_json)
    concom_prod_to_be_included_list = []
    event_onset_date = pvi_json['events'][0]['startDate']
    if final_concom_data:
        for each in final_concom_data:
            start_date = process_date(each[13].replace('\n', ' ').replace('-', ''))
            end_date = process_date(each[15].replace('\n', ' ').replace('-', ''))
            compare_date_result = compare_dates(event_onset_date, start_date, end_date)
            if compare_date_result:
                concom_prod_to_be_included_list.append(each)
    if concom_prod_to_be_included_list:
        for each_data in concom_prod_to_be_included_list:
            pvi_json = process_concomitant_data(pvi_json, each_data)
    prod_seq_num = 1
    for prod in pvi_json['products']:
        prod['seq_num'] = prod_seq_num
        prod_seq_num += 1
    return pvi_json


def process_concomitant_data(pvi_json, each_data):
    prod_block = change_reference_values_to_none(copy.deepcopy(pvi_json['products'][0]))
    prod_ind_block = change_reference_values_to_none(copy.deepcopy(pvi_json['products'][0]['indications'][0]))
    prod_block['role_value'] = 'concomitant'
    prod_block['license_value'] = each_data[1].replace('\n', ' ')
    if each_data[4] not in [None, '', '-']:
        prod_block['indications'][0]['reportedReaction'] = process_indication_value(each_data[4])
    if each_data[5] not in [None, '', '-']:
        if prod_block['indications'][0]['reportedReaction'] not in [None, '']:
            prod_block['indications'].append(prod_ind_block)
            prod_block['indications'][1]['reportedReaction'] = process_indication_value(each_data[5])
        else:
            prod_block['indications'][0]['reportedReaction'] = process_indication_value(each_data[5])
    if each_data[4] in [None, '', '-'] and each_data[5] in [None, '', '-']:
        if each_data[2] not in [None, '', '-']:
            prod_block['indications'][0]['reportedReaction'] = process_indication_value(each_data[2])
    prod_block['doseInformations'][0] = process_dose_informations(prod_block['doseInformations'][0], each_data)
    pvi_json['products'].append(prod_block)
    return pvi_json


# Function to process dose Information for all the concomitant products
def process_dose_informations(prod_dose_block, each_data):
    if each_data[6] not in [None, '', '-']:
        prod_dose_block['dose_inputValue'] = each_data[6].replace('\n', ' ')
    if each_data[7].replace('\n', '').lower == 'other':
        prod_dose_block['dose_inputValue'] = prod_dose_block['dose_inputValue'] + ' ' + each_data[8].replace('\n', ' ')
    else:
        prod_dose_block['dose_inputValue'] = prod_dose_block['dose_inputValue'] + ' ' + each_data[7].replace('\n', ' ')
    if prod_dose_block['dose_inputValue']:
        prod_dose_block['description'] = 'Dose: ' + prod_dose_block['dose_inputValue']
    if each_data[9].lower() == 'other':
        prod_dose_block['frequency_value'] = each_data[10].replace('\n', ' ')
    else:
        prod_dose_block['frequency_value'] = each_data[9].replace('\n', ' ')
    if prod_dose_block['frequency_value']:
        if prod_dose_block['description']:
            prod_dose_block['description'] = prod_dose_block['description'] + ', Frequency: ' + prod_dose_block['frequency_value']
        else:
            prod_dose_block['description'] = 'Frequency: ' + prod_dose_block['frequency_value']
    if each_data[11].lower() == 'other':
        prod_dose_block['route_value'] = each_data[12].replace('\n', '')
    else:
        prod_dose_block['route_value'] = each_data[11].replace('\n', '')
    prod_dose_block['startDate'] = process_date(each_data[13].replace('\n', ' ').replace('-', ''))
    prod_dose_block['endDate'] = process_date(each_data[15].replace('\n', ' ').replace('-', ''))
    return prod_dose_block


# Function to format product indication value
def process_indication_value(indication):
    if indication not in [None, '']:
        indication = indication.replace('\n', ' ')
        if '_' in indication:
            if len(indication.split('_')) == 3:
                indication = indication.split('_')[1]
            elif len(indication.split('_')) == 2:
                if re.match('^\d', indication.split('_')[0]):
                    indication = indication.split('_')[1]
                else:
                    indication = indication.split('_')[0]
    return indication


def compare_dates(event_date, start_date, end_date):
    result = True
    if event_date not in [None, '']:
        if len(event_date.split('-')) != 3:
            result = True
        else:
            event_date_day, event_date_month, event_date_year = event_date.split('-')
            event_check_date = date(int(event_date_year), months.index(event_date_month)+1, int(event_date_day))
            result = date_difference_start(start_date, event_check_date)
            if result == 'Not Include':
                result = False
            elif result == 'Check End':
                result = date_difference_end(end_date, event_check_date)
            elif result == 'Include':
                result = True
    return result


def date_difference_start(start_date, compare_date):
    if start_date not in [None, '']:
        result = 'Include'
        if len(start_date.split('-')) == 3:
            start_date_day, start_date_month, start_date_year = start_date.split('-')
            start_check_date = date(int(start_date_year), months.index(start_date_month) + 1, int(start_date_day))
            if start_check_date >= compare_date:
                result = 'Not Include'
            else:
                delta = abs(compare_date - start_check_date)
                if 'day' in str(delta):
                    if int(str(delta).split()[0]) <= 30:
                        result = 'Include'
                    else:
                        result = 'Check End'
        elif len(start_date.split('-')) == 2:
            com_month = compare_date.month
            start_month = months.index(start_date.split('-')[0]) + 1
            if int(start_date.split('-')[-1])-compare_date.year >= 1:
                result = 'Not Include'
            elif int(start_date.split('-')[-1]) == compare_date.year:
                if start_month > com_month:
                    result = 'Not Include'
                elif start_month == com_month:
                    if compare_date.day == 1:
                        result = 'Not Include'
                    else:
                        result = 'Include'
                elif com_month-start_month == 1:
                    result = 'Include'
                else:
                    result = 'Check End'
            elif int(start_date.split('-')[-1])-compare_date.year == -1:
                if com_month == 1 and start_month == 12:
                    result = 'Include'
                else:
                    result = 'Check End'
            else:
                result = 'Check End'
        elif len(start_date.split('-')) == 1:
            if int(start_date.split('-')[-1])-compare_date.year >= 1:
                result = 'Not Include'
            elif int(start_date.split('-')[-1]) == compare_date.year:
                if compare_date.month == 1 and compare_date.day == 1:
                    result = 'Not Include'
                else:
                    result = 'Include'
            else:
                result = 'Check End'
    else:
        result = 'Check End'
    return result


def date_difference_end(end_date, compare_date):
    if end_date not in [None, '']:
        result = True
        if len(end_date.split('-')) == 3:
            end_date_day, end_date_month, end_date_year = end_date.split('-')
            end_check_date = date(int(end_date_year), months.index(end_date_month) + 1, int(end_date_day))
            delta = abs(compare_date - end_check_date)
            if 'day' in str(delta):
                if int(str(delta).split()[0]) > 30:
                    result = False
            elif str(delta) == '0:00:00':
                result = True
        elif len(end_date.split('-')) == 2:
            com_month = compare_date.month
            end_month = months.index(end_date.split('-')[0]) + 1
            if int(end_date.split('-')[-1])-compare_date.year > 1:
                result = False
            elif int(end_date.split('-')[-1])-compare_date.year == 1:
                if com_month == 12 and end_month == 1:
                    result = True
                else:
                    result = False
            elif int(end_date.split('-')[-1]) == compare_date.year:
                if com_month == end_month:
                    result = True
                elif abs(end_month-com_month) == 1:
                    result = True
                else:
                    result = False
            elif int(end_date.split('-')[-1])-compare_date.year == -1:
                if com_month == 1 and end_month == 12:
                    result = True
                else:
                    result = False
            else:
                result = False
        elif len(end_date.split('-')) == 1:
            if int(end_date.split('-')[0]) == compare_date.year:
                result = True
            elif int(end_date.split('-')[0])-compare_date.year == 1:
                if compare_date.month == 12:
                    result = True
                else:
                    result = False
            elif compare_date.year-int(end_date.split('-')[0]) == 1:
                if compare_date.month == 1:
                    result = True
                else:
                    result = False
            else:
                result = False
    else:
        result = True
    return result


def process_junk_fields(pvi_json):
    pvi_json['patient']['patientId_acc'] = None
    pvi_json['patient']['age']['inputValue_acc'] = None
    pvi_json['patient']['name'] = pvi_json['patient']['name_acc'] = pvi_json['patient']['race'] = None
    return pvi_json


def populate_sus_product(pvi_json, extracted_json):
    pvi_json['products'][0]['license_value'] = 'Odronextemab'
    pvi_json['products'][0]['role_value'] = 'suspect'
    pvi_json['products'][0]['indications'][0]['reportedReaction'] = 'B-cell Lymphoma'
    try:
        data = [x['value'] for x in extracted_json if x['AnnotID'] == '10098'][0]
        prod_data = sus_prod_filter_data(data)
        print(data)
        print(prod_data)
    except:
        prod_data = []
    dose_info_list = []
    empty_dose = copy.deepcopy(pvi_json['products'][0]['doseInformations'][0])
    for each_dose_info in prod_data:
        dose = copy.deepcopy(empty_dose)
        if len(each_dose_info) >= 10:
            dose['dose_inputValue'] = each_dose_info[5].replace('MG', '').strip() + ' milligram'
            start_date = each_dose_info[8].replace('\n', '').replace(' ', '')
            start_date = start_date[0:2] + ' ' + start_date[2:5] + ' ' + start_date[5:]
            dose['startDate'] = process_date(start_date)
            dose_info_list.append(dose)
    if dose_info_list:
        #for every_doseinfo in dose_info_list:
        #dose_info_list.sort(key=lambda every_doseinfo: date(every_doseinfo["startDate"].split('-')[0], months.index(every_doseinfo["startDate"].split('-')[1])+1, every_doseinfo["startDate"].split('-')[2]))
        pvi_json['products'][0]['doseInformations'] = dose_info_list
    return pvi_json


def sus_prod_filter_data(data):
    new_data = []
    date_list = []
    data_list = []
    date_min_index = 0
    for each in data:
        if each[0] in [None, '']:
            each.pop(0)
    for each in data:
        if len(each) >= 10 and each[1] == 'Yes':
            new_data.append(each)
    final_dose_list = []
    if new_data:
        for each in new_data:
            if each[5]:
                each[5] = each[5].replace('\n', '').replace('MG', '').strip()
            if each[8]:
                each[8] = each[8].replace('\n', '').strip()
                date_old = each[8]
                if len(date_old) == 9:
                    each[8] = date_old[0:2] + " " + date_old[2:5] + " " +  date_old[5:9]
                elif len(date_old) == 7:
                    each[8] = date_old[0:3] +" " + date_old[3:7]
                elif len(date_old) == 4:
                    each[8] = date_old[0:4]
        dose_list = [each[5] for each in new_data]
        unique_dose = set(dose_list)
        dose_dict  = {}
        for dose in unique_dose:
            dose_dict[dose] = []
        for every_dose in new_data:
            dose_dict[every_dose[5]].append(every_dose)
        for key, val in dose_dict.items():
            date_list = [each[8] for each in val]
            if date_list:
                date_initial = date(9999, 12, 31)
                print(date_list)
                for each in date_list:
                    if len(each.split()) == 3 and date(int(each.split()[2]), months.index(each.split()[1]) + 1, int(each.split()[0])) < date_initial:
                        date_initial = date(int(each.split()[2]), months.index(each.split()[1]) + 1, int(each.split()[0]))
                        date_min_index = date_list.index(each)
            final_dose_list.append(val[date_min_index])
    return final_dose_list


def process_medical_history(pvi_json):
    med_block = change_reference_values_to_none(copy.deepcopy(pvi_json['patient']['medicalHistories'][0]))
    med_his = []
    for med in pvi_json['patient']['medicalHistories']:
        if med['reportedReaction'] not in [None, '']:
            med['reportedReaction'] = med['reportedReaction'].replace('\n', ' ')
            med['startDate'] = process_date(med['startDate'].replace('\n', ' ').replace('-', ''))
            med['endDate'] = process_date(med['endDate'].replace('\n', ' ').replace('-', ''))
            if med['historyNote'] not in [None, '', '-']:
                med['historyNote'] = med['historyNote'].replace('\n', ' ')
                med['historyNote'] = 'CTCAE Grade : ' + med['historyNote']
            else:
                med['historyNote'] = None
            if med['continuing'] == 'Ongoing':
                med['continuing'] = 'Yes'
            elif med['continuing'] == 'Resolved':
                med['continuing'] = 'No'
            else:
                med['continuing'] = None
            med['reactionCoded'] = med['historyConditionType'] = med['familyHistory'] = None
            med_his.append(med)
    if len(med_his) > 0:
        pvi_json['patient']['medicalHistories'] = med_his
    else:
        pvi_json['patient']['medicalHistories'] = [med_block]
    return pvi_json


def process_ae_data(pvi_json, extracted_json):
    try:
        data = [x['value'] for x in extracted_json if x['AnnotID'] == '10097'][0]
        event_data = data[-1]
    except:
        event_data = []
    if event_data and len(event_data) >= 10:
        event_seq_num = 1
        for event in pvi_json['events']:
            event['seq_num'] = event_seq_num
            event['reportedReaction'] = event_data[1].replace('\n', ' ')
            event['startDate'] = process_date(event_data[2].replace('\n', ' '))
            event['endDate'] = process_date(event_data[9].replace('\n', ' '))
            event['outcome'] = event_data[7].replace('\n', '')
            if event['outcome'] and event['outcome'].lower() == 'not recovered/not resolved':
                event['outcome'] = 'Not Recovered / Not Resolved'
            if event['outcome'] and event['outcome'].lower() == 'recovering/resolving':
                event['outcome'] = 'Recovering / Resolving'
            event_seq_num += 1
    return pvi_json


# Function to process Patient ID called from Main function
def process_patient_id_sender_case_uid(pvi_json):
    if pvi_json['patient']['patientId'] not in [None, ''] and len(pvi_json['patient']['patientId']) > 4:
        pvi_json['patient']['patientId'] = pvi_json['patient']['patientId'][0:-3] + "-" + pvi_json['patient']['patientId'][-3:]
    pvi_json['senderCaseUid'] = pvi_json['patient']['patientId']
    return pvi_json


def convert_mg_to_milligram(pvi_json):
    for prod in pvi_json['products']:
        for dose in prod['doseInformations']:
            if dose['dose_inputValue'] and ' mg' in dose['dose_inputValue']:
                dose['dose_inputValue'] = dose['dose_inputValue'].replace(' mg', ' milligram')
            if dose['description'] and ' mg' in dose['description']:
                dose['description'] = dose['description'].replace(' mg', ' milligram')
            if dose['dose_inputValue']:
                start_index = dose['dose_inputValue'].find(' g')
                if start_index != -1:
                    if len(dose['dose_inputValue']) <= start_index+2:
                        dose['dose_inputValue'] = dose['dose_inputValue'].replace(' g', ' gram')
                        if dose['description']:
                            dose['description'] = dose['description'].replace(' g', ' gram')
                    elif not dose['dose_inputValue'][start_index+2].isalpha():
                        dose['dose_inputValue'] = dose['dose_inputValue'].replace(' g', ' gram')
                        if dose['description']:
                            dose['description'] = dose['description'].replace(' g', ' gram')
            if dose['dose_inputValue']:
                if ' ml' in dose['dose_inputValue']:
                    dose['dose_inputValue'] = dose['dose_inputValue'].replace(' ml', ' millilitre')
                elif 'mL' in dose['dose_inputValue']:
                    dose['dose_inputValue'] = dose['dose_inputValue'].replace('mL', 'millilitre')
            if dose['description']:
                if ' ml' in dose['description']:
                    dose['description'] = dose['description'].replace(' ml', ' millilitre')
                elif 'mL' in dose['description']:
                    dose['description'] = dose['description'].replace('mL', 'millilitre')
    return pvi_json


# Function to get AE dict from extracted json
def get_ae_dict(extracted_json, annot):
    try:
        data = [x['value'] for x in extracted_json if x['AnnotID'] == annot][0]
        ae_dict = {}
        if data:
            for each in data:
                if len(each) == 2:
                    ae_dict[each[0]] = each[1]
                else:
                    if None in each:
                        each.remove(None)
                    if len(each) >= 2:
                        ae_dict[each[0]] = each[1]
    except:
        ae_dict = {}
    return ae_dict


def process_additional_ae_data(pvi_json, extracted_json):
    ae_dict = get_ae_dict(extracted_json, '10116')
    if ae_dict != {}:
        pvi_json['events'][0]['eventCategory'] = [{'value': ae_dict['AE most extreme severity grade']}]
        action_taken = ae_dict['Action taken with REGN1979']
        if action_taken not in [None, '', 'NOT APPLICABLE', 'NOT CHECKED', 'Not Applicable']:
            if action_taken.lower() == 'dosage maintained':
                action_taken = 'Dose Not Changed'
            if action_taken.lower() in ['drug discontinued (temp)', 'dose delayed', 'dose interrupted', 'drug interrupted']:
                action_taken = 'Dose Temporarily withdrawn'
            if action_taken.lower() == 'study treatment withdrawn':
                action_taken = 'Drug Withdrawn'
            pvi_json['products'][0]['actionTaken']['value'] = action_taken
    return pvi_json


def process_seriousness_criteria(pvi_json, extracted_json):
    seriousness_dict = get_ae_dict(extracted_json, '10114')
    if seriousness_dict != {}:
        es_list = get_event_seriousness_list(seriousness_dict)
        if len(es_list) > 0:
            es_block = change_reference_values_to_none(copy.deepcopy(pvi_json['events'][0]['seriousnesses'][0]))
            pvi_json['events'][0]['seriousnesses'] = []
            for each in es_list:
                es_block['value'] = each
                pvi_json['events'][0]['seriousnesses'].append(es_block)
    return pvi_json


def get_event_seriousness_list(ae_dict):
    es_list = []
    if ae_dict['It resulted in death'].lower() == 'yes':
        es_list.append('Death')
    if ae_dict['It was life-threatening'].lower() == 'yes':
        es_list.append('Life Threatening')
    if ae_dict['It required or prolonged inpatient hospitalization'].lower() == 'yes':
        es_list.append('Hospitalization')
    if ae_dict['It is a congenital anomaly/birth defect in offspring of\nstudy subject'].lower() == 'yes':
        es_list.append('Congenital Anomaly')
    if ae_dict['Persistent or significant disability / incapacity'].lower() == 'yes':
        es_list.append('Disability')
    if ae_dict['Other medically serious important event'].lower() == 'yes':
        es_list.append('Other Medically Important Condition')
    return es_list


def process_serious_event_aesi_table(pvi_json, extracted_json):
    ae_dict = get_ae_dict(extracted_json, '10115')
    if ae_dict != {}:
        event_date = pvi_json['events'][0]['startDate']
        if len(event_date.split('-')) == 3:
            event_date = date(int(event_date.split('-')[2]), months.index(event_date.split('-')[1])+1, int(event_date.split('-')[0]))
            new_date = process_date(ae_dict['Date event became serious (dd-mon-yyyy)'])
            if len(new_date.split('-')) == 3:
                new_date = date(int(new_date.split('-')[2]), months.index(new_date.split('-')[1])+1, int(new_date.split('-')[0]))
                if new_date > event_date:
                    pvi_json['events'][0]['startDate'] = process_date(ae_dict['Date event became serious (dd-mon-yyyy)'])
        pvi_json['summary']['caseDescription'] = ae_dict['SAE/AESI NARRATIVE'].replace('\n', ' ')
    return pvi_json


def process_aesi_continuation_table(pvi_json, extracted_json):
    ae_dict = get_ae_dict(extracted_json, '10101')
    if ae_dict != {}:
        for index in range(10):
            key = 'Event Description ' + str(index+1)
            if ae_dict[key] not in [None, '', '-']:
                if pvi_json['summary']['caseDescription']:
                    pvi_json['summary']['caseDescription'] = pvi_json['summary']['caseDescription'] + ' ' + ae_dict[key]
                else:
                    pvi_json['summary']['caseDescription'] = ae_dict[key].replace('\n', ' ')
    if pvi_json['summary']['caseDescription']:
        pvi_json['summary']['caseDescription'] = "SAE/AESI NARRATIVE : " + pvi_json['summary']['caseDescription']
    return pvi_json


def process_treatment_for_ae_details_section(pvi_json, extracted_json):
    ae_dict = get_ae_dict(extracted_json, '10113')
    if ae_dict != {}:
        for index in range(5):
            key = 'Concomitant procedure/surgery #' + str(index+1)
            if ae_dict[key] not in [None, '', '-']:
                med_his = change_reference_values_to_none(copy.deepcopy(pvi_json['patient']['medicalHistories'][0]))
                med_his['reportedReaction'] = process_indication_value(ae_dict[key])
                pvi_json['patient']['medicalHistories'].append(med_his)
        if ae_dict['If Other, specify'] not in [None, '', '-']:
            med_his = change_reference_values_to_none(copy.deepcopy(pvi_json['patient']['medicalHistories'][0]))
            med_his['reportedReaction'] = process_indication_value(ae_dict['If Other, specify'])
            pvi_json['patient']['medicalHistories'].append(med_his)
    return pvi_json


def populate_pe_matrix(pvi_json, extracted_json):
    pvi_json['productEventMatrix'][0] = change_reference_values_to_none(pvi_json['productEventMatrix'][0])
    check_dict = {'Yes': 'Related', 'No': 'Not Related', '': 'Not Reported', '-': 'Not Reported', 'Unknown': 'Unknown'}
    try:
        data = [x['value'] for x in extracted_json if x['AnnotID'] == '10097'][0]
        event_data = data[-1]
    except:
        event_data = []
    if event_data and len(event_data) >= 10:
        if event_data[4].replace('\n', ' ') in ['Yes', 'No', 'Unknown', '', '-']:
            pvi_json['productEventMatrix'][0]['product_seq_num'] = 1
            pvi_json['productEventMatrix'][0]['event_seq_num'] = 1
            pvi_json['productEventMatrix'][0]['relatednessAssessments'][0]['result']['value'] = check_dict[event_data[4].replace('\n', ' ')]
        if event_data[5].replace('\n', ' ') in ['Yes', 'No', 'Unknown', '', '-']:
            second_value = check_dict[event_data[5].replace('\n', ' ')]
            pvi_json['productEventMatrix'][0]['relatednessAssessments'].append({'result': {'value': second_value, 'value_acc': None}})
    return pvi_json


def process_death_details(pvi_json, extracted_json):
    try:
        data = [x['value'] for x in extracted_json if x['AnnotID'] == '10100'][0]
        death_data = data[0]
    except:
        death_data = []
    if death_data:
        pvi_json['deathDetail']['deathDate']['date'] = process_date(death_data[0])
        pvi_json['deathDetail']['deathCauses']['reportedReaction'] = death_data[1].replace('\n', ' ')
    return pvi_json

def process_empty_dose(pvi_json):
    for product in pvi_json['products']:
        for dose in product['doseInformations'][:]:
            if dose['dose_inputValue'] == None and dose['startDate'] == None:
                product['doseInformations'].remove(dose)
    return pvi_json
    
    
# Main function to call all the other functions
def get_postprocessed_json(pvi_json, extracted_json):
    pvi_json = process_junk_fields(pvi_json)
    try:
        pvi_json = populate_sus_product(pvi_json, extracted_json)
    except:
        print('Error in populating suspect product')
    try:
        pvi_json = process_ae_data(pvi_json, extracted_json)
    except:
        print('Error in processing AE data')
    try:
        pvi_json = process_serious_event_aesi_table(pvi_json, extracted_json)
    except:
        print('Error in serious event AESI table')
    try:
        pvi_json = process_aesi_continuation_table(pvi_json, extracted_json)
    except:
        print('Error in processing AESI continuation table')
    try:
        pvi_json = process_medical_history(pvi_json)
    except:
        print('Error in processing medical History')
    try:
        pvi_json = process_treatment_for_ae_details_section(pvi_json, extracted_json)
    except:
        print('Error in processing Treatment for AE details')
    try:
        pvi_json = process_concomitant_products_filtering(pvi_json, extracted_json)
    except:
        print('Error in processing concomitant products filtering')
    try:
        pvi_json = process_additional_ae_data(pvi_json, extracted_json)
    except:
        print('Error in processing Additional Ae details table')
    try:
        pvi_json = process_seriousness_criteria(pvi_json, extracted_json)
    except:
        print('Error in processing Seriousness criteria')
    pvi_json = process_patient_id_sender_case_uid(pvi_json)
    pvi_json = convert_mg_to_milligram(pvi_json)
    try:
        pvi_json = populate_pe_matrix(pvi_json, extracted_json)
    except:
        print('Error in populating PE matrix')
    try:
        pvi_json = process_death_details(pvi_json, extracted_json)
    except:
        print('Error in processing death details')
    try:
        pvi_json = process_empty_dose(pvi_json)
    except:
        print('Error in removing empty dose')
    return pvi_json


