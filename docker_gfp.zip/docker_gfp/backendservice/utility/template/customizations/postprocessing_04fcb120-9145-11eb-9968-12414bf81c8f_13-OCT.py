import re
import copy
from postal.parser import parse_address
from copy import deepcopy


# Change all the copied reference block from PVI JSON values to None
def change_reference_values_to_none(pvi_json):
    for key, value in pvi_json.items():
        if isinstance(value, dict):
            change_reference_values_to_none(value)
        elif isinstance(value, list):
            for val in value:
                change_reference_values_to_none(val)
        else:
            pvi_json.update({key: None})
    return pvi_json


# Processing patient Height and Weight
def patient_name_height_weight_process(pvi_json):
    weight = re.findall(re.compile("\d+.*\s*[kKgG]"), pvi_json['patient']['name'])
    height = re.findall(re.compile("\d+.*\s*[cCmM]"), pvi_json['patient']['name'])
    if len(weight) > 0:
        pvi_json['patient']['name'] = pvi_json['patient']['name'].replace(weight[0], '')
        pvi_json['patient']['weight'] = weight[0].split()[0]
        pvi_json['patient']['weightUnit'] = weight[0].split()[1]
    if len(height) > 0:
        pvi_json['patient']['name'] = pvi_json['patient']['name'].replace(height[0], '')
        pvi_json['patient']['height'] = height[0].split()[0]
        pvi_json['patient']['heightUnit'] = height[0].split()[1]
    pvi_json['patient']['name'] = pvi_json['patient']['name'].strip()
    pvi_json['patient']['name'] = pvi_json['patient']['name'].replace('\n', '')
    return pvi_json


# Processing patient Initials
def process_patient_initials(pvi_json):
    pvi_json['patient']['name'] = pvi_json['patient']['name'].strip()
    if pvi_json['patient']['name'] not in [None, '']:
        pvi_json['patient']['name'] = pvi_json['patient']['name'].replace('-', '')
        pvi_json['patient']['name'].strip()
        if 'privacy' in pvi_json['patient']['name'].lower():
            pvi_json['patient']['name'] = None
        elif 'unknown' in pvi_json['patient']['name'].lower():
            pvi_json['patient']['name'] = 'UNKNOWN'
        elif pvi_json['patient']['name'].isdigit():
            pvi_json['patient']['name'] = None
        else:
            pvi_json = patient_name_height_weight_process(pvi_json)
    elif pvi_json['patient']['age']['inputValue'] in [None, ''] and pvi_json['patient']['gender'] in [None, '']:
        pvi_json['patient']['name'] = 'UNKNOWN'
    return pvi_json


# Processing Patient Age
def process_patient_age(pvi_json):
    pvi_json['patient']['age']['inputValue'] = pvi_json['patient']['age']['inputValue'].strip()
    pvi_json['patient']['race'] = pvi_json['patient']['race'].replace('\n', '').replace(' ', '').replace('?', '')
    if pvi_json['patient']['age']['inputValue'] not in [None, '']:
        pvi_json['patient']['age']['inputValue'] = pvi_json['patient']['age']['inputValue'] + ' Years'
        pvi_json['patient']['age']['ageType'] = 'PATIENT_ON_SET_AGE'
    elif pvi_json['patient']['race'] not in [None, '', '--']:
        pvi_json['patient']['age']['inputValue'] = pvi_json['patient']['race']
        pvi_json['patient']['ageType'] = 'PATIENT_BIRTH_DATE'
    else:
        pvi_json['patient']['age']['inputValue'] = ''
    pvi_json['patient']['race'] = None
    return pvi_json


# Processing Fixed Describe Reaction on the First page of the form
def process_first_page_describe_reaction(pvi_json, extracted_json):
    data = [x['value'] for x in extracted_json if x['AnnotID'] == '10011'][0]
    flag = False
    word_list = ['case', 'report', 'clinical', 'trial', 'study', 'reports']
    if data:
        for index, data_item in enumerate(data):
            if any(item in data_item.lower() for item in word_list):
                pvi_json['summary']['caseDescription'] = pvi_json['summary']['caseDescription'] + '\n' + ' '.join(data[index:])
                flag = True
                break
    return pvi_json, flag


# Processing continued described reaction on additional pages
def process_second_page_describe_reaction(pvi_json, extracted_json, flag):
    data = [x['value'] for x in extracted_json if x['AnnotID'] == '10026'][0]
    word_list = ['case', 'report', 'clinical', 'trial', 'study', 'reports']
    if flag:
        pvi_json['summary']['caseDescription'] = pvi_json['summary']['caseDescription'] + ' '.join(data)
    else:
        if data:
            for index, data_item in enumerate(data):
                if any(item in data_item.lower() for item in word_list):
                    pvi_json['summary']['caseDescription'] = pvi_json['summary']['caseDescription'] + '\n' + ' '.join(data[index:])
                    break
    return pvi_json


# Check all the available element in any block of one product
def check_total_elements_for_product(sample):
    element_dict = {'seq': 0, 'drug': 1}
    for i in range(len(sample)):
        if 'daily dose' in sample[i].lower():
            element_dict['dose'] = i
        if 'route of admin' in sample[i].lower():
            element_dict['route'] = i
        if 'indication for use' in sample[i].lower():
            element_dict['indication'] = i
        if 'therapy dates/duration' in sample[i].lower():
            element_dict['therapy'] = i
    return element_dict


# Get total number of products available in additional page section
def get_list_of_list_for_extracted_data(sample):
    temp = [index for index in range(len(sample)) if sample[index].strip().startswith('Seq.')]
    total_sections = []
    for i in range(len(temp)):
        if i < len(temp) - 1:
            total_sections.append(sample[temp[i]:temp[i + 1]])
        else:
            total_sections.append(sample[temp[i]:len(sample)])
    return total_sections


# Get Each drug end index
def get_drug_end_index(data, element_dict):
    if 'dose' in element_dict.keys():
        end_index = element_dict['dose']
    elif 'route' in element_dict.keys():
        end_index = element_dict['route']
    elif 'indication' in element_dict.keys():
        end_index = element_dict['indication']
    elif 'therapy' in element_dict.keys():
        end_index = element_dict['therapy']
    else:
        for i in range(len(data)):
            if 'causality' in data[i].lower():
                end_index = i
                break
            end_index = len(data)
    return end_index


# Processing Drug name
def get_drug_name(data, element_dict):
    drug_end_index = get_drug_end_index(data, element_dict)
    drug_name = data[element_dict['drug']:drug_end_index]
    return drug_name


# Get Available dose data for each product
def get_dose_data(data, element_dict):
    dose_start_index = element_dict['dose']
    if 'route' in element_dict.keys():
        end_index = element_dict['route']
    elif 'indication' in element_dict.keys():
        end_index = element_dict['indication']
    elif 'therapy' in element_dict.keys():
        end_index = element_dict['therapy']
    else:
        for i in range(len(data)):
            if 'causality' in data[i].lower():
                end_index = i
                break
            end_index = len(data)
    dose_data = data[dose_start_index:end_index]
    return dose_data


# Get Route data for each product
def get_route_data(data, element_dict):
    route_start_index = element_dict['route']
    if 'indication' in element_dict.keys():
        end_index = element_dict['indication']
    elif 'therapy' in element_dict.keys():
        end_index = element_dict['therapy']
    else:
        for i in range(len(data)):
            if 'causality' in data[i].lower():
                end_index = i
                break
            end_index = len(data)
    route_data = data[route_start_index:end_index]
    return route_data


# Get Indication data for each product
def get_indication_data(data, element_dict):
    indication_start_index = element_dict['indication']
    if 'therapy' in element_dict.keys():
        end_index = element_dict['therapy']
    else:
        for i in range(len(data)):
            if 'causality' in data[i].lower():
                end_index = i
                break
            end_index = len(data)
    indication_data = data[indication_start_index:end_index]
    return indication_data


# Get therapy data for each product
def get_therapy_data(data, element_dict):
    therapy_start_index = element_dict['therapy']
    for i in range(len(data)):
        if 'causality' in data[i].lower():
            end_index = i
            break
        end_index = len(data)
    therapy_data = data[therapy_start_index:end_index]
    return therapy_data


# Get causality data for each suspect product
def get_causality_level_data(data, start_index, prod_seq_num):
    causality_data = data[start_index:len(data)]
    event_name_index = []
    event_list_of_list = []
    for i in range(len(causality_data)):
        if re.match('\s*\d+\s*\d*\)\s*\w*', causality_data[i]):
            event_name_index.append(i)
    for i in range(len(event_name_index)):
        if i < len(event_name_index) - 1:
            event_list_of_list.append(causality_data[event_name_index[i]:event_name_index[i + 1]])
        else:
            event_list_of_list.append(causality_data[event_name_index[i]:len(causality_data)])
    event_final_list = []
    event_seq_no = 0
    for event in event_list_of_list:
        event_seq_no += 1
        event_dict = {'event_seq_no': event_seq_no, 'prod_seq_no': prod_seq_num}
        for item in range(len(event)):
            if 'with drug' in event[item].lower():
                event_dict['actionTaken'] = event[item].partition(':')[2].strip()
            if 'reporter' in event[item].lower():
                event_dict['causalityReporter'] = event[item].partition(':')[2].strip()
        event_final_list.append(event_dict)
    return event_final_list


# Process Product Reaction Section on the additional pages of the form
def process_product_reaction_level_data(pvi_json, extracted_json):
    data = ''
    for ind in range(len(extracted_json)):
        if extracted_json[ind]['AnnotID'] == '10027':
            data = extracted_json[ind]['value']
            break
    if data not in [None, '']:
        total_section_data_in_list = get_list_of_list_for_extracted_data(data)
        prod_seq_no = 0
        index = 0
        pe_list = []
        concomitant = 0
        for item in total_section_data_in_list:
            element_available_dict = check_total_elements_for_product(item)
            prod_seq_no += 1
            if len(pvi_json['products']) > index:
                pvi_json['products'][index]['seq_num'] = prod_seq_no
                pvi_json['products'][index]['license_value'] = process_drug_name(get_drug_name(item, element_available_dict))
            else:
                pvi_json['products'].append(copy.deepcopy(pvi_json['products'][0]))
                pvi_json['products'][index] = change_reference_values_to_none(pvi_json['products'][index])
                pvi_json['products'][index]['doseInformations'] = pvi_json['products'][index]['doseInformations'][:1]
                pvi_json['products'][index]['indications'] = pvi_json['products'][index]['indications'][:1]
                pvi_json['products'][index]['concentration'] = pvi_json['products'][index]['concentration'][:1]
                pvi_json['products'][index]['ingredients'] = pvi_json['products'][index]['ingredients'][:1]
                pvi_json['products'][index]['seq_num'] = prod_seq_no
                pvi_json["products"][index]['license_value'] = process_drug_name(get_drug_name(item, element_available_dict))
            if 'dose' in element_available_dict.keys():
                pvi_json = process_dose_data(get_dose_data(item, element_available_dict), index, pvi_json)
            if 'route' in element_available_dict.keys():
                pvi_json = process_route_data(get_route_data(item, element_available_dict), index, pvi_json)
            if 'indication' in element_available_dict.keys():
                pvi_json = process_indication_data(get_indication_data(item, element_available_dict), index, pvi_json)
            if 'therapy' in element_available_dict.keys():
                pvi_json = process_therapy_data(get_therapy_data(item, element_available_dict), index, pvi_json)
            for indx in range(len(item)):
                if 'causality' in item[indx].lower():
                    event_level_data = get_causality_level_data(item, indx, prod_seq_no)
                    if len(event_level_data) == 1:
                        pvi_json["products"][index]["actionTaken"]["value"] = event_level_data[0]['actionTaken']
                    pe_list.append(event_level_data)
                    #concomitant = 0
                    break
            if concomitant == 1:
                pvi_json['products'][index]['role_value'] = 'concomitant'
            else:
                pvi_json['products'][index]['role_value'] = 'suspect'
            for indx in range(len(item)):
                if 'concomitant drugs' in item[indx].lower():
                    concomitant = 1
                    break
            index += 1
        if len(pe_list) > 0:
            pvi_json = process_pe_matrix_data(pvi_json, pe_list)
    suspect_len = len(total_section_data_in_list)
    return pvi_json, suspect_len


# Process PE Matrix Data
def process_pe_matrix_data(pvi_json, pe_list):
    temp = 0
    for item in pe_list:
        for index in range(len(item)):
            if temp < len(pvi_json['productEventMatrix']):
                pvi_json['productEventMatrix'][temp] = change_reference_values_to_none(pvi_json['productEventMatrix'][temp])
                pvi_json['productEventMatrix'][temp]['product_seq_num'] = item[index]['prod_seq_no']
                pvi_json['productEventMatrix'][temp]['event_seq_num'] = item[index]['event_seq_no']
                pvi_json['productEventMatrix'][temp]['relatednessAssessments'][0]['result']['value'] = item[index]['causalityReporter']
            else:
                pvi_json['productEventMatrix'].append(copy.deepcopy(pvi_json['productEventMatrix'][0]))
                pvi_json['productEventMatrix'][temp] = change_reference_values_to_none(pvi_json['productEventMatrix'][temp])
                pvi_json['productEventMatrix'][temp]['product_seq_num'] = item[index]['prod_seq_no']
                pvi_json['productEventMatrix'][temp]['event_seq_num'] = item[index]['event_seq_no']
                pvi_json['productEventMatrix'][temp]['relatednessAssessments'][0]['result']['value'] = item[index]['causalityReporter']
            temp += 1
    return pvi_json


# Process Drug Name
def process_drug_name(sample):
    drug = "".join(sample)
    return drug.partition(':')[2].strip()


# Process Dose Data for each product
def process_dose_data(dose_data, index, pvi_json):
    dose_data[0] = dose_data[0].partition(':')[2]
    dose_data = [dose.strip() for dose in dose_data]
    temp = 0
    dose_index = 0
    while temp < len(dose_data):
        if re.match('^\d+\s*\)', dose_data[temp]):
            temp += 1
        else:
            dose_data[temp - 1] = ''.join(dose_data[temp - 1:temp + 1])
            dose_data.pop(temp)
    while dose_index < len(dose_data):
        if len(pvi_json['products'][index]['doseInformations']) > dose_index:
            pvi_json['products'][index]['doseInformations'][dose_index]['dose_inputValue'] = dose_data[dose_index]
        else:
            pvi_json['products'][index]['doseInformations'].append(copy.deepcopy(pvi_json['products'][index]['doseInformations'][0]))
            pvi_json['products'][index]['doseInformations'][dose_index] = change_reference_values_to_none(pvi_json['products'][index]['doseInformations'][dose_index])
            pvi_json['products'][index]['doseInformations'][dose_index]['dose_inputValue'] = dose_data[dose_index]
        dose_index += 1
    return pvi_json


# Process Indication Data for each product
def process_indication_data(indication_data, index, pvi_json):
    indication_data[0] = indication_data[0].partition(':')[2]
    indication_data = [indication.strip() for indication in indication_data]
    temp = 0
    ind_index = 0
    while temp < len(indication_data):
        if re.match('^\d+\s*\)', indication_data[temp]):
            temp += 1
        else:
            indication_data[temp - 1] = ''.join(indication_data[temp - 1:temp + 1])
            indication_data.pop(temp)
    while ind_index < len(indication_data):
        if len(pvi_json['products'][index]['indications']) > ind_index:
            pvi_json['products'][index]['indications'][ind_index]['reportedReaction'] = indication_data[ind_index]
        else:
            pvi_json['products'][index]['indications'].append({'reactionCoded': None, 'reportedReaction': None})
            pvi_json['products'][index]['indications'][ind_index]['reportedReaction'] = indication_data[ind_index]
        ind_index += 1
    return pvi_json


# Process Route Data for each product
def process_route_data(route_data, index, pvi_json):
    route_data[0] = route_data[0].partition(':')[2]
    route_data = [route.strip() for route in route_data]
    temp = 0
    route_index = 0
    while temp < len(route_data):
        if re.match('^\d+\s*\)', route_data[temp]):
            temp += 1
        else:
            route_data[temp - 1] = ''.join(route_data[temp - 1:temp + 1])
            route_data.pop(temp)
    while route_index < len(route_data):
        if len(pvi_json['products'][index]['doseInformations']) > route_index:
            pvi_json['products'][index]['doseInformations'][route_index]['route_value'] = route_data[route_index]
        else:
            pvi_json['products'][index]['doseInformations'].append(copy.deepcopy(pvi_json['products'][index]['doseInformations'][0]))
            pvi_json['products'][index]['doseInformations'][route_index] = change_reference_values_to_none(pvi_json['products'][index]['doseInformations'][route_index])
            pvi_json['products'][index]['doseInformations'][route_index]['route_value'] = route_data[route_index]
        route_index += 1
    return pvi_json


# Process Therapy Data for each product
def process_therapy_data(therapy_data, index, pvi_json):
    therapy_data[0] = therapy_data[0].partition(':')[2]
    therapy_data = [therapy.strip() for therapy in therapy_data]
    temp = 0
    therapy_index = 0
    while temp < len(therapy_data):
        if re.match('^\d+\s*\)', therapy_data[temp]):
            temp += 1
        else:
            therapy_data[temp - 1] = ''.join(therapy_data[temp - 1:temp + 1])
            therapy_data.pop(temp)
    while therapy_index < len(therapy_data):
        if len(pvi_json['products'][index]['doseInformations']) > therapy_index:
            pvi_json['products'][index]['doseInformations'][therapy_index]['startDate'] = therapy_data[therapy_index]
        else:
            pvi_json['products'][index]['doseInformations'].append(copy.deepcopy(pvi_json['products'][index]['doseInformations'][0]))
            pvi_json['products'][index]['doseInformations'][therapy_index] = change_reference_values_to_none(pvi_json['products'][index]['doseInformations'][therapy_index])
            pvi_json['products'][index]['doseInformations'][therapy_index]['startDate'] = therapy_data[therapy_index]
        therapy_index += 1
    return pvi_json


# Process First Receipt Date
def process_first_receipt_date(pvi_json):
    if pvi_json["senderCaseVersion"]:
        try:
            pvi_json["senderCaseVersion"] = int(pvi_json["senderCaseVersion"])
        except:
            pass
    if pvi_json['literatures'][0]['pages'] not in [None, '']:
        if 'inovio' in pvi_json['literatures'][0]['pages'].lower() or 'ziopharm' in pvi_json['literatures'][0]['pages'].lower():
            pvi_json['receiptDate'] = None
        else:
            pvi_json['receiptDate'] = pvi_json['receiptDate'].replace('/', '-')
            pvi_json['receiptDate'] = pvi_json['receiptDate'].replace(' ', '')
            pvi_json["mostRecentReceiptDate"] = pvi_json['receiptDate']
            if pvi_json["senderCaseVersion"] == 2:
                pvi_json['receiptDate'] = None
        pvi_json['literatures'][0]['pages'] = None
    return pvi_json


# Process Concomitant Data available on the first page
def process_concomitant_first_page(pvi_json):
    med_history_zero = copy.deepcopy(pvi_json['patient']['medicalHistories'][0])
    con_prod_list = []
    for prod in pvi_json['products']:
        if prod['role_value'].lower() == 'concomitant':
            con_prod_list.append(prod['license_value'])
    index = 0
    temp = 0
    ind = 0
    if con_prod_list:
        while temp < len(pvi_json['patient']['medicalHistories']):
            if pvi_json['patient']['medicalHistories'][temp]['reportedReaction'].strip().split('(')[0].startswith(con_prod_list[index].split('(')[0]):
                index += 1
                temp += 1
            else:
                if pvi_json['patient']['medicalHistories'][temp]['reportedReaction']:
                    pvi_json['patient']['medicalHistories'][temp-1]['reportedReaction'] = pvi_json['patient']['medicalHistories'][temp-1]['reportedReaction'] + ' ' + \
                                                              pvi_json['patient']['medicalHistories'][temp]['reportedReaction']
                if pvi_json['patient']['medicalHistories'][temp]['startDate']:
                    pvi_json['patient']['medicalHistories'][temp-1]['startDate'] = pvi_json['patient']['medicalHistories'][temp-1]['startDate'] + ' ' + pvi_json['patient']['medicalHistories'][temp]['startDate']
                if pvi_json['patient']['medicalHistories'][temp]['endDate']:
                    pvi_json['patient']['medicalHistories'][temp-1]['endDate'] = pvi_json['patient']['medicalHistories'][temp-1]['endDate'] + ' ' + pvi_json['patient']['medicalHistories'][temp]['endDate']
                pvi_json['patient']['medicalHistories'].pop(temp)
        for prod in pvi_json['products']:
            if prod['role_value'].lower() == 'concomitant':
                if ind < len(pvi_json['patient']['medicalHistories']):
                    prod['doseInformations'][0]['dose_inputValue'] = pvi_json['patient']['medicalHistories'][ind]['endDate'].replace('\n', '')
                    dates_list = pvi_json['patient']['medicalHistories'][ind]['startDate'].split('\n')
                    temp_2 = 0
                    for index in range(len(dates_list)):
                        if dates_list[index].strip() not in [None, '']:
                            if temp_2 < len(prod['doseInformations']):
                                prod['doseInformations'][temp_2]['startDate'] = dates_list[index]
                            else:
                                prod['doseInformations'].append(copy.deepcopy(prod['doseInformations'][0]))
                                prod['doseInformations'][temp_2] = change_reference_values_to_none(prod['doseInformations'][temp_2])
                                prod['doseInformations'][temp_2]['startDate'] = dates_list[index]
                            temp_2 += 1
                ind += 1
    else:
        for med in pvi_json['patient']['medicalHistories']:
            if med['reportedReaction'].lower().strip() not in [None, '', 'none']:
                pvi_json['products'].append(copy.deepcopy(pvi_json['products'][0]))
                pvi_json['products'][-1] = change_reference_values_to_none(pvi_json['products'][-1])
                pvi_json['products'][-1]['license_value'] = med['reportedReaction']
                pvi_json['products'][-1]['doseInformations'][0]['startDate'] = med['startDate']
                pvi_json['products'][-1]['doseInformations'][0]['dose_inputValue'] = med['endDate']
                pvi_json['products'][-1]['role_value'] = 'concomitant'
    if len(pvi_json['patient']['medicalHistories']) == 0:
        pvi_json['patient']['medicalHistories'].append(med_history_zero)
        pvi_json['patient']['medicalHistories'][0] = change_reference_values_to_none(pvi_json['patient']['medicalHistories'][0])
    for med in pvi_json['patient']['medicalHistories']:
        med['startDate'] = None
        med['endDate'] = None
        med['reportedReaction'] = None
    return pvi_json


# Process Other relevant History Data available on the First page
def process_other_relevant_history(pvi_json):
    pattern = False
    if pvi_json['summary']['adminNotes'] not in [None, '']:
        data = pvi_json['summary']['adminNotes'].split('\n')
        temp = 0
        for index in range(len(data)):
            if re.match('^\s*\w+.*\[', data[index]):
                pattern = True
                if temp < len(pvi_json['patient']['medicalHistories']):
                    pvi_json = process_patient_med_history_section(pvi_json, index, data, temp)
                else:
                    pvi_json['patient']['medicalHistories'].append(copy.deepcopy(pvi_json['patient']['medicalHistories'][0]))
                    pvi_json['patient']['medicalHistories'][temp] = change_reference_values_to_none(pvi_json['patient']['medicalHistories'][temp])
                    pvi_json = process_patient_med_history_section(pvi_json, index, data, temp)
                temp += 1
        if not pattern:
            pvi_json['patient']['medicalHistories'][0]['historyNote'] = ' '.join(data)
        pvi_json['summary']['adminNotes'] = None
    return pvi_json


# Process Medical History Section
def process_patient_med_history_section(pvi_json, index, data, temp):
    res1 = re.compile('\(\s*//.*\)')
    res2 = re.compile('\(\s*/\w+.*\)')
    res3 = re.compile('\(\s*\d+/.*\)')
    res4 = re.compile('\(\s*\d+-.*\)')
    pvi_json['patient']['medicalHistories'][temp]['reportedReaction'] = data[index].split('[')[0].strip()
    if 'continuing:' in data[index].lower():
        pvi_json['patient']['medicalHistories'][temp]['continuing'] = data[index].split(':')[1].split(')')[0].strip()
    if re.findall(res1, data[index]):
        pattern = 1
        data1 = re.findall(res1, data[index])
        date = process_med_history_start_end_date(data1[0].split(')')[0].strip(), pattern)
        if date:
            pvi_json['patient']['medicalHistories'][temp]['startDate'] = date[0]
            pvi_json['patient']['medicalHistories'][temp]['endDate'] = date[1]
    elif re.findall(res2, data[index]):
        pattern = 2
        data1 = re.findall(res2, data[index])
        date = process_med_history_start_end_date(data1[0].split(')')[0].strip(), pattern)
        if date:
            pvi_json['patient']['medicalHistories'][temp]['startDate'] = date[0]
            pvi_json['patient']['medicalHistories'][temp]['endDate'] = date[1]
    elif re.findall(res3, data[index]):
        pattern = 3
        data1 = re.findall(res3, data[index])
        date = process_med_history_start_end_date(data1[0].split(')')[0].strip(), pattern)
        if date:
            pvi_json['patient']['medicalHistories'][temp]['startDate'] = date[0]
            pvi_json['patient']['medicalHistories'][temp]['endDate'] = date[1]
    elif re.findall(res4, data[index]):
        pattern = 4
        data1 = re.findall(res4, data[index])
        date = process_med_history_start_end_date(data1[0].split(')')[0].strip(), pattern)
        if date:
            pvi_json['patient']['medicalHistories'][temp]['startDate'] = date[0]
            pvi_json['patient']['medicalHistories'][temp]['endDate'] = date[1]
    return pvi_json


# Process Medical History Start and End Dates
def process_med_history_start_end_date(date_data, pattern):
    date = []
    date_data = date_data.replace('(', '').strip()
    if pattern == 1:
        start_date = date_data.split('-')[0].replace('/', '').strip()
        end_date = process_end_date(date_data.split('-')[1].strip())
        date.append(start_date)
        date.append(end_date)
    if pattern == 2 or pattern == 3:
        start_date = date_data.split('-')[0].strip()
        start_year = re.findall('\d\d\d\d', start_date)[0]
        start_mon = re.findall('[a-zA-Z][a-zA-Z][a-zA-Z]', start_date)[0]
        if pattern == 2:
            start_date = start_mon + '-' + start_year
        else:
            start_day = re.findall('\d\d', start_date)[0]
            start_date = start_day + '-' + start_mon + '-' + start_year
        end_date = process_end_date(date_data.split('-')[1].strip())
        date.append(start_date)
        date.append(end_date)
    if pattern == 4:
        date = re.findall('\d\d\s*-\s*[a-zA-Z][a-zA-Z][a-zA-Z]\s*-\s*\d\d\d\d', date_data)
    return date


# Formatting End Date
def process_end_date(end_date):
    if end_date not in [None, '']:
        if re.match('^//', end_date):
            end_date = end_date.replace('/', '').strip()
        else:
            year = re.findall('\d\d\d\d', end_date)[0]
            mon = re.findall('[a-zA-Z][a-zA-Z][a-zA-Z]', end_date)[0]
            if re.match('^/\s*\w+', end_date):
                end_date = mon + '-' + year
            else:
                day = re.findall('\d\d', end_date)[0]
                end_date = day + '-' + mon + '-' + year
    return end_date


# Update report Source
def update_report_source(pvi_json):
    report_list = [0, 0, 0, 0]
    val = pvi_json["project"]
    if 'Study' in val:
        report_list[0] = 1
    if 'health professional' in val:
        report_list[1] = 1
    if 'literature' in val:
        report_list[2] = 1
    if 'other' in val:
        report_list[3] = 1
    pvi_json["project"] = None
    if report_list == [1, 0, 0, 0] or report_list == [1, 1, 0, 0] or report_list == [1, 0, 0, 1]:
        pvi_json["sourceType"][0]["value"] = "Study"
    if report_list == [0, 1, 0, 0] or report_list == [0, 1, 0, 1] or report_list == [0, 0, 0, 1]:
        pvi_json["sourceType"][0]["value"] = "Spontaneous"
    if report_list == [0, 1, 1, 0] or report_list == [0, 0, 1, 0] or report_list == [0, 0, 1, 1]:
        pvi_json["sourceType"][0]["value"] = "Literature spontaneous"
    if report_list == [1, 0, 1, 0]:
        pvi_json["sourceType"][0]["value"] = "Literature Study"
    return pvi_json


# Process Event Seriousness
def process_event_seriousnesss(pvi_json):
    if pvi_json['argus_id'] not in [None, '']:
        if 'death' in pvi_json['argus_id'].lower():
            pvi_json['events'][0]['seriousnesses'][0]['value'] = 'Death'
        if 'hospitalization' in pvi_json['argus_id'].lower():
            if pvi_json['events'][0]['seriousnesses'][-1]['value'] in [None, '']:
                pvi_json['events'][0]['seriousnesses'][-1]['value'] = 'Hospitalization'
            else:
                pvi_json['events'][0]['seriousnesses'].append({'value': None, 'value_acc': 0.95})
                pvi_json['events'][0]['seriousnesses'][-1]['value'] = 'Hospitalization'
        if 'disability' in pvi_json['argus_id'].lower():
            if pvi_json['events'][0]['seriousnesses'][-1]['value'] in [None, '']:
                pvi_json['events'][0]['seriousnesses'][-1]['value'] = 'Disability'
            else:
                pvi_json['events'][0]['seriousnesses'].append({'value': None, 'value_acc': 0.95})
                pvi_json['events'][0]['seriousnesses'][-1]['value'] = 'Disability'
        if 'life threatning' in pvi_json['argus_id'].lower():
            if pvi_json['events'][0]['seriousnesses'][-1]['value'] in [None, '']:
                pvi_json['events'][0]['seriousnesses'][-1]['value'] = 'Life threatning'
            else:
                pvi_json['events'][0]['seriousnesses'].append({'value': None, 'value_acc': 0.95})
                pvi_json['events'][0]['seriousnesses'][-1]['value'] = 'Life threatning'
        if 'congenital anamoly' in pvi_json['argus_id'].lower():
            if pvi_json['events'][0]['seriousnesses'][-1]['value'] in [None, '']:
                pvi_json['events'][0]['seriousnesses'][-1]['value'] = 'Congenital Anamoly'
            else:
                pvi_json['events'][0]['seriousnesses'].append({'value': None, 'value_acc': 0.95})
                pvi_json['events'][0]['seriousnesses'][-1]['value'] = 'Congenital Anamoly'
        if 'other' in pvi_json['argus_id'].lower():
            if pvi_json['events'][0]['seriousnesses'][-1]['value'] in [None, '']:
                pvi_json['events'][0]['seriousnesses'][-1]['value'] = 'Other Medically Important Condition'
            else:
                pvi_json['events'][0]['seriousnesses'].append({'value': None, 'value_acc': 0.95})
                pvi_json['events'][0]['seriousnesses'][-1]['value'] = 'Other Medically Important Condition'
        pvi_json['argus_id'] = None
    return pvi_json


# Process Country
def process_country(pvi_json):
    country_code_list = ['AF', 'AL', 'DZ', 'AS', 'AD', 'AO', 'AI', 'AQ', 'AG', 'AR', 'AM', 'AW',
                         'AU', 'AT', 'AZ', 'BS', 'BH', 'BD', 'BB', 'BY', 'BE', 'BZ', 'BJ', 'BM', 'BT', 'BO', 'BA', 'BW',
                         'BV', 'BR', 'IO', 'BN', 'BG', 'BF', 'BI', 'KH', 'CM', 'CA', 'CV', 'KY', 'CF', 'TD', 'CL', 'CN',
                         'CX', 'CC', 'CO', 'KM', 'CG', 'CK', 'CR', 'CI', 'HR', 'CU', 'CY', 'CZ', 'DK', 'DJ', 'DM', 'DO',
                         'EC', 'EG', 'SV', 'GQ', 'ER', 'EE', 'ET', 'FK', 'FO', 'FJ', 'FI', 'FR', 'GF', 'PF', 'TF', 'GA',
                         'GM', 'GE', 'DE', 'GH', 'GI', 'GR', 'GL', 'GD', 'GP', 'GU', 'GT', 'GN', 'GW', 'GY', 'HT',
                         'HM', 'HN', 'HK', 'HU', 'IS', 'IN', 'ID', 'IR', 'IQ', 'IE', 'IL', 'IT', 'JM', 'JP', 'JO', 'KZ',
                         'KE', 'KI', 'KP', 'KR', 'KW', 'KG', 'LA', 'LV', 'LB', 'LS', 'LR', 'LY', 'LI', 'LT', 'LU', 'MO',
                         'MK', 'MG', 'MW', 'MY', 'MV', 'ML', 'MT', 'MH', 'MQ', 'MR', 'MU', 'YT', 'MX', 'FM', 'MD', 'MC',
                         'MN', 'MS', 'MA', 'MZ', 'MM', 'NA', 'NR', 'NP', 'NL', 'AN', 'NC', 'NZ', 'NI', 'NE', 'NG', 'NU',
                         'NF', 'MP', 'NO', 'OM', 'PK', 'PW', 'PA', 'PG', 'PY', 'PE', 'PH', 'PN', 'PL', 'PT', 'PR', 'QA',
                         'RE', 'RO', 'RU', 'RW', 'KN', 'LC', 'VC', 'WS', 'SM', 'ST', 'SA', 'SN', 'SC', 'SL', 'SG', 'SK',
                         'SI', 'SB', 'SO', 'ZA', 'GS', 'ES', 'LK', 'SH', 'PM', 'SD', 'SR', 'SJ', 'SZ', 'SE', 'CH', 'SY',
                         'TW', 'TJ', 'TZ', 'TH', 'TG', 'TK', 'TO', 'TT', 'TN', 'TR', 'TM', 'TC', 'TV', 'UG', 'UA', 'AE',
                         'GB', 'US', 'UM', 'UY', 'UZ', 'VU', 'VA', 'VE', 'VN', 'VG', 'VI', 'WF', 'EH', 'YE', 'CD', 'ZM',
                         'ZW', 'EU', 'RS', 'ME', 'AX', 'GG', 'IM', 'JE', 'PS', 'BL', 'MF', 'TL', 'VA', 'BQ', 'CW', 'SX',
                         'SS', 'XA']
    country_list = ['AFGHANISTAN', 'ALBANIA', 'ALGERIA', 'AMERICAN SAMOA', 'ANDORRA', 'ANGOLA', 'ANGUILLA',
                    'ANTARCTICA', 'ANTIGUA AND BARBUDA', 'ARGENTINA', 'ARMENIA', 'ARUBA', 'AUSTRALIA', 'AUSTRIA',
                    'AZERBAIJAN', 'BAHAMAS', 'BAHRAIN', 'BANGLADESH', 'BARBADOS', 'BELARUS', 'BELGIUM', 'BELIZE',
                    'BENIN', 'BERMUDA', 'BHUTAN', 'BOLIVIA', 'BOSNIA AND HERZEGOVINA', 'BOTSWANA', 'BOUVET ISLAND',
                    'BRAZIL', 'BRITISH INDIAN OCEAN TERRITORY', 'BRUNEI DARUSSALAM', 'BULGARIA', 'BURKINA FASO',
                    'BURUNDI', 'CAMBODIA', 'CAMEROON', 'CANADA', 'CAPE VERDE', 'CAYMAN ISLANDS',
                    'CENTRAL AFRICAN REPUBLIC', 'CHAD', 'CHILE', 'CHINA', 'CHRISTMAS ISLAND', 'COCOS (KEELING) ISLANDS',
                    'COLOMBIA', 'COMOROS', 'CONGO', 'COOK ISLANDS', 'COSTA RICA', 'CÔTE D IVOIRE', 'CROATIA', 'CUBA',
                    'CYPRUS', 'CZECH REPUBLIC', 'DENMARK', 'DJIBOUTI', 'DOMINICA', 'DOMINICAN REPUBLIC', 'ECUADOR',
                    'EGYPT', 'EL SALVADOR', 'EQUATORIAL GUINEA', 'ERITREA', 'ESTONIA', 'ETHIOPIA',
                    'FALKLAND ISLANDS (MALVINAS)', 'FAROE ISLANDS', 'FIJI', 'FINLAND', 'FRANCE', 'FRENCH GUIANA',
                    'FRENCH POLYNESIA', 'FRENCH SOUTHERN TERRITORIES', 'GABON', 'GAMBIA', 'GEORGIA', 'GERMANY', 'GHANA',
                    'GIBRALTAR', 'GREECE', 'GREENLAND', 'GRENADA', 'GUADELOUPE', 'GUAM', 'GUATEMALA', 'GUINEA',
                    'GUINEA-BISSAU', 'GUYANA', 'HAITI', 'HEARD ISLAND AND MCDONALD ISLANDS', 'HONDURAS', 'HONG KONG',
                    'HUNGARY', 'ICELAND', 'INDIA', 'INDONESIA', 'IRAN, ISLAMIC REPUBLIC OF', 'IRAQ', 'IRELAND',
                    'ISRAEL', 'ITALY', 'JAMAICA', 'JAPAN', 'JORDAN', 'KAZAKHSTAN', 'KENYA', 'KIRIBATI',
                    'KOREA, DEMOCRATIC PEOPLE S REPUBLIC OF', 'KOREA, REPUBLIC OF', 'KUWAIT', 'KYRGYZSTAN',
                    'LAO PEOPLE S DEMOCRATIC REPUBLIC', 'LATVIA', 'LEBANON', 'LESOTHO', 'LIBERIA',
                    'LIBYAN ARAB JAMAHIRIYA', 'LIECHTENSTEIN', 'LITHUANIA', 'LUXEMBOURG', 'MACAO',
                    'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF', 'MADAGASCAR', 'MALAWI', 'MALAYSIA', 'MALDIVES',
                    'MALI', 'MALTA', 'MARSHALL ISLANDS', 'MARTINIQUE', 'MAURITANIA', 'MAURITIUS', 'MAYOTTE', 'MEXICO',
                    'MICRONESIA, FEDERATED STATES OF', 'MOLDOVA', 'MONACO', 'MONGOLIA', 'MONTSERRAT', 'MOROCCO',
                    'MOZAMBIQUE', 'MYANMAR', 'NAMIBIA', 'NAURU', 'NEPAL', 'NETHERLANDS', 'NETHERLANDS ANTILLES',
                    'NEW CALEDONIA', 'NEW ZEALAND', 'NICARAGUA', 'NIGER', 'NIGERIA', 'NIUE', 'NORFOLK ISLAND',
                    'NORTHERN MARIANA ISLANDS', 'NORWAY', 'OMAN', 'PAKISTAN', 'PALAU', 'PANAMA', 'PAPUA NEW GUINEA',
                    'PARAGUAY', 'PERU', 'PHILIPPINES', 'PITCAIRN', 'POLAND', 'PORTUGAL', 'PUERTO RICO', 'QATAR',
                    'RÉUNION', 'ROMANIA', 'RUSSIAN FEDERATION', 'RWANDA', 'SAINT KITTS AND NEVIS', 'SAINT LUCIA',
                    'SAINT VINCENT AND THE GRENADINES', 'SAMOA', 'SAN MARINO', 'SAO TOME AND PRINCIPE', 'SAUDI ARABIA',
                    'SENEGAL', 'SEYCHELLES', 'SIERRA LEONE', 'SINGAPORE', 'SLOVAKIA', 'SLOVENIA', 'SOLOMON ISLANDS',
                    'SOMALIA', 'SOUTH AFRICA', 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS', 'SPAIN', 'SRI LANKA',
                    'SAINT HELENA', 'SAINT PIERRE AND MIQUELON', 'SUDAN', 'SURINAME', 'SVALBARD AND JAN MAYEN',
                    'SWAZILAND', 'SWEDEN', 'SWITZERLAND', 'SYRIAN ARAB REPUBLIC', 'TAIWAN, PROVINCE OF CHINA',
                    'TAJIKISTAN', 'TANZANIA, UNITED REPUBLIC OF', 'THAILAND', 'TOGO', 'TOKELAU', 'TONGA',
                    'TRINIDAD AND TOBAGO', 'TUNISIA', 'TURKEY', 'TURKMENISTAN', 'TURKS AND CAICOS ISLANDS', 'TUVALU',
                    'UGANDA', 'UKRAINE', 'UNITED ARAB EMIRATES', 'UNITED KINGDOM', 'UNITED STATES',
                    'UNITED STATES MINOR OUTLYING ISLANDS', 'URUGUAY', 'UZBEKISTAN', 'VANUATU',
                    'HOLY SEE (VATICAN CITY STATE)', 'VENEZUELA, BOLIVARIAN REPUBLIC OF', 'VIET NAM',
                    'VIRGIN ISLANDS, BRITISH', 'VIRGIN ISLANDS, U.S.', 'WALLIS AND FUTUNA', 'WESTERN SAHARA', 'YEMEN',
                    'CONGO, THE DEMOCRATIC REPUBLIC OF THE', 'ZAMBIA', 'ZIMBABWE', 'EUROPEAN UNION', 'SERBIA',
                    'MONTENEGRO', 'ÅLAND ISLANDS', 'GUERNSEY', 'ISLE OF MAN', 'JERSEY',
                    'PALESTINIAN TERRITORY, OCCUPIED', 'SAINT BARTHÉLEMY', 'SAINT MARTIN', 'TIMOR-LESTE',
                    'VATICAN CITY STATE', 'BONAIRE, SINT EUSTATIUS AND SABA', 'CURAÇAO', 'SINT MAARTEN (DUTCH PART)',
                    'SOUTH SUDAN', 'WORLD']
    country = pvi_json['aegis_id'].strip()
    country = country.replace(".", "")
    if "USA" in country:
        country = "United States of America"
    if 'UK' in country:
        country = 'United Kingdom'
    else:
        for index in range(len(country_code_list)):
            if country_code_list[index] == country:
                country = country_list[index]
                break
    if country not in [None, '']:
        pvi_json['events'][0]['country'] = country
    pvi_json['aegis_id'] = None
    return pvi_json


# Formatting Event Dates
def process_event_start_dates(pvi_json):
    for event in pvi_json['events']:
        try:
            if event['startDate'] not in [None, '']:
                ongoing = "No"
                start_date = event['startDate']
                start_date = start_date.replace("?","").strip(" / \ - ")
                if "/" in start_date:
                    start_date = start_date.split("/")
                    for slash in range(len(start_date)):
                        start_date[slash] = start_date[slash].strip().replace(" ","").replace("  ","")
                    while "" in start_date:
                        start_date.remove("")
                    if start_date:
                        event['startDate'] = "-".join(start_date)
                elif "-" in start_date:
                    start_date = start_date.split("-")
                    for slash in range(len(start_date)):
                        start_date[slash] = start_date[slash].strip().replace(" ","").replace("  ","")
                    while "" in start_date:
                        start_date.remove("")
                    if start_date:
                        event['startDate'] = "-".join(start_date)
                else:
                    try:
                        if start_date.strip() == "":
                            event['startDate'] = None
                        elif len(start_date.strip()) == 4 and start_date.strip().isdigit():
                            event['startDate'] = start_date
                        else:
                            event['startDate'] = None
                    except:
                        event['startDate'] = None
                try:
                    end_date = ""
                    end_date = event["endDate"].replace("?","").strip(" / \ - ")
                    if "ongoing" in end_date.lower():
                        ongoing = "Yes"
                        end_date_index = end_date.lower().find("ongoing")
                        if end_date_index != -1:
                            end_date = end_date[:end_date_index]
                except:
                    pass
                if "/" in end_date:
                    end_date = end_date.split("/")
                    for slash in range(len(end_date)):
                        end_date[slash] = end_date[slash].strip().replace(" ","").replace("  ","")
                    while "" in end_date:
                        end_date.remove("")
                    if end_date:
                        event['endDate'] = "-".join(end_date)
                elif "-" in end_date:
                    end_date = end_date.split("-")
                    for slash in range(len(end_date)):
                        end_date[slash] = end_date[slash].strip().replace(" ","").replace("  ","")
                    while "" in end_date:
                        end_date.remove("")
                    if end_date:
                        event['endDate'] = "-".join(end_date)
                else:
                    try:
                        if end_date.strip() == "":
                            event['endDate'] = None
                        elif len(end_date.strip()) == 4 and end_date.strip().isdigit():
                            event['endDate'] = end_date
                        else:
                            event['endDate'] = None
                    except:
                        event['endDate'] = None
    
                if not event['endDate'] and ongoing == "Yes":
                    event['endDate'] = "Ongoing"
        except:
            pass
    return pvi_json


# Formatting Product Start and End Dates
def process_product_start_end_date(pvi_json):
    for prod in pvi_json['products']:
        for dose in prod['doseInformations']:
            date = dose['startDate']
            if date not in [None, '']:
                dose['startDate'] = date.split(' -')[0].strip()
                dose['startDate'] = re.sub('^\s*\d+\s*\)', '', dose['startDate']).strip()
                dose['startDate'] = process_date(dose['startDate'].replace(' ', ''))
                if ' -' in date:
                    dose['endDate'] = date.split(' -')[1].strip()
                    if dose['endDate'] not in [None, '']:
                        dose['endDate'] = process_date(dose['endDate'].replace(' ', ''))
    return pvi_json


# Additional function for Process date for Products
def process_date(date):
    if re.match('^//', date):
        if len(re.findall('\d\d\d\d', date)) > 0:
            date = re.findall('\d\d\d\d', date)[0]
        else:
            date = None
    elif re.match('^/\s*\w+', date):
        if len(re.findall('[a-zA-Z][a-zA-Z][a-zA-Z]', date)) > 0 and len(re.findall('\d\d\d\d', date)) > 0:
            date = re.findall('[a-zA-Z][a-zA-Z][a-zA-Z]', date)[0] + '-' + re.findall('\d\d\d\d', date)[0]
        else:
            date = None
    else:
        if len(re.findall('\d\d', date)) > 0 and len(re.findall('[a-zA-Z][a-zA-Z][a-zA-Z]', date)) > 0 and len(re.findall('\d\d\d\d', date)) > 0:
            date = re.findall('\d\d', date)[0] + '-' + re.findall('[a-zA-Z][a-zA-Z][a-zA-Z]', date)[0] + '-' + re.findall('\d\d\d\d', date)[0]
        else:
            date = None
    return date


# Formatting Route and Dose values  ###---
def process_route_and_dose_value(pvi_json):
    for prod in pvi_json['products']:
        for dose in prod['doseInformations']:
            if dose['route_value'] not in [None, '']:
                dose['route_value'] = re.sub('^\s*\d+\s*\)', '', dose['route_value'])
                r_value = dose['route_value']
                if r_value not in [None, ""]:
                    dose['route_value'] = r_value.split('(')[0].strip()

            if dose['dose_inputValue'] not in [None, '']:
                dose['dose_inputValue'] = re.sub('^\s*\d+\s*\)', '', dose['dose_inputValue'])
                dose['description'] = dose['dose_inputValue'].strip()
                dose['dose_inputValue'] = None

    return pvi_json


# Formatting Indication Reported Reaction
def process_indication_reported_reaction(pvi_json):
    for prod in pvi_json['products']:
        for indication in prod['indications']:
            if indication['reportedReaction'] not in [None, '']:
                indication['reportedReaction'] = re.sub('^\s*\d+\s*\)', '', indication['reportedReaction'])
                indication['reportedReaction'] = re.sub('\[\s*\w+.*\]', '', indication['reportedReaction']).strip()
    return pvi_json


def removing_duplicate_words(given_string):
    coded_val = ""
    if given_string:
        coded_val = re.findall('\(\s*\w+.*\)', given_string)[0].strip()
        coded_val = coded_val.split(",")[0].strip("( ) ")
        if '(' in coded_val and ')' in coded_val:
            coded_val = coded_val.split("(")[1].strip()
        elif '(' in coded_val:
            coded_val = coded_val.split("(")[0].strip()
        else:
            coded_val = coded_val.split(")")[0].strip()
    return coded_val


# Processing Event Names  ###---
def process_event_name_reported_reaction_and_coded(pvi_json):
    for event in pvi_json['events']:
        if event['reportedReaction'] not in [None, '']:
            try:
                event['reactionCoded'] = removing_duplicate_words(event['reportedReaction'])
            except:
                event['reactionCoded'] = None
            event['reportedReaction'] = 'Refer to Narrative for reported verbatim term'
    return pvi_json


# Formatting Product Names
def process_product_name(pvi_json):
    for prod in pvi_json['products']:
        if prod['license_value'] not in [None, '']:
            prod_name_ori = prod['license_value']
            if prod["role_value"] == "suspect":
                suspect_name = re.findall('\(\s*\w+.*\)',prod_name_ori)
                if suspect_name:
                    suspect_name = suspect_name[0].split(')')[0].replace('(', '')
                    if "infusion" in suspect_name.lower() or "injection" in suspect_name.lower():
                        suspect_name = prod_name_ori.split("(")[0]
                else:
                    suspect_name = prod_name_ori.split("(")[0]
                prod['license_value'] = suspect_name
            elif prod["role_value"] == "concomitant":
                concom_name = re.findall('\(\s*\w+.*\)',prod_name_ori)
                if concom_name:
                    concom_name = concom_name[0].split(')')[0].replace('(', '')
                    if "tablet" in concom_name.lower() or concom_name.strip()[0].isdigit():
                        concom_name = prod_name_ori.split("(")[0]
                else:
                    concom_name = prod_name_ori.split("(")[0]
                prod['license_value'] = concom_name
                
            '''
            prod_pattern_find = re.findall('\(\s*\w+.*\)', prod['license_value'])
            if len(prod_pattern_find) > 0:
                prod['license_value'] = prod_pattern_find[0].split(')')[0].replace('(', '')
            '''
    return pvi_json


# Populating Reporter Address
def populate_reporter_adr(pvi_json, reporter_address, row_index):
    street = reporter_address.get("house_number", "")
    street = street + " " + reporter_address.get("house", "").strip()
    street = street + " " + reporter_address.get("road", "").strip()

    pvi_json["reporters"][row_index]["street"] = street
    pvi_json["reporters"][row_index]["city"] = reporter_address.get("city", None)
    pvi_json["reporters"][row_index]["state"] = reporter_address.get("state", None)
    pvi_json["reporters"][row_index]["postcode"] = reporter_address.get("postcode", None)
    if "country" in reporter_address.keys():
        if reporter_address["country"]:
            pvi_json["reporters"][row_index]["country"] = reporter_address["country"]
    return pvi_json


# Breaking Address into components
def break_address_into_components(address_str):
    parsed_address_tuple = parse_address(address_str)
    address_dict = {}
    for address_component in parsed_address_tuple:
        address_dict[address_component[1]] = address_component[0]
    for key, val in address_dict.items():
        if key == "country":
            address_dict[key] = val.upper()
        else:
            address_dict[key] = val.title()
    return address_dict


# Formatting Reporter Name
def populate_reporter_name(pvi_json, reporter_index):
    if pvi_json['reporters'][reporter_index]['givenName'] not in [None, ""]:
        first_reporter_name = pvi_json['reporters'][reporter_index]['givenName']
        if "Dr." in first_reporter_name:
            first_reporter_name = first_reporter_name.replace("Dr.", "").strip()
            pvi_json["reporters"][reporter_index]["title"] = "Dr"
        elif "Dr" in first_reporter_name:
            first_reporter_name = first_reporter_name.replace("Dr", "").strip()
            pvi_json["reporters"][reporter_index]["title"] = "Dr"
        elif "Dr," in first_reporter_name:
            first_reporter_name = first_reporter_name.replace("Dr,", "").strip()
            pvi_json["reporters"][reporter_index]["title"] = "Dr"

        pvi_json["reporters"][reporter_index]["firstName"] = first_reporter_name.split()[0]
        if len(first_reporter_name.split()) == 2:
            pvi_json["reporters"][reporter_index]["lastName"] = first_reporter_name.split()[-1]
        elif len(first_reporter_name.split()) == 3:
            pvi_json["reporters"][reporter_index]["middleName"] = first_reporter_name.split()[1]
            pvi_json["reporters"][reporter_index]["lastName"] = first_reporter_name.split()[-1]
        elif len(first_reporter_name.split()) > 3:
            pvi_json["reporters"][reporter_index]["middleName"] = first_reporter_name.split()[1]
            pvi_json["reporters"][reporter_index]["lastName"] = " ".join(first_reporter_name.split()[2:])

    pvi_json["reporters"][reporter_index]["givenName"] = None
    return pvi_json


# Processing Reporter Section
def process_reporter(pvi_json):
    telephone = False
    if pvi_json['reporters'][0]['givenName'] not in [None, '']:
        data = pvi_json['reporters'][0]['givenName'].split('\n')
        pvi_json['reporters'][0]['givenName'] = data[0].strip()
        pvi_json = populate_reporter_name(pvi_json, 0)
        for index in range(len(data)):
            data[index] = data[index].strip()
            if 'tel:' in data[index].lower():
                tel_index = index
                telephone = True
        if telephone:
            address = ', '.join(data[1:tel_index])
            pvi_json['reporters'][0]['telephone'] = ' '.join(data[tel_index:])
            pvi_json['reporters'][0]['telephone'] = pvi_json['reporters'][0]['telephone'].split(':')[1].strip()
        else:
            address = ', '.join(data[1:])
        if address not in [None, '']:
            address_dict = break_address_into_components(address)
            pvi_json = populate_reporter_adr(pvi_json, address_dict, 0)
    return pvi_json


# Processing data if only one product is available on first page
def process_single_product_on_first_page(pvi_json):
    try:
        if pvi_json['products'][0]['doseInformations'][0]['dose_inputValue'] not in [None, '']:
            pvi_json['products'][0]['doseInformations'][0]['dose_inputValue'] = pvi_json['products'][0]['doseInformations'][0]['dose_inputValue'].strip()
            if not re.match('^\d+\s*\)', pvi_json['products'][0]['doseInformations'][0]['dose_inputValue']):
                if pvi_json['products'][1]['doseInformations'][0]['dose_inputValue']:
                    pvi_json['products'][0]['doseInformations'][0]['dose_inputValue'] = pvi_json['products'][0]['doseInformations'][0]['dose_inputValue'] + '' + pvi_json['products'][1]['doseInformations'][0]['dose_inputValue']
    except:
        pass
    try:
        if pvi_json['products'][0]['doseInformations'][0]['route_value'] not in [None, '']:
            pvi_json['products'][0]['doseInformations'][0]['route_value'] = pvi_json['products'][0]['doseInformations'][0]['route_value'].strip()
            if not re.match('^\d+\s*\)', pvi_json['products'][0]['doseInformations'][0]['route_value']):
                if pvi_json['products'][1]['doseInformations'][0]['route_value']:
                    pvi_json['products'][0]['doseInformations'][0]['route_value'] = pvi_json['products'][0]['doseInformations'][0]['route_value'] + '' + pvi_json['products'][1]['doseInformations'][0]['route_value']
    except:
        pass
    try:
        if pvi_json['products'][0]['doseInformations'][0]['startDate'] not in [None, '']:
            pvi_json['products'][0]['doseInformations'][0]['startDate'] = pvi_json['products'][0]['doseInformations'][0]['startDate'].strip()
            if not re.match('^\d+\s*\)', pvi_json['products'][0]['doseInformations'][0]['startDate']):
                if pvi_json['products'][1]['doseInformations'][0]['startDate']:
                    pvi_json['products'][0]['doseInformations'][0]['startDate'] = pvi_json['products'][0]['doseInformations'][0]['startDate'] + '' + pvi_json['products'][1]['doseInformations'][0]['startDate']
    except:
        pass
    '''
    pvi_json['products'][0]['doseInformations'][0]['dose_inputValue'] = pvi_json['products'][0]['doseInformations'][0]['dose_inputValue'].strip()
    if not re.match('^\d+\s*\)', pvi_json['products'][0]['doseInformations'][0]['dose_inputValue']):
        if pvi_json['products'][1]['doseInformations'][0]['dose_inputValue']:
            pvi_json['products'][0]['doseInformations'][0]['dose_inputValue'] = pvi_json['products'][0]['doseInformations'][0]['dose_inputValue'] + '' + pvi_json['products'][1]['doseInformations'][0]['dose_inputValue']
        if pvi_json['products'][1]['doseInformations'][0]['route_value']:
            pvi_json['products'][0]['doseInformations'][0]['route_value'] = pvi_json['products'][0]['doseInformations'][0]['route_value'] + '' + pvi_json['products'][1]['doseInformations'][0]['route_value']
        if pvi_json['products'][1]['doseInformations'][0]['startDate']:
            pvi_json['products'][0]['doseInformations'][0]['startDate'] = pvi_json['products'][0]['doseInformations'][0]['startDate'] + '' + pvi_json['products'][1]['doseInformations'][0]['startDate']
    '''
    pvi_json['products'].pop(1)
    return pvi_json


# Process Sender and Narrative Comments
def process_sender_and_narrative_comments(pvi_json):
    if pvi_json['summary']['senderComments'] not in [None, '']:
        pvi_json['summary']['senderComments'] = pvi_json['summary']['senderComments'].replace('Suspect Drugs (Cont...)', '').replace('Suspect Products (Cont...)', '').replace('Product-Reaction level', '').strip()
    if pvi_json['summary']['caseDescription'] not in [None, '']:
        if 'company remarks' in pvi_json['summary']['caseDescription'].lower():
            pvi_json['summary']['caseDescription'] = pvi_json['summary']['caseDescription'].split('Company Remarks')[0].strip()
        if 'suspect drugs (cont...)' in pvi_json['summary']['caseDescription'].lower():
            pvi_json['summary']['caseDescription'] = pvi_json['summary']['caseDescription'].split('Suspect Drugs (Cont...)')[0].strip()
        if 'suspect products (cont...)' in pvi_json['summary']['caseDescription'].lower():
            pvi_json['summary']['caseDescription'] = pvi_json['summary']['caseDescription'].split('Suspect Products (Cont...)')[0].strip()
    return pvi_json


# Process Event section if Reaction information continued is missing on the second page
def process_event_if_reaction_section_is_missing(pvi_json, extracted_json):
    if pvi_json['events'][0]['reportedReaction'] in [None, '']:
        event_name_list = []
        data = ''
        for ind in range(len(extracted_json)):
            if extracted_json[ind]['AnnotID'] == '10027':
                data = extracted_json[ind]['value']
                break
        if data not in [None, '']:
            total_section_data_in_list = get_list_of_list_for_extracted_data(data)
            for index in range(len(total_section_data_in_list[0])):
                if 'causality' in total_section_data_in_list[0][index].lower():
                    causality_start_index = index
                    causality_section = total_section_data_in_list[0][causality_start_index:]
                    event_name_list = get_event_name_from_causality(causality_section)
                    break
        if event_name_list:
            for event_indx in range(len(event_name_list)):
                if event_indx < len(pvi_json['events']):
                    pvi_json['events'][event_indx]['reportedReaction'] = event_name_list[event_indx]
                    pvi_json['events'][event_indx]['seq_num'] = event_indx+1
                else:
                    pvi_json['events'].append(copy.deepcopy(pvi_json['events'][0]))
                    pvi_json['events'][event_indx] = change_reference_values_to_none(pvi_json['events'][event_indx])
                    pvi_json['events'][event_indx]['reportedReaction'] = event_name_list[event_indx]
                    pvi_json['events'][event_indx]['seq_num'] = event_indx + 1
        if pvi_json['message'] not in [None, '']:
            pvi_json['message'] = pvi_json['message'].replace('\n', '')
            pvi_json['message'] = pvi_json['message'].replace(' ', '')
            pvi_json['events'][0]['startDate'] = pvi_json['message']
            pvi_json['message'] = None
    return pvi_json


# Get event name from causality section
def get_event_name_from_causality(causality_section):
    event_name_list = []
    for inner_indx in range(len(causality_section)):
        if re.match('^\s*\d+\s*\)', causality_section[inner_indx]):
            for action_index in range(inner_indx, len(causality_section)):
                if 'with drug' in causality_section[action_index].lower():
                    event_name = ' '.join(causality_section[inner_indx:action_index])
                    event_name_list.append(event_name)
                    break
    for event in range(len(event_name_list)):
        event_name_list[event] = re.sub('^\s*\d+\s*\)', '', event_name_list[event])
    return event_name_list


# Processing outcome
def process_outcome(pvi_json, extracted_json, flag):
    temp = 0
    event_name_list = []
    word_list = ['case', 'report', 'clinical', 'trial', 'study', 'reports']
    if flag:
        data = [x['value'] for x in extracted_json if x['AnnotID'] == '10011'][0]
        for index, data_item in enumerate(data):
            if any(item in data_item.lower() for item in word_list):
                event_first_page_data = data[:index]
                break
    else:
        data = [x['value'] for x in extracted_json if x['AnnotID'] == '10026'][0]
        event_first_page_data = [x['value'] for x in extracted_json if x['AnnotID'] == '10011'][0]
        for index, data_item in enumerate(data):
            if any(item in data_item.lower() for item in word_list):
                event_first_page_data = event_first_page_data + data[:index]
                break
    data_event = [x['value'] for x in extracted_json if x['AnnotID'] == '10027'][0]
    if data_event not in [None, '']:
        total_section_data_in_list = get_list_of_list_for_extracted_data(data_event)
        for index in range(len(total_section_data_in_list[0])):
            if 'causality' in total_section_data_in_list[0][index].lower():
                causality_start_index = index
                causality_section = total_section_data_in_list[0][causality_start_index:]
                event_name_list = get_event_name_from_causality(causality_section)
                break
    event_name_list = [event.strip() for event in event_name_list]
    event_first_page_data = [event.strip() for event in event_first_page_data]
    data_indx = 0
    match_index_list = []
    final_event_data = []
    while data_indx < len(event_first_page_data) and temp < len(event_name_list):
        if event_name_list[temp].split()[0] == event_first_page_data[data_indx].split()[0]:
            match_index_list.append(data_indx)
            temp += 1
            data_indx += 1
        else:
            data_indx += 1
    for index in range(len(match_index_list)):
        if index < len(match_index_list)-1:
            event_data = ' '.join(event_first_page_data[match_index_list[index]:match_index_list[index + 1]])
        else:
            event_data = ' '.join(event_first_page_data[match_index_list[index]:])
        final_event_data.append(event_data)
    for event in range(len(final_event_data)):
        if '-' in final_event_data[event]:
            form_outcome = ""
            form_outcome = final_event_data[event].split('-')[-1].strip()
            check = form_outcome.split(" ")
            check = "".join(check).lower()
            if "notrecovered" in check or "notresolved" in check:
                form_outcome = "Not Recovered / Not Resolved"
            elif "recovered" in form_outcome.lower() or "resolved" in form_outcome.lower():
                form_outcome = "Recovered/resolved"
            pvi_json['events'][event]['outcome'] = form_outcome
    return pvi_json


# Process Event Sequence Number
def process_event_seq_num(pvi_json):
    for index in range(len(pvi_json['events'])):
        pvi_json['events'][index]['seq_num'] = index+1
    return pvi_json


def tests_processing_updated(pvi_json, extracted_json):
    lab = [x['value'] for x in extracted_json if x['AnnotID'] == '10040'][0]
    '''for every in range(len(w1json)):
        if w1json[every]["AnnotID"] == "10040":
            lab = w1json[every]["value"]
            break
    '''
    for header in range(len(lab)):
        lab[header][0].replace("Test name","").strip()
        lab[header][1].replace("Test date","").strip()
        lab[header][2].replace("Test result","").strip()
        lab[header][3].replace("Normal value Classification","").replace("Classification","").replace("Normal value","").strip()
        lab[header][4].replace("Normal value Classification","").replace("Classification","").replace("Normal value","").strip()
        if lab[header][0]=="" and lab[header][1]=="" and lab[header][2]=="" and lab[header][3]=="" and lab[header][4]=="":
            lab[header]==""
    while "" in lab:
            lab.remove("")
    if lab and lab !=[[]]:
        merge_lab = {}
        for every_lab in range(len(lab)):
            if every_lab!=0 and lab[every_lab][0].strip()!="" and lab[every_lab][1].strip()=="" and lab[every_lab][2].strip()=="" and lab[every_lab][3].strip()=="":
                merge_lab[every_lab-1] = every_lab      
        #total_num_lab = len(lab) - len(merge_lab)
        for key, value in merge_lab.items():
            lab[key][0] = lab[key][0].strip() + " " + lab[value][0].strip()
            lab[value] = ""
        while "" in lab:
            lab.remove("") 
        seq_num = 1
        tests = []
        for rgn_lab in lab:
            lab_dates = rgn_lab[1].strip()
            lab_dates_list = lab_dates.split("\n")
            for every_date in range(len(lab_dates_list)):
                lab_dates_list[every_date] = lab_dates_list[every_date].strip()
            while "" in lab_dates_list:
                lab_dates_list.remove("") 
            lab_testresult = rgn_lab[2].strip()
            lab_testresult_list = lab_testresult.split("\n")
            for every_testresult in range(len(lab_testresult_list)):
                lab_testresult_list[every_testresult] = lab_testresult_list[every_testresult].strip()
            while "" in lab_testresult_list:
                lab_testresult_list.remove("") 
            lab_normal = rgn_lab[3].strip()
            lab_normal_list = lab_normal.split("\n")
            for every_normal in range(len(lab_normal_list)):
                lab_normal_list[every_normal] = lab_normal_list[every_normal].strip()
            while "" in lab_normal_list:
                lab_normal_list.remove("") 
            lab_notes = rgn_lab[4].strip()
            lab_notes_list = lab_notes.split("\n")
            for every_note in range(len(lab_notes_list)):
                lab_notes_list[every_note] = lab_notes_list[every_note].strip()
            while "" in lab_notes_list:
                lab_notes_list.remove("") 
            num_row = max(len(lab_dates_list),len(lab_testresult_list),len(lab_normal_list),len(lab_notes_list))
            if num_row == 0:
                num_row = 1
            for every_row in range(num_row):
                pvi_lab = deepcopy(pvi_json["tests"][0])
                pvi_lab["seq_num"] = seq_num
                seq_num = seq_num +1
                pvi_lab["testName"] = rgn_lab[0].strip()
                try:
                    if "/" in lab_dates_list[every_row]:
                        predate = lab_dates_list[every_row]
                        predate = predate.split("/")
                        for everypre in range(len(predate)):
                            predate[everypre] = predate[everypre].strip()
                        predate = "-".join(predate)
                        pvi_lab["startDate"] = predate
                    else:
                        pvi_lab["startDate"] = lab_dates_list[every_row]
                except:
                    pvi_lab["startDate"] = None
                try:
                    pvi_lab["testResult"] = lab_testresult_list[every_row]
                except:
                    pvi_lab["testResult"] = None
                try:
                    pvi_lab["testLow"] = lab_normal_list[every_row]
                except:
                    pvi_lab["testLow"] = None
                try:
                    pvi_lab["testNotes"] = lab_notes_list[every_row]
                except:
                    pvi_lab["testNotes"] = None
                tests.append(pvi_lab)
        pvi_json["tests"] = tests
    return pvi_json


def referenceType(pvi_json):
    pvi_json["references"][0]["referenceType"] = "LP Case Number"
    return pvi_json


def set_study_number(pvi_json, extracted_json):
    center_number = [x['value'] for x in extracted_json if x['AnnotID'] == '10019'][0]
    if center_number:
        study_item = ""
        for every_center in center_number:
            if "study no" in every_center.lower():
                study_item = every_center
                break
        study = study_item.split(":")[1].strip().split(" ")[0]
        if study:
            pvi_json["study"]["studyNumber"] = study
    return pvi_json


def set_patient_id(pvi_json):
    if pvi_json["patient"]["patientId"]:
        pvi_json["patient"]["patientId"] = pvi_json["patient"]["patientId"].split("\n")[0].strip()
        if 'Center No.' in pvi_json['summary']['caseDescription']:
            concatenate_string = pvi_json['summary']['caseDescription'].split('\n')[0].split(':')[-1].strip()
            if not pvi_json['patient']['patientId'].startswith(concatenate_string):
                pvi_json['patient']['patientId'] = concatenate_string + '-' + pvi_json["patient"]["patientId"]
    return pvi_json


# Process Action Taken according to mapping
def process_action_taken(pvi_json):
    for prod in pvi_json['products']:
        if prod['actionTaken']['value'] not in [None, '']:
            if 'dosage maintained' in prod['actionTaken']['value'].lower():
                prod['actionTaken']['value'] = 'Dose Not Changed'
            if 'drug discontinued (temp)' in prod['actionTaken']['value'].lower():
                prod['actionTaken']['value'] = 'Dose Temporarily withdrawn'
    return pvi_json


def valid_date_check(pvi_json):
    for prod in pvi_json['products']:
        for dose in prod['doseInformations']:
            dose['startDate'] = valid_check(dose['startDate'])
            dose['endDate'] = valid_check(dose['endDate'])
    for event in pvi_json['events']:
        event['startDate'] = valid_check(event['startDate'])
    pvi_json['receiptDate'] = valid_check(pvi_json['receiptDate'])
    pvi_json['mostRecentReceiptDate'] = valid_check(pvi_json['mostRecentReceiptDate'])
    for test in pvi_json['tests']:
        test['startDate'] = valid_check(test['startDate'])
    return pvi_json


def valid_check(date):
    months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'sep', 'oct', 'nov', 'dec']
    valid = True
    if date not in [None, '']:
        if len(date.split('-')) == 3:
            if not re.match('\d\d', date.split('-')[0]):
                valid = False
            if date.split('-')[1].lower() not in months:
                valid = False
            if not re.match('\d\d\d\d', date.split('-')[-1]):
                valid = False
        elif len(date.split('-')) == 2:
            if date.split('-')[0].lower() not in months:
                valid = False
            if not re.match('\d\d\d\d', date.split('-')[-1]):
                valid = False
        elif len(date.split('-')) == 1:
            if not re.match('\d\d\d\d', date.split('-')[-1]):
                valid = False
    if not valid:
        return None
    else:
        return date


# Get Final post processed Json
def get_postprocessed_json(pvi_json, w1json):
    try:
        pvi_json = process_patient_age(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_patient_initials(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_first_receipt_date(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_single_product_on_first_page(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json, suspect_len = process_product_reaction_level_data(pvi_json, w1json)
    except Exception as e:
        pass
    try:
        pvi_json, flag = process_first_page_describe_reaction(pvi_json, w1json)
    except Exception as e:
        pass
    try:
        pvi_json = process_second_page_describe_reaction(pvi_json, w1json, flag)
    except Exception as e:
        pass
    try:
        pvi_json = process_concomitant_first_page(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_other_relevant_history(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = tests_processing_updated(pvi_json, w1json)
    except Exception as e:
        pass
    try:
        pvi_json = update_report_source(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_reporter(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_route_and_dose_value(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_indication_reported_reaction(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_product_name(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_product_start_end_date(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_country(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_sender_and_narrative_comments(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_event_if_reaction_section_is_missing(pvi_json, w1json)
    except Exception as e:
        pass
    try:
        pvi_json = process_event_name_reported_reaction_and_coded(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_event_seriousnesss(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_event_start_dates(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_outcome(pvi_json, w1json, flag)
    except Exception as e:
        pass
    try:
        pvi_json = process_event_seq_num(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = referenceType(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = set_study_number(pvi_json, w1json)
    except Exception as e:
        pass
    try:
        pvi_json = set_patient_id(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = process_action_taken(pvi_json)
    except Exception as e:
        pass
    try:
        pvi_json = valid_date_check(pvi_json)
    except Exception as e:
        pass
    return pvi_json
