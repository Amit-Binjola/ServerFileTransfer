import re
import pandas as pd
import traceback
from datetime import datetime


class PostProcessedJson:
    def __init__(self, pvi_json, extracted_df):
        self.pvi_json = pvi_json
        self.extracted_df = extracted_df
        self.na_pattern = "Nothing|Unknown|Blank|N/A"
        self.products_list = set()

    @staticmethod
    def date_format(given_date):
        date, timestamp = None, None
        try:
            date, timestamp = given_date.split(" ")
        except ValueError:
            date = given_date
        try:
            day, month, year = date.split('.')
            dmy = day + "-" + month + "-" + year
            dt = datetime.strptime(dmy, "%d-%m-%Y").strftime("%d-%b-%Y").upper()
        except ValueError:
            month, year = date.split('.')
            my = month + "-" + year
            dt = datetime.strptime(my, "%m-%Y").strftime("%b-%Y").upper()
        if timestamp and timestamp != "00:00:00":
            dt = dt + " " + timestamp
        return dt

    def event_date(self):
        start_date = PostProcessedJson.get_annotation_value(self.extracted_df, 'Date of event')[0].strip()
        for event_index in range(len(self.pvi_json["events"])):
            dt = PostProcessedJson.date_format(start_date)
            self.pvi_json["events"][event_index]["startDate"] = dt
        return self.pvi_json

    def receipt_date(self):
        receipt_date = PostProcessedJson.get_annotation_value(self.extracted_df, "Date of first contact")[0].strip()
        dt = PostProcessedJson.date_format(receipt_date)
        self.pvi_json["receiptDate"] = dt
        return self.pvi_json

    @staticmethod
    def parse_reported_reaction(reaction):
        if reaction:
            reaction_list = reaction.split('\n')
            reaction = "".join(reaction_list[:2])
        return reaction

    def ischecked(self, annotation):
        #return df.loc[annotation]['value'] == ["1"]
        return self.extracted_df.loc[annotation]['value'] == ["1"]

    @staticmethod
    def get_annotation_value(df, annotation):
        return df.loc[annotation]['value']

    @staticmethod
    def strip_junk_char(inp_string):
        if inp_string:
            out_string = inp_string.replace("\n", "").strip(" { } ( ) \ / ; . [ ] , - : ")
            return out_string
        else:
            return inp_string

    def reported_reaction(self):
        events = self.pvi_json["events"]
        for event_index in range(len(events)):
            reaction = PostProcessedJson.parse_reported_reaction(events[event_index]["reportedReaction"])
            self.pvi_json["events"][event_index]["reportedReaction"] = reaction
        return self.pvi_json

    def set_country(self):
        country = PostProcessedJson.get_annotation_value(self.extracted_df, 'Place of event')[0]
        self.pvi_json["patient"]["country"] = country
        return self.pvi_json

    def medical_history(self):
        history_note = "Duration Unknown"
        if self.ischecked('Diabetic < 1 Cb'):
            history_note = "< 1 Years"
        elif self.ischecked('Diabetic 1 -  5 CB'):
            history_note = "1 - 5 Years"
        elif self.ischecked('Diabetic 6 - 15 CB'):
            history_note = "6 - 15 Years"
        elif self.ischecked('Diabetic longer CB'):
            history_note = "Longer than 15 Years"
        elif self.ischecked('Diabetic NA'):
            history_note = "Duration Unknown"
        self.pvi_json["patient"]["medicalHistories"][0]["historyNote"] = history_note
        return self.pvi_json

    def set_sender_comments(self):
        """self.pvi_json["summary"]["nativeLanguage"] = list()
        native_language = self.pvi_json["summary"]["nativeLanguage"]
        native_language_dict = {"reporterComments": None, "caseDescription": None, "nativeLanguageId": 0,
                                "senderComments": None}"""
        sender_comments = PostProcessedJson.get_annotation_value(self.extracted_df, 'Main complained Product')[0]
        product = sender_comments[1]
        serial_num = sender_comments[-1]
        if re.search(self.na_pattern, serial_num, re.IGNORECASE) and re.search("YpsoPump", product, re.IGNORECASE):
            comments="Serial number of pump: Not available"
        else:
            comments=product + " - " + serial_num
        self.pvi_json["summary"]["senderComments"] = None  #comments
        self.pvi_json["summary"]["reporterComments"] = comments
        """native_language_dict["reporterComments"] = comments
        native_language_dict["caseDescription"] = self.pvi_json["summary"]["caseDescription"]
        native_language_dict["nativeLanguageId"] +=1
        native_language.append(native_language_dict)
        self.pvi_json["summary"]["nativeLanguage"] = native_language"""
        return self.pvi_json

    def get_attached_products_info(self):
        products_info  = dict()
        product_set = set()
        main_complaint_product = PostProcessedJson.get_annotation_value(self.extracted_df, "Main complained Product")[0][1]
        product_brand = self.get_product_brand()
        attached_products = PostProcessedJson.get_annotation_value(self.extracted_df, "Attached_products")

        for product in attached_products:
            product[1] = product[1].replace("\n", "")
            if main_complaint_product in product[1] or "Ypsopump" in product[1] or product_brand in product[1]:
                continue
            elif re.match("[^a-zA-Z\d\s]", product[1]):
                continue
            else:
                if product[1] in self.products_list:
                    continue
                    #res = products_info[product[1]].append([product[-1]])
                else:
                    self.products_list.add(product[1])
                    products_info[product[1]] = [product[-1]]
        return products_info

    def get_product_brand(self):
        license_value = ""
        if self.ischecked('brand fiasp CB'):
            license_value = "Fiasp PumpCart"
        elif self.ischecked('brand lyumjev CB'):
            license_value = "Lyumjev"
        elif self.ischecked('brand humalog CB'):
            license_value = "Humalog"
        elif self.ischecked('brand apidra CB'):
            license_value = "Apidra"
        elif self.ischecked('brand sanofi CB'):
            license_value = "Sanofi Lispro"
        elif self.ischecked('brand novo rapid CB'):
            license_value = "NovoRapid PumpCart"
        elif self.ischecked('brand novo rapid prefilled CB') or \
                self.ischecked("Brand NA") or self.ischecked("Brand other"):
            license_value = "NovoRapid PumpCart"
        return license_value

    def get_all_attached_product_list(self):
        from copy import deepcopy
        product_dict = deepcopy(self.pvi_json["products"][0])
        products_len = len(self.pvi_json["products"])
        attached_products = self.get_attached_products_info()
        all_attached_product_list = []
        for key, values in attached_products.items():
            product_dict["seq_num"] = products_len + 1
            product_dict["license_value"] = key
            for idx in range(len(values)):
                if not re.match(self.na_pattern, values[idx], re.IGNORECASE):
                    product_dict["doseInformations"][idx]["customProperty_batchNumber_value"] = values[idx]
            all_attached_product_list.append(product_dict)
        return all_attached_product_list

    def pre_process_product(self):
        products = self.pvi_json["products"]
        pre_processed_products = []
        seq_num = 0
        for idx in range(len(products)):
            license = products[idx]["license_value"]
            license = license.replace("\n", "")
            license = re.sub(r'[^A-Za-z0-9 ]+', '', license)
            if license and license not in self.products_list:
                self.products_list.add(license)
                products[idx]["seq_num"] = seq_num
                seq_num += 1
                for index in range(len(products[idx]["doseInformations"])):
                    batch_num = products[idx]["doseInformations"][index]["customProperty_batchNumber_value"]
                    if batch_num:
                        batch_num = batch_num.replace("\n", "")
                        batch_num = re.sub(r"[^A-Za-z0-9 ]+", "", batch_num)
                        if re.match(self.na_pattern,  batch_num, re.IGNORECASE):
                            batch_num=None
                        products[idx]["doseInformations"][index]["customProperty_batchNumber_value"]=batch_num
                    else:
                        pass
                pre_processed_products.append(products[idx])
            else:
                continue
        self.pvi_json["products"] = pre_processed_products
        return

    def patient_age(self):
        self.pvi_json["patient"]['age']['inputValue'] = ""
        if self.ischecked('AGE 19 -34 CB'):
            self.pvi_json["patient"]['age']['inputValue'] = "Adult"
        elif self.ischecked('Age 35 - 64 CB'):
            self.pvi_json["patient"]['age']['inputValue'] = "Adult"
        elif self.ischecked('Age ≥ 80 CB'):
            self.pvi_json["patient"]['age']['inputValue'] = "Elderly"
        return self.pvi_json

    def bg_test_during_event(self):
        bg_value = " ".join(self.get_annotation_value(self.extracted_df, "BG level during accurate"))
        if bg_value:
            try:
                bg_value = bg_value.split(":")[1]
                bg_value = re.sub(r'[^A-Za-z0-9<>]+', '', bg_value)
            except:
                bg_value = None
        mgdl = self.ischecked("bg level mg_aksh")
        mmol = self.ischecked("mmol_aksh")
        na = self.ischecked("BG level NA CB")
        test_dict = self.empty_lab_dict()
        test_dict["testName"] = "Blood glucose" if bg_value else None
        #test_dict["testHigh"] = bg_value if bg_value and (mgdl or mmol) else None
        test_dict["testLow"] = bg_value
        test_dict["testResult"] = bg_value if bg_value and not mgdl and not mmol else None
        if mgdl:
            test_dict["testResultUnit"] = "MG/DL" if mgdl else None
        elif mmol:
            test_dict["testResultUnit"] = "mmol/L"
        else:
            test_dict["testResultUnit"] = None
        test_dict["testNotes"] = "BG level during event" if bg_value else None
        isempty = self.islabtest_empty(test_dict)
        if isempty:
            return None
        else:
            return test_dict


    def ketone_test(self):
        ketone_value = " ".join(self.get_annotation_value(self.extracted_df, "Ketone accurate"))
        if ketone_value:
            try:
                ketone_value = ketone_value.split(":")[1]
                ketone_value = re.sub(r'[^A-Za-z0-9<>]+', '', ketone_value)
            except:
                ketone_value = None
        mgdl = self.ischecked("Ketone MG CB")
        mmol = self.ischecked("Ketone mmol CB")
        na = self.ischecked("ketone na")
        dr = self.ischecked("ketone dr cb")
        pt = self.ischecked("ketone dr cb")
        test_dict = self.empty_lab_dict()
        test_dict["testName"] = "Ketones" if ketone_value else None
        #test_dict["testHigh"] = ketone_value if ketone_value and (mgdl or mmol) else None
        test_dict["testLow"] = ketone_value
        test_dict["testResult"]=ketone_value if ketone_value and not mgdl and not mmol else None
        if mgdl:
            test_dict["testResultUnit"]="MG/DL" if mgdl else None
        elif mmol:
            test_dict["testResultUnit"] = "mmol/L"
        else:
            test_dict["testResultUnit"] = None
        test_dict["testNotes"] = "Ketone value during event" if ketone_value else None
        isempty = self.islabtest_empty(test_dict)
        if isempty:
            return None
        else:
            return test_dict

    def bg_test_after_intervention(self):
        bg_value = " ".join(self.get_annotation_value(self.extracted_df, "BG after intervention Accurate "))
        if bg_value:
            try:
                bg_value = bg_value.split(":")[1]
                bg_value = re.sub(r'[^A-Za-z0-9<>]+', '', bg_value)
            except:
                bg_value = None
        mgdl = self.ischecked("BG after intervention MG CB")
        mmol = self.ischecked("BG after intervention mmol CB")
        na = self.ischecked("BG after intervention NA CB")
        test_dict = self.empty_lab_dict()
        test_dict["testName"] = "Blood glucose" if bg_value else None
        #test_dict["testHigh"] = bg_value if bg_value and (mgdl or mmol) else None
        test_dict["testLow"] = bg_value
        test_dict["testResult"] = bg_value if bg_value and not mgdl and not mmol else None
        if mgdl:
            test_dict["testResultUnit"] = "MG/DL"
        elif mmol:
            test_dict["testResultUnit"] = "mmol/L"
        else:
            test_dict["testResultUnit"] = None
        test_dict["testNotes"] = "BG level after intevention" if bg_value else None
        isempty = self.islabtest_empty(test_dict)
        if isempty:
            return None
        else:
            return test_dict

    def islabtest_empty(self, labtest_dict):
        if any(labtest_dict.values()):
            return False
        else:
            return True

    @staticmethod
    def empty_lab_dict():
        keys = ["seq_num", "startDate", "testAssessment", "testHigh", "testLow", "testName", "testNotes", "testResult",
                "testResultUnit"]
        return dict.fromkeys(keys, None)

    def lab_tests(self):
        labtest = list()
        bg_test_during_event = self.bg_test_during_event()
        if bg_test_during_event:
            labtest.append(bg_test_during_event)
        keytone_test = self.ketone_test()
        if keytone_test:
            labtest.append(keytone_test)
        bg_test_after_interv = self.bg_test_after_intervention()
        if bg_test_after_interv:
            labtest.append(bg_test_after_interv)
        seq_num = 0
        for test in labtest:
            seq_num += 1
            test["seq_num"]  = seq_num
        self.pvi_json["tests"] = labtest
        return self.pvi_json

    def reporter_qualification(self):
        patient = self.ischecked("Contacted by whom Pt cb")
        medical_person = self.ischecked("Contacted by whom Medical Cb")
        other = self.ischecked("Contacted by whom Other cb")
        reporter = self.pvi_json["reporters"]
        cnt = len(reporter)
        for idx in range(cnt):
            if patient or other:
                self.pvi_json["reporters"][idx]["qualification"] = "Consumer or Other Non Health professional"
            elif medical_person:
                self.pvi_json["reporters"][idx]["qualification"] = "Other Health care professional"
        return self.pvi_json

def get_postprocessed_json(pvi_json, extracted_json):
    extracted_df = pd.DataFrame(extracted_json)
    extracted_df.set_index('class', inplace=True)
    print(extracted_df)
    ppj = PostProcessedJson(pvi_json, extracted_df)
    try:
        pvi_json = ppj.reported_reaction()
    except:
        traceback.print_exc()
    try:
        pvi_json = ppj.event_date()
    except:
        traceback.print_exc()
    try:
        pvi_json = ppj.receipt_date()
    except:
        traceback.print_exc()
    try:
        pvi_json = ppj.set_country()
    except:
        traceback.print_exc()
    try:
        pvi_json = ppj.medical_history()
    except:
        traceback.print_exc()
    try:
        ppj.set_sender_comments()
    except:
        traceback.print_exc()
    try:
        ppj.pre_process_product()
    except:
        traceback.print_exc()
    try:
        ppj.patient_age()
    except:
        traceback.print_exc()
    try:
        ppj.lab_tests()
    except:
        traceback.print_exc()
    try:
        ppj.reporter_qualification()
    except:
        traceback.print_exc()
    return pvi_json
