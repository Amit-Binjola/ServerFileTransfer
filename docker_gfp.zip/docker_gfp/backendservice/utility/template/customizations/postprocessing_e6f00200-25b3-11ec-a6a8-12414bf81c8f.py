import json
import re
import traceback

import numpy as np
import pandas as pd
# OUTPUT_JSON = "input_values.JSON"
# OUTPUT_JSON = "pvi_json.json"
# OUTPUT_JSON = "Seriouspvi.json"
# INTERMEDIATE_JSON = "input_values1.json"
# INTERMEDIATE_JSON = "change_date.json"
# INTERMEDIATE_JSON = "problem_inter.json"
# INTERMEDIATE_JSON = "repeating.json"
# INTERMEDIATE_JSON = "Serious_intermediate.json"
# INTERMEDIATE_JSON = "int_serious.json"
#
# with open(OUTPUT_JSON, "rb") as myfile:
#     data = json.load(myfile)
#
# with open(INTERMEDIATE_JSON, "rb") as inter_file:
#     inter_data = json.load(inter_file)

MONTH_MAPPINGS = {1:'JAN',2:'FEB',3:'MAR',4:'APR',5:'MAY',6:'JUN',7:'JUL',8:'AUG',9:'SEP',10:'OCT',11:'NOV',12:'DEC'}

class MakeRegex:
    @staticmethod
    def make_start_regex(input_keys):
        regex = "("
        for value in input_keys:
            regex = regex + "^" + value + "|"
        regex = regex + ")"
        return regex

    @staticmethod
    def make_between_regex(input_values):
        regex = "["
        for val in input_values:
            regex = regex + val
        regex = regex + "]"
        return regex

    @staticmethod
    def make_word_regex(find_words):
        regex = r""
        for i, word in enumerate(find_words):
            if i < len(find_words)-1:
                regex = regex + r"\b" + word + r"\b|"
            else:
                regex = regex + r"\b" + word + r"\b"

        return regex

    @staticmethod
    def generate_digit_regex(max_digits = 4):
        regex = r"\d{" + str(max_digits) + ",}"
        return regex
    @staticmethod
    def generate_numeric_regex():
        regex = r"[.]?[\d][a-zA-Z]*"
        return regex

def remove_null_license_values(pvi_json):
    product_json = pvi_json["products"]
    temp_product = []
    remove_section = [" ", "NO", "N/A", "FALSE", "YES", "TRUE", "  ", "null"]
    for product in product_json:
        if product["license_value"] is not None:
            if product["license_value"].upper() not in remove_section:
                temp_product.append(product)
    pvi_json["products"] = temp_product
    return pvi_json


def filter_license_value(pvi_json):
    product_json = pvi_json["products"]
    temp_product = []
    possible_values = ["YES,", "TRUE,", "yes,", "true,"]
    regex = MakeRegex.make_start_regex(possible_values)
    for product in product_json:
        text = re.sub(regex, "", product["license_value"])
        product["license_value"] = text
        temp_product.append(product)
    pvi_json["products"] = temp_product
    return pvi_json

def find_in_whole_document(inter_data, string_to_search):
    is_found = False
    regex = MakeRegex.make_word_regex(string_to_search)
    for field in inter_data:
        if type(field["value"]) == dict:
            string = " ".join(field["value"].values())
            match = re.findall(regex, string)
            if len(match)!=0:
                is_found = True
                break
        elif type(field["value"]) == list:
            for val in field["value"]:
                if type(val)==list:
                    string = " ".join(s for s in val)
                    match = re.findall(regex, string)
                    if len(match)!=0:
                        is_found = True
                elif type(val) == str:
                    match = re.findall(regex, val)
                    if len(match)!=0:
                        is_found = True
                        break
    return is_found

def find_word_in_string(input_string, input_words):
    found = False
    regex = MakeRegex.make_word_regex(input_words)
    match = re.findall(regex, input_string)
    if len(match) != 0:
        found = True
    return found


def seperate_license_value(pvi_json, inter_data):
    product_json = pvi_json["products"]
    accu_word_list = ["Cartridge", "Accu-Chek", "pre-filled", "Insight"]
    FIASP_word = ["FIASP"]
    temp_dict = []
    possible_separation = [",", ";", "|", "/"]
    regex = MakeRegex.make_between_regex(possible_separation)
    novo_found = False
    for product in product_json:
        names = re.split(regex, product["license_value"])
        for count, name in enumerate(names):
            sample = product.copy()
            if find_word_in_string(name, accu_word_list) and not novo_found:
                if find_in_whole_document(inter_data, FIASP_word):
                    sample["license_value"] = "FIASP"
                    sample["seq_num"] = 0
                    temp_dict.append(sample)
                    novo_found = True
                else:
                    sample["license_value"] = "NovoRapid Pumpcart"
                    sample["seq_num"] = 0
                    temp_dict.append(sample)
                    novo_found = True
            elif find_word_in_string(name, accu_word_list) and novo_found:
                pass
            else:
                if len(name)>3 and name is not None and name.lower() != "person":
                    sample["license_value"] = name
                    sample["seq_num"] = count + 1
                    temp_dict.append(sample)
    pvi_json["products"] = temp_dict
    return pvi_json

def convert_date(date):
    seprations = [".", "/","-"]
    regex = MakeRegex.make_between_regex(seprations)
    splitted = re.split(regex,date)
    month = ""
    try:
        month = splitted[1]
        month_number = int(splitted[1])
        if month_number in MONTH_MAPPINGS.keys():
            month = MONTH_MAPPINGS[month_number]
            splitted[1] = month
        return "-".join(splitted)
    except Exception as e:
        return date


def get_PRI_aware_date(pvi_json, inter_data):
    PRI_date = ["PRI Become Aware Date"]
    local_date = ["Local Complaint Created Date"]
    PRI_regex = MakeRegex.make_word_regex(PRI_date)
    local_regex = MakeRegex.make_word_regex(local_date)
    PRI_date_value = ""
    local_date_value = ""
    for field in inter_data:
        if type(field["value"]) == dict:
            string = " ".join(field["value"].keys())
            PRI_match = re.findall(PRI_regex, string)
            local_match = re.findall(local_regex, string)
            if len(PRI_match)!=0:
                PRI_date_value = field["value"][PRI_date[0]]
            if len(local_match)!=0:
                local_date_value = field["value"][local_date[0]]
        if (len(PRI_date_value)>=3 and len(local_date_value)>3):
            break
    seprations = [".", "/"]
    regex = MakeRegex.make_between_regex(seprations)
    if PRI_date_value != "":
        date = "-".join(re.split(regex,PRI_date_value))
        date = convert_date(date)
        pvi_json["receiptDate"] = date
    else:
        date = "-".join(re.split(regex, local_date_value))
        date = convert_date(date)
        pvi_json["receiptDate"] = date
    return pvi_json

def get_first_last_name(pvi_json, inter_data):
    customer_strings = ["Customer data"]
    customer_regex = MakeRegex.make_word_regex(customer_strings)
    name = ""
    for data in inter_data:
        class_data = data["class"]
        match = re.findall(customer_regex, class_data)
        if len(match)!=0:
            value = data["value"]["First Name"]
            if len(value)>1:
                name = name + value[0].upper()
            value = data["value"]["Last Name"]
            if len(value)>1:
                name = name + value[0].upper()
    pvi_json["patient"]["name"] = name
    return pvi_json

def get_event_reported_reaction(pvi_json, inter_data):
    all_events = pvi_json["events"]
    temp_event = []
    possible_separation = [",", ";", "|", "/"]
    regex = MakeRegex.make_between_regex(possible_separation)
    count = 0
    for event in all_events:
        reported_reaction = event["reportedReaction"]
        splitted_reactions = re.split(regex, reported_reaction)
        for reaction in splitted_reactions:
            sample = event.copy()
            sample["reportedReaction"] = reaction
            sample["seq_num"] = count +1
            count = count +1
            temp_event.append(sample)
    pvi_json["events"] = temp_event
    return pvi_json


def add_patient_country(pvi_json):
    all_events = pvi_json["events"]
    reported_country = ""
    for event in all_events:
        reported_country = event["country"]
        if reported_country != "":
            break
    pvi_json["patient"]["country"] = reported_country
    return pvi_json


def get_filtered_products(pvi_json):
    product_json = pvi_json["products"]
    temp_product = []
    sequences = []
    for product in product_json:
        sequence_number = product['seq_num']
        if sequence_number is not None:
            sequences.append(int(sequence_number))
            temp_product.append(product)
    temp_products = np.array(temp_product)[np.argsort(sequences)].tolist()
    pvi_json["products"] = temp_products
    return pvi_json

def get_event_start_date(pvi_json, inter_data):
    search_str = ["Date", "Event", "Occurred"]
    # event_date = pvi_json['events']["startDate"]
    seprations = [".", "/", "-"]
    date_regex = MakeRegex.make_between_regex(seprations)
    regex = MakeRegex.make_word_regex(search_str)
    date = ""
    date_found = False
    for fields in inter_data:
        field_type = fields["class"]
        if field_type == "Date":
            values = fields["value"]
            if type(values)== dict:
                keys = values.keys()
                for key in keys:
                    matched = re.findall(regex,key)
                    if len(matched)>=2:
                        date_value = values[key]
                        date = "-".join(re.split(date_regex, date_value))
                        date = convert_date(date)
                        date_found = True
                    if date_found:
                        break
        if date_found:
            break
    events = pvi_json['events']
    temp_dict = []
    for event in events:
        event["startDate"] = date
        temp_dict.append(event)
    pvi_json['events'] = temp_dict
    return pvi_json

# Phase 2


def get_complaint_ID(pvi_json, inter_data):
    search_string = ["complaint", "Complaint", "Reference Id", "Reference ID", "Complaint ID", "complaint id"]
    regex = MakeRegex.make_word_regex(search_string)
    data_found = False
    complaint_no = ""
    for fields in inter_data:
        field_type = fields["class"]
        matched = re.findall(regex, field_type)
        if len(matched) >= 1:
            complaint_no = " ".join(fields["value"].values())
            data_found = True
        if data_found:
            break
    pvi_json["senderCaseUid"] = complaint_no
    return pvi_json


def get_source_type(pvi_json, inter_data):
    """search_string = ["Source", "source"]
    source_key = ["Complaint Source", "Complaint", "complaint", "Source", "source"]
    source_regex = MakeRegex.make_word_regex(source_key)
    regex = MakeRegex.make_word_regex(search_string)
    data_found = False
    source_type = ""
    for fields in inter_data:
        field_type = fields["class"]
        matched = re.findall(regex, field_type)
        if len(matched) >= 1:
            all_keys = fields["value"].keys()
            for key in all_keys:
                source_match = re.findall(source_regex, key)
                if len(source_match) >= 1:
                    source = fields["value"][key]
                    if len(source)>=2:
                        source_type = source
                        data_found = True
                if data_found:
                    break
        if data_found:
            break
    if len(source_type)>=2:
        pvi_json["sourceType"] = [{"value": "Consumer", "value_acc": 0.95}]
    else:
        pvi_json["sourceType"] = []"""
    pvi_json["sourceType"] = [{"value": "Spontaneous", "value_acc": 0.95}]
    return  pvi_json


def get_sender_comments(pvi_json):
    # Reverting native language change
    """pvi_json["summary"]["nativeLanguage"] = list()
    native_language = pvi_json["summary"]["nativeLanguage"]
    native_language_dict = {"reporterComments": None, "caseDescription": None, "nativeLanguageId": 0,
                            "senderComments": None}
    """
    comments = ""
    reporter_comments = pvi_json['summary']['senderComments']
    digit_regex = MakeRegex.generate_digit_regex(max_digits=5)
    if reporter_comments is not None:
        match = re.findall(digit_regex, reporter_comments)
        if len(match) >= 1:
            comments = "Accu-Chek Insight insulin pump" + " - " + str(match[0])
            # pvi_json["summary"]["senderComments"] = None
            # pvi_json['summary']['reporterComments'] = "Accu-Chek Insight insulin pump" + " - " + str(match[0])
            # pvi_json['summary']['nativeLanguage']['reporterComments'] = "Accu-Chek Insight insulin pump" + " - " + str(
            #     match[0])
        else:
            comments = "Serial number of pump: Not available"
            # pvi_json["summary"]["senderComments"] = None
            # pvi_json['summary']['reporterComments'] = "Serial number of pump: Not available"
            # pvi_json['summary']['nativeLanguage']['reporterComments'] = "Serial number of pump: Not available"
    """
    native_language_dict["reporterComments"] = comments
    native_language_dict["caseDescription"] = pvi_json["summary"]["caseDescription"]
    native_language_dict["nativeLanguageId"] += 1
    native_language.append(native_language_dict)
    pvi_json["summary"]["nativeLanguage"] = native_language
    """
    pvi_json['summary']['reporterComments'] = comments
    pvi_json['summary']['senderComments'] = None
    # sender_comments = pvi_json["summary"]["senderComments"]
    # reporter_comments = pvi_json['summary']['reporterComments']
    # pvi_json["summary"]["nativeLanguage"] = {"reporterComments": None, "caseDescription": None}
    # digit_regex = MakeRegex.generate_digit_regex(max_digits=5)
    # if sender_comments is not None:
    #     match = re.findall(digit_regex, sender_comments)
    #     # pvi_json['summary']['nativeLanguage'] = None
    #     if len(match)>=1:
    #         pvi_json["summary"]["senderComments"] = None
    #         pvi_json['summary']['reporterComments'] = "Accu-Chek Insight insulin pump" + " - " + str(match[0])
    #         pvi_json['summary']['nativeLanguage']['reporterComments'] = "Accu-Chek Insight insulin pump" + " - " + str(match[0])
    #     else:
    #         pvi_json["summary"]["senderComments"] = None
    #         pvi_json['summary']['reporterComments'] = "Serial number of pump: Not available"
    #         pvi_json['summary']['nativeLanguage']['reporterComments'] = "Serial number of pump: Not available"
    # elif reporter_comments is not None:
    #     match = re.findall(digit_regex, reporter_comments)
    #     # pvi_json['summary']['nativeLanguage'] = None
    #     if len(match) >= 1:
    #         pvi_json["summary"]["senderComments"] = None
    #         pvi_json['summary']['reporterComments'] = "Accu-Chek Insight insulin pump" + " - " + str(match[0])
    #         pvi_json['summary']['nativeLanguage']['reporterComments'] = "Accu-Chek Insight insulin pump" + " - " + str(
    #             match[0])
    #     else:
    #         pvi_json["summary"]["senderComments"] = None
    #         pvi_json['summary']['reporterComments'] = "Serial number of pump: Not available"
    #         pvi_json['summary']['nativeLanguage']['reporterComments'] = "Serial number of pump: Not available"
    return pvi_json


def get_referene_type(pvi_json, inter_data):
    search_string = ["complaint", "Complaint", "Reference Id", "Reference ID", "Complaint ID", "complaint id"]
    regex = MakeRegex.make_word_regex(search_string)
    data_found = False
    complaint_no = ""
    for fields in inter_data:
        field_type = fields["class"]
        matched = re.findall(regex, field_type)
        if len(matched) >= 1:
            complaint_no = " ".join(fields["value"].values())
            data_found = True
        if data_found:
            break
    references = pvi_json["references"]
    temp_reference = []
    for reference in references:
        reference["referenceType"] = "Complaint ID"
        temp_reference.append(reference)
    pvi_json["references"] = temp_reference
    return pvi_json


def get_dose_information(pvi_json, inter_json):
    product_json = pvi_json["products"]
    accu_word_list = ["Cartridge", "A-C", "Insight"]
    temp_dict = []
    cartridge_regex = MakeRegex.make_word_regex(accu_word_list)
    # possible_separation = [",", ";", "|", "/"]
    # regex = MakeRegex.make_between_regex(possible_separation)
    novo_found = False
    value = ""
    for value in inter_json:
        value_class = value["class"]
        if value_class=="Product_Table":
            all_values = value["value"]
            for prod_value in all_values:
                for str_value in prod_value:
                    matched = re.findall(cartridge_regex, str_value)
                    if len(matched) >= 3:
                        value = prod_value[1]
                        novo_found = True
                        break
                if novo_found:
                    break
            if novo_found:
                break
        if novo_found:
            break
    accu_word_list = ["Accu-Chek", "Insight", "pump"]
    acc_regex = MakeRegex.make_word_regex(accu_word_list)
    matches = re.findall(acc_regex, value)
    if len(matches)>=2:
        pvi_json["products"][0]["doseInformations"][0]["customProperty_batchNumber_value"] = None
    else:
        pvi_json["products"][0]["doseInformations"][0]["customProperty_batchNumber_value"] = value
    return pvi_json

def get_product_listing(pvi_json, inter_json, original_pvi):
    all_inter_treatment = []
    yes_list = ['yes,',"Yes,", "YES,","yes","Yes","YES"]
    insuline_list = ["insulin","Insuline","Insulin",]
    yes_regex = MakeRegex.make_word_regex(yes_list)
    insuline_regex = MakeRegex.make_word_regex(insuline_list)
    for field in inter_json:
        if field["class"] == "treatment_kV":
            field_value = " ".join(field["value"].values())
            subtracted_yes = re.sub(yes_regex,"",field_value)
            if len(subtracted_yes)>=3:
                all_inter_treatment.append(subtracted_yes)
        elif field['class'] == "Insulin_product_FT":
            field_value = " ".join(field["value"])
            matched_str = re.findall(insuline_regex, field_value)
            if len(matched_str)>=1:
                all_inter_treatment.append("Insulin")
        elif field['class'] == "other drugs KV":
            field_value = " ".join(field["value"].values())
            # matched_str = re.findall(insuline_regex,field_value)
            if len(field_value)>=1:
                all_inter_treatment.append(field_value)

        #TODO to add the class for last section
    pvi_products = pvi_json["products"]
    first_product = pvi_products[0].copy()
    final_products = []
    final_products.append(first_product)
    for index, product in enumerate(pvi_products):
        if index == 0:
            pass
        else:
            all_inter_treatment.append(product["license_value"])
    unique_values = np.unique(np.array(all_inter_treatment))
    for index, unique_value in enumerate(unique_values):
        sample_dict = original_pvi["products"][0]
        if index+1!=3:
            sample_dict["license_value"] = unique_value.upper()
            sample_dict["role_value"] = "treatment"
            sample_dict["seq_num"] = index +1
            sample_dict["indications"][0]["reportedReaction"] = None
            sample_dict["doseInformations"][0]["route_value"] = None

        elif index+1 == 3:
            sample_dict["license_value"] = unique_value
            sample_dict["role_value"] = "concomitant"
            sample_dict["seq_num"] = index + 1
            sample_dict["indications"][0]["reportedReaction"] = None
            sample_dict["doseInformations"][0]["route_value"] = None
        final_products.append(sample_dict)
        sample_dict = None
    # for val in final_products:
    pvi_json["products"] = final_products
    return pvi_json

def remove_duplicate_products(pvi_json, inter_json):
    licenses = []
    all_products = pvi_json["products"]
    final_licenses = []
    for p in all_products:
        license_value = p["license_value"]
        if license_value not in licenses:
            licenses.append(license_value)
            final_licenses.append(p)
    pvi_json["products"] = final_licenses
    return pvi_json


###Phase 3 Tasks

def modify_event_seriousness(pvi_json, inter_json):
    possible_values = ["NO", "No", "no", "FALSE", "False", "false", "N/A", "Not Specified", "Unknown"]
    regex = MakeRegex.make_word_regex(possible_values)
    final_events = []
    value_found = False
    for ann_id in inter_json:
        if ann_id["class"]=="event_seriousnesss":
            value_found = True
            values = ann_id["value"]
            for value in values:
                if len(value)>1:
                    event_list = pvi_json["events"][0].copy()
                    seriousness_value = [{"value": None, "value_acc": 0.95}]
                    matched = re.findall(regex,value)
                    if len(matched)>=1:
                        seriousness_value[0]['value'] = None
                        # event["seriousnesses"][0]["value"] = None
                    elif value is None or len(value) <= 6:
                        seriousness_value[0]['value'] = None
                        # event["seriousnesses"][0]["value"] = None
                    elif "tal?" in value and len(value) <= 10:
                        seriousness_value[0]['value'] = None
                        # event["seriousnesses"][0]["value"] = None
                    elif len(value) > 10:
                        seriousness_value[0]['value'] = "Hospitalization"
                        # event["seriousnesses"][0]["value"] = "Hospitalization"
                    event_list["seriousnesses"] = seriousness_value
                    final_events.append(event_list)
            if value_found:
                break
    pvi_json["events"] = final_events

    # for index, event in enumerate(events):
        # event_str = event["seriousnesses"][0]["value"]
        # event["seq_num"] = index
        # matched = re.findall(regex, event_str)
        # if len(matched)>=1:
        #     event["seriousnesses"][0]["value"] = None
        # elif event_str is None or len(event_str)<=6:
        #     event["seriousnesses"][0]["value"] = None
        # elif "tal?" in event_str and len(event_str)<=10:
        #     event["seriousnesses"][0]["value"] = None
        # elif event_str.lower() == "hospitalization":
        #     event["seriousnesses"][0]["value"] = None
        # elif "tal?" in event_str and len(event_str)>10:
        #     event["seriousnesses"][0]["value"] = "Hospitalization"
        # elif "tal?" not in event_str:
        #     event["seriousnesses"][0]["value"] = "Hospitalization"
        # final_events.append(event)
    # pvi_json["events"] = final_events
    return pvi_json

def dose_description(pvi_json, inter_json):
    first_product = pvi_json["products"][0]
    none_list = ["No", "NO", "N/A","False","Not Specified", "not specified", "specified"]
    none_regex = MakeRegex.make_word_regex(none_list)
    discontinued_list = ["Discontinued","discontinued"]
    cartrage_change_list = ["changed", "cartridge","nothing","cartridge replaced","customer exchanged the cartridge","No change",
                            "none","changed cartridge","no action taken"]
    unknown = ["unknown","Unknown"]
    increased = ["Dose Increased"]
    decreased = ["Dose Decreased"]
    discnt_regex = MakeRegex.make_word_regex(discontinued_list)
    change_regex = MakeRegex.make_word_regex(cartrage_change_list)
    unknown_regex = MakeRegex.make_word_regex(unknown)
    incr_regex = MakeRegex.make_word_regex(increased)
    decr_regex = MakeRegex.make_word_regex(decreased)
    field_value = ""
    description_value = ""
    for field in inter_json:
        if field["class"] == "Daily_dose_KVP":
            field_value = " ".join(field["value"].values())
            matched = re.findall(none_regex,field_value)
            if len(matched)>=1:
                first_product["doseInformations"][0]["description"] = None
            else:
                first_product["doseInformations"][0]["description"] = field_value
        elif field["class"] == "action_taken_kvp":
            value = " ".join(field["value"].values())
            if len(value)>2:
                discnt_match = re.findall(discnt_regex,value)
                change_match = re.findall(change_regex,value)
                unknown_match = re.findall(unknown_regex,value)
                incr_match = re.findall(incr_regex,value)
                decr_match = re.findall(decr_regex,value)
                if len(discnt_match)>=1:
                    description_value = "DRUG Withdrawn"
                elif len(change_match)>=1:
                    description_value = "Dose not Changed"
                elif len(unknown_match)>=1:
                    description_value = "UNKOWN"
                elif len(incr_match)>=1:
                    description_value = "Dose Increased"
                elif len(decr_match)>=1:
                    description_value = "Dose Reduced"
                else:
                    description_value = "UNKNOWN"
                first_product["actionTaken"]["value"] = description_value
            else:
                description_value = None
                first_product["actionTaken"]["value"] = description_value
    pvi_json["products"][0] = first_product
    return pvi_json

def get_blood_glucuse(pvi_json, inter_json):
    yes_list = ["yes","Yes","YES","No","NO","N/A","True","False","true","false"]
    yes_regex = MakeRegex.make_word_regex(yes_list)
    tests = pvi_json["tests"]
    digits_seq = ["0","1","2","3","4","5","6","7","8","9","."]
    final_list = []
    for field in inter_json:
        if field["class"]=="BG_KV":
            glucose_value = " ".join(field["value"].values())
            remaining = re.sub(yes_regex, "", glucose_value)
            if len(remaining)<=2:
                pvi_json["tests"] = final_list
                break
            else:
                numeric = [(index,n) for index, n in enumerate(remaining) if n in digits_seq]
                number = "".join(remaining[numeric[0][0]:numeric[-1][0]+1])
                unit = remaining[numeric[-1][0]+1:]
                if len(number)>=1 and len(unit)>=1:
                    tests["testName"] = "Blood Glucose"
                    tests["testLow"] = number
                    tests["testResultUnit"] = unit
                elif len(unit)<=1 and len(number)>=1:
                    tests["testName"] = "Blood Glucose"
                    tests["testLow"] = number
                elif len(number)>=1:
                    tests["testName"] = "Blood Glucose"
                    tests["testLow"] = number
                final_list.append(tests)
                pvi_json["tests"] = final_list
                break
    return pvi_json

def modify_product_matrix(pvi_json, inter_json):
    event_matrix = pvi_json["productEventMatrix"][0]["relatednessAssessments"][0]
    final_matrix = []
    if event_matrix["result"]["value"] is None:
        pass
    elif event_matrix["result"]["value"] == "Related":
        event_matrix["result"]["value"] = "Possible"
    elif event_matrix["result"]["value"] == "Not Related":
        event_matrix["result"]["value"] = "Unlikely"
    final_matrix.append(event_matrix)
    pvi_json["productEventMatrix"][0]["relatednessAssessments"] = final_matrix
    return pvi_json

def event_seriosness(pvi_json, extracted_df):
    event_seriousness_data = extracted_df.loc["Case_descp"]["value"]
    event_seriousness = "".join(event_seriousness_data).replace("tal? If", "")
    if event_seriousness:
        value = "Hospitalization"
    else:
        value = None
    events = pvi_json["events"]
    for idx in range(len(events)):
        for seriosness_idx in range(len(events[idx]["seriousnesses"])):
            pvi_json["events"][idx]["seriousnesses"][seriosness_idx]["value"]=value
    return pvi_json

def get_event_description(pvi_json, inter_json):
    events = pvi_json["events"]
    value = ""
    value_found = False
    for field in inter_json:
        if field["class"]=="seriousness_2":
            value = " ".join(field["value"].values())
            value_found = True
        if value_found:
            break
    final_events = []
    for index, event in enumerate(events):
        event["duration"] = {"id": None, "value": "", "inputValue": None}
        if len(value)>2:
            event["duration"]["inputValue"] = value
        final_events.append(event)

    pvi_json["events"] = final_events

    return pvi_json

def reporter_qualification(pvi_json, extracted_df):
    #code_list = ["Consumer or other non health professional", "Lawyer", "Other health professional", "Pharmacist", "Physician"]
    qualification_1 = extracted_df.loc["Reporter_qualification"]["value"].get("'reporter?", "")
    qualification_2 = extracted_df.loc["Reporter_qualification_2"]["value"].get("reporter (e.g.", "")
    #compliant_source  = extracted_df.loc["Source"]["value"].get("Complaint Source", "")
    mapping = {"physician": "Physician",
               "dentist": "Other Healthcare Professional",
               "pharmacist": "Pharmacist",
               "nurse": "Other Healthcare Professional",
               "consumer or other non health professional": "Consumer or other non health professional",
               "lawyer": "Lawyer",
               "other health professional" : "Other health professional"}
    q_val_1, q_val_2 = None, None
    for item in list(mapping.keys()):
        if item in qualification_1.lower():
            q_val_1 = mapping.get(item, "")
    for item in list(mapping.keys()):
        if item in qualification_2.lower():
            q_val_2 = mapping.get(item, "")
    if q_val_2:
        qualification = q_val_2
    elif q_val_1 and not q_val_2:
        qualification = q_val_1
    elif not q_val_1 and not q_val_2:
        qualification = None
    if qualification:
        pvi_json["reporters"][0]["qualification"] = qualification
    return pvi_json

def get_postprocessed_json(pvi_json, inter_data):
    extracted_df = pd.DataFrame(inter_data)
    extracted_df.set_index("class", inplace=True)
    print(extracted_df)
    original_pvi = pvi_json.copy()
    try:
        pvi_json = remove_null_license_values(pvi_json)
    except Exception as e:
        print("Error in Null license value")
    try:
        pvi_json = filter_license_value(pvi_json)
    except Exception as e:
        print(e)
    try:
        pvi_json = seperate_license_value(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_PRI_aware_date(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_first_last_name(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_event_reported_reaction(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = add_patient_country(pvi_json)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_filtered_products(pvi_json)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_event_start_date(pvi_json, inter_data)
    except Exception as e:
        print(e)

    # Phase 2
    try:
        pvi_json = get_complaint_ID(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_source_type(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_sender_comments(pvi_json)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_referene_type(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_dose_information(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_product_listing(pvi_json, inter_data,original_pvi)
    except Exception as e:
        print(e)
    try:
        pvi_json = remove_duplicate_products(pvi_json, inter_data)
    except Exception as e:
        print(e)

    #Phase 3
    # Commented for debugging purpose
    # try:
    #     pvi_json = modify_event_seriousness(pvi_json, inter_data)
    # except Exception as e:
    #     print(e)
    try:
        pvi_json = dose_description(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_blood_glucuse(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = modify_product_matrix(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = get_event_description(pvi_json, inter_data)
    except Exception as e:
        print(e)
    try:
        pvi_json = event_seriosness(pvi_json, extracted_df)
    except Exception as e:
        print(e)
    try:
        pvi_json = reporter_qualification(pvi_json, extracted_df)
    except:
        traceback.print_exc()
    return pvi_json


# get_postprocessed_json(data, inter_data)
# with open("pvi_test.json","w+") as myfile:
#     json.dump(pvi_json,myfile,indent=4)