import cv2
import json
import numpy as np
from config import TEMPLATE_FOLDER, logger
from os import path
from datetime import datetime


def ignoring_bounding_pixels(img, form_config_params):
    bw_thresh = form_config_params["checkbox"]["bw_thresh"]
    btm = int(img.shape[0] - form_config_params["checkbox"]["ignore_pixels_bottom"])
    top = int(form_config_params["checkbox"]["ignore_pixels_top"])
    right = int(img.shape[1] - form_config_params["checkbox"]["ignore_pixels_right"])
    left = int(form_config_params["checkbox"]["ignore_pixels_left"])
    img = img[top:btm, left:right]
    return img, bw_thresh


# to remove text content and keep only boxes
def text_removal(img, BLOCK_SIZE, THRESHOLD_CONSTANT, kernel_length):
    # Detect vertical and horizontal lines
    img = np.array(img)
    img_bin = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, BLOCK_SIZE,
                                    THRESHOLD_CONSTANT)
    img_bin = 255 - img_bin  # Invert the image

    # Defining a kernel length

    # A verticle kernel of (1 X kernel_length), which will detect all the verticle lines from the image.
    vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, kernel_length))

    # A horizontal kernel of (kernel_length X 1), which will help to detect all the horizontal line from the image.
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_length, 1))

    # A kernel of (3 X 3) ones.
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))

    # Morphological operation to detect verticle lines from an image
    img_temp1 = cv2.erode(img_bin, vertical_kernel, iterations=2)

    vertical_lines_img = cv2.dilate(img_temp1, vertical_kernel, iterations=2)

    # Morphological operation to detect horizontal lines from an image
    img_temp2 = cv2.erode(img_bin, horizontal_kernel, iterations=3)
    horizontal_lines_img = cv2.dilate(img_temp2, horizontal_kernel, iterations=4)

    # Weighting parameters, this will decide the quantity of an image to be added to make a new image.
    alpha = 0.5
    beta = 1.0 - alpha
    # This function helps to add two image with specific weight parameter 
    # to get a third image as summation of two image.
    img_final_bin = cv2.addWeighted(vertical_lines_img, alpha, horizontal_lines_img, beta, 0.0)
    img_final_bin = cv2.erode(~img_final_bin, kernel, iterations=2)

    (thresh, img_final_bin) = cv2.threshold(img_final_bin, 120, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

    return img_final_bin


# 0 -> Unchecked, 1 -> Checked
def CountFrequency(my_list):
    # Creating an empty dictionary  
    freq = {items: my_list.count(items) for items in my_list}
    return freq


def closest(filter_second_value, Number):
    aux = [abs(Number - valor) for valor in filter_second_value]
    return aux.index(min(aux))


# ignoring repeated coordinates based on x_pos or y_pos
def filter_cords(cbox_cord, sort_type):
    c_type = 0 if sort_type == "left-to-right" else 1
    THRESHOLD = 12
    cords_filtered = []
    temp = 0
    for cord_index in range(len(cbox_cord)):
        if cord_index == 0 or abs(temp - cbox_cord[cord_index][c_type]) > THRESHOLD:
            cords_filtered.append(cbox_cord[cord_index])
        temp = cbox_cord[cord_index][c_type]
    return cords_filtered


def filter_cords_top_to_bottom(cbox_cord, sort_type):
    c_type = 1
    THRESHOLD = 25
    cords_filtered = []
    temp = 0
    for cord_index in range(len(cbox_cord)):
        if cord_index == 0 or abs(temp - cbox_cord[cord_index][c_type]) > THRESHOLD:
            cords_filtered.append(cbox_cord[cord_index])
        temp = cbox_cord[cord_index][c_type]
    return cords_filtered


def removeSmallComponents(image, threshold):
    # find all your connected components (white blobs in your image)
    nb_components, output, stats, centroids = cv2.connectedComponentsWithStats(image, connectivity=8)
    sizes = stats[1:, -1]
    nb_components = nb_components - 1

    img2 = np.zeros((output.shape), dtype=np.uint8)
    # for every component in the image, you keep it only if it's above threshold
    for indx in range(0, nb_components):
        if sizes[indx] >= threshold:
            img2[output == indx + 1] = 255
    return img2


def sort_list_of_list(tuples):
    sort_position = 0  # 0 means sort list of list based on 1st values of list of list
    tuple_length = len(tuples)
    for tuple_index_outer in range(0, tuple_length):
        for tuple_index_inner in range(0, tuple_length - tuple_index_outer - 1):
            if (tuples[tuple_index_inner][sort_position] > tuples[tuple_index_inner + 1][sort_position]):
                temp = tuples[tuple_index_inner]
                tuples[tuple_index_inner] = tuples[tuple_index_inner + 1]
                tuples[tuple_index_inner + 1] = temp
    return tuples


# ignoring pixels which are part of rectangle box
def filter_white_pixel_index(white_index, edges, WHITE_PIXEL_THRESH_VAL):
    row, col = edges.shape
    filtered_white_position = [list(pix) for pix in white_index if
                               abs(pix[0] - row) > WHITE_PIXEL_THRESH_VAL and abs(pix[1] - col) > WHITE_PIXEL_THRESH_VAL
                               and WHITE_PIXEL_THRESH_VAL < pix[1] < col - int(
                                   WHITE_PIXEL_THRESH_VAL / 2) and WHITE_PIXEL_THRESH_VAL < pix[0] < row - int(
                                   WHITE_PIXEL_THRESH_VAL / 2)]
    return filtered_white_position


# filtering checkbox coordinates if coordinates are overlapping
def filter_overlapping_checkboxes(cbox_cord, OVERLAPPING_THRESH_VAL):
    if len(cbox_cord) == 1:
        filtered_cords = cbox_cord
    else:
        filtered_cords = []
        for cord_indx in range(len(cbox_cord)):
            if cord_indx == 0:
                filtered_cords.append(cbox_cord[cord_indx])
                left = cbox_cord[cord_indx][0]
                top = cbox_cord[cord_indx][1]
            else:
                if abs(left - cbox_cord[cord_indx][0]) > OVERLAPPING_THRESH_VAL and abs(
                        top - cbox_cord[cord_indx][1]) > OVERLAPPING_THRESH_VAL:
                    filtered_cords.append(cbox_cord[cord_indx])
                    left = cbox_cord[cord_indx][0]
                    top = cbox_cord[cord_indx][1]
    return filtered_cords


def filter_overlapping_checkboxes_top_to_bottom(cbox_cord, OVERLAPPING_THRESH_VAL):
    if len(cbox_cord) == 1:
        filtered_cords = cbox_cord
    else:
        filtered_cords = []
        for cord_indx in range(len(cbox_cord)):
            if cord_indx == 0:
                filtered_cords.append(cbox_cord[cord_indx])
                top = cbox_cord[cord_indx][1]
            else:
                if abs(top - cbox_cord[cord_indx][1]) > OVERLAPPING_THRESH_VAL:
                    filtered_cords.append(cbox_cord[cord_indx])
                    top = cbox_cord[cord_indx][1]

    return filtered_cords

# classification is based on number of white pixels
def classify_cbox_using_white_pixels(checkbox_category, img, cord, form_config_params):

    #img, bw_thresh = ignoring_bounding_pixels(img, form_config_params)
    imgcrp = img[cord[1]:cord[1] + cord[3], cord[0]:cord[0] + cord[2]]
    imgcrp = cv2.resize(imgcrp, (60, 60))
    #edges = cv2.Canny(imgcrp, 100, 200)
    '''cv2.imshow("img", edges)
    cv2.waitKey(0)
    cv2.destroyAllWindows()'''
    imgcrp, bw_thresh = ignoring_bounding_pixels(imgcrp, form_config_params)
    imgcrp = 255 - imgcrp
    white_indx = np.argwhere(imgcrp == 255)
    filtered_white_position = filter_white_pixel_index(white_indx, imgcrp, form_config_params["checkbox_constants"]["WHITE_PIXEL_THRESH"])

    if len(filtered_white_position) > form_config_params["checkbox_constants"]["CLASSIFIER_THRESHOLD"]:
        checkbox_category.append("1")
    else:
        checkbox_category.append("0")

    return checkbox_category


# it return a list e.g., [0,1,1]
def multiple_rectangular_checkbox(img, form_config_params):

    width_min = form_config_params['checkbox_params']["rectangle_checkbox"]["width_min"]
    height_min = form_config_params['checkbox_params']["rectangle_checkbox"]["height_min"]
    width_max = form_config_params['checkbox_params']["rectangle_checkbox"]["width_max"]
    height_max = form_config_params['checkbox_params']["rectangle_checkbox"]["height_max"]
    if type(img) is not np.ndarray:
        img = np.ndarray(img)

    checkbox_category = []
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, img = cv2.threshold(img, form_config_params['checkbox_constants']["GRAY_REMOVAL_THRESH"], 255, 0)

    try:
        _, contours, __ = cv2.findContours(img, 1, 2)
    except:
        contours, __ = cv2.findContours(img, 1, 2)
    cbox_cord = []
    for cnt in contours:
        x_pos, y_pos, width, height = cv2.boundingRect(cnt)

        if width >= width_min and height >= height_min and width < width_max and height < height_max:
            cbox_cord.append([x_pos, y_pos, width, height])
    sort_type = "top-to-bottom"  # "left-to-right" # this option should come from config
    if len(cbox_cord) == 0:
        img = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 25, 1)
        noofpixels = img.shape[0]*img.shape[1]
        indx = np.argwhere(img == 255)
        checkbox_category = ["1"]
        if (len(indx)/noofpixels)*100 < 25:
            checkbox_category = ["0"]

    else:
        cbox_cord = filter_cords(cbox_cord, sort_type)

        if sort_type == "left-to-right":
            cbox_cord_all = filter_overlapping_checkboxes(cbox_cord)
        if sort_type == "top-to-bottom":
            cbox_cord_all = filter_overlapping_checkboxes_top_to_bottom(cbox_cord, form_config_params["checkbox_constants"]["OVERLAPPING_COORDINATE_THRESH"])

        cbox_cord = []
        for cord in cbox_cord_all:
            if cord[0] and cord[1]:
                cbox_cord.append(cord)

        if len(cbox_cord) == 0:
            cbox_cord = cbox_cord_all


        if len(cbox_cord) > 1:
            for cord in cbox_cord:
                if cord[0] and cord[1]:
                    checkbox_category = classify_cbox_using_white_pixels(checkbox_category, img, cord, form_config_params)

        elif len(cbox_cord) == 1:
            checkbox_category = classify_cbox_using_white_pixels(checkbox_category, img, cbox_cord[0], form_config_params)

        checkbox_category.reverse()
    return checkbox_category



def round_checkbox_classifier(image):
    checked = 0
    IGNORE_END_PIXELS = 15
    IGNORE_START_PIXELS = 5
    IMG_WIDTH = IMG_HEIGHT = 100
    CLASSIFIER_THRESHOLD = 3000
    img = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    ret, img = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY_INV)
    # Find circles
    circles = cv2.HoughCircles(img, cv2.HOUGH_GRADIENT, 1, 5, param1=40, param2=30, minRadius=0, maxRadius=50)
    # If some circle is found
    if circles is not None:
        # Get the (x, y, r) as integers
        circles = np.round(circles[0, :]).astype("int")
        # loop over the circles
        for (x_cord, y_cord, radius) in circles:
            rectX = (x_cord - radius)
            rectY = (y_cord - radius)
            crop_img = img[rectY + IGNORE_START_PIXELS:int(rectY + 2.5 * radius) - IGNORE_END_PIXELS,
                       rectX + IGNORE_START_PIXELS:int(rectX + 2.5 * radius) - IGNORE_END_PIXELS]
            crop_img = cv2.resize(crop_img, (IMG_HEIGHT, IMG_WIDTH))

            if np.sum(crop_img) > CLASSIFIER_THRESHOLD:
                checked = 1
    return checked


def unusual_round_checkbox(img, TEMPLATE_FOLDER, cbox_type):
    BLACK = 0
    checked = "0"
    WHITE = 255
    IMG_WIDTH = 100
    IMG_HEIGHT = 100
    PIXELS_TO_IGNORE = 15
    CLASSFIER_THRESHOLD = 150
    try:
        img = cv2.resize(img, (IMG_WIDTH, IMG_HEIGHT))
        img = img[PIXELS_TO_IGNORE:-PIXELS_TO_IGNORE, PIXELS_TO_IGNORE:-PIXELS_TO_IGNORE]
        template = cv2.imread(TEMPLATE_FOLDER + "/" + cbox_type + ".png", 0)
        width, height = template.shape[::-1]
        # Apply template Matching
        res = cv2.matchTemplate(img, template, 1)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
        top_left = max_loc
        bottom_right = (top_left[0] + width, top_left[1] + height)
        try:
            for row_index in range(0, img.shape[0]):
                for col_index in range(0, bottom_right[0]):
                    img[row_index, col_index] = WHITE
        except:
            for row_index in range(top_left[0], img.shape[0]):
                for col_index in range(top_left[1], bottom_right[0]):
                    img[row_index, col_index] = WHITE
        img[img < 50] = BLACK
        img = ~img
        if np.sum(img) > WHITE * CLASSFIER_THRESHOLD:
            checked = "1"
    except:
        checked = "0"
    return checked


def crop_img(img, line_coords):
    IGNORE_PIXELS = 2
    img_col_size = img.shape[1] / 2
    left = max([coord for coord in line_coords if coord <= img_col_size])
    right = min([coord for coord in line_coords if coord > img_col_size])
    img = img[:, left + IGNORE_PIXELS:right - IGNORE_PIXELS]
    return img


def remove_vertical_lines(img):
    img = ~img
    # Apply edge detection method on the image
    edges = cv2.Canny(img, 30, 150, apertureSize=3)
    line_coords = []
    # This returns an array of r and theta values 
    lines = cv2.HoughLines(edges, 1, np.pi / 180, 200)
    if np.array(lines).ndim and np.array(lines).size != 0:
        # The below for loop runs till r and theta values
        # are in the range of the 2d array
        for line_num in range(len(lines)):
            for r, theta in lines[line_num]:
                # rcos theta +1000 *sin theta
                line_coords.append(int(np.cos(theta) * r + 1000 * (-np.sin(theta))))

    if len(line_coords) > 0:
        img = crop_img(img, line_coords)

    return img


def cbox_in_table_column(img, checkbox_type):
    cropping_pos = 0
    COLUMN_START_POSITION = 1
    COLUMN_END_POSITION = -1
    ADDITIONAL_PIXELS = 3
    temp_index = 0
    LINE_BREAKE_THRESH = 8
    checked_result = []

    if img is not None:
        img = remove_vertical_lines(img)
        img[img > 10] = 255
        img[img <= 10] = 0
        if len(img.shape) == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        ori_img = img.copy()
        BLOCK_SIZE = 25
        THRESHOLD_CONSTANT = 0
        img = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, BLOCK_SIZE,
                                    THRESHOLD_CONSTANT)

        crp_pos = [0]
        h_line_indx = []
        for row_index in range(0, img.shape[0]):
            if np.sum(255 - img[row_index, :]) > 0:
                if row_index - temp_index > LINE_BREAKE_THRESH:
                    h_line_indx.append(row_index)
                    temp_index = row_index
                    ori_img[row_index:row_index + 1, :] = 0
                    if cropping_pos != 0:
                        cropping_pos = cropping_pos + ADDITIONAL_PIXELS
                    cropped_cell_img = ori_img[cropping_pos:row_index - 1, COLUMN_START_POSITION:-COLUMN_END_POSITION]
                    result = checkbox_classifier(cropped_cell_img, checkbox_type)
                    checked_result.append(result)
                    cropping_pos = row_index
                    crp_pos.append(cropping_pos)

    return checked_result


# checkbox detection and classification
def checkbox_classifier(img, checkbox_type, form_config_params):
    if checkbox_type.lower() in ["multiple_rectangular_checkbox", "rectangle_checkbox", "rectangle checkbox", "rectanglecheckbox", "checkbox"]:
        output = multiple_rectangular_checkbox(img, form_config_params)
    elif checkbox_type.lower() == "circle_checkbox":
        output = round_checkbox_classifier(img)
    elif checkbox_type.lower() == "unusual-round-hand-drawn-n":
        output = unusual_round_checkbox(img, TEMPLATE_FOLDER, "template_N")
    elif checkbox_type.lower() == "unusual-round-hand-drawn-y":
        output = unusual_round_checkbox(img, TEMPLATE_FOLDER, "template_Y")
    else:
        output = ["0"]  # "checkbox type not given"

    return output


#img = cv2.imread("/home/suresh/Desktop/sourcecodes/regeneron_cioms/generic-form-parser/src/all.png", 0)

#op = multiple_rectangular_checkbox(img)
#print(op)
