import json, re
#import boto3
from fuzzywuzzy import fuzz
from botocore.errorfactory import ClientError
from os import system, path
from config import CONFIG_JSON, logger, s3_bucket, s3_ACCESS_KEY, s3_SECRET_KEY, TRUE_CHECK, FALSE_CHECK, BACKEND_FOLDER
from utility_convert_coord import convert_UI_coord_to_plumber
import os


# initialising the s3 client if credentials provided in configuration json
########################################################################################################################
'''
if s3_bucket and s3_ACCESS_KEY and s3_SECRET_KEY:
    s3_client = boto3.client('s3', aws_access_key_id=s3_ACCESS_KEY, aws_secret_access_key=s3_SECRET_KEY)
    s3_resource = boto3.resource('s3', aws_access_key_id=s3_ACCESS_KEY, aws_secret_access_key=s3_SECRET_KEY)
'''
########################################################################################################################

fuzzy_threshold = CONFIG_JSON["fuzzy_threshold"]


# to check whether s3 bucket exists with the given s3 bucket name
def s3_bucket_exists(bucket_name):
    bucket_exists = False
    # s3 = boto3.resource('s3', aws_access_key_id=s3_ACCESS_KEY, aws_secret_access_key=s3_SECRET_KEY)

    if s3_resource.Bucket(bucket_name).creation_date is None:
        logger.warning("s3 bucket does not exist")
    else:
        bucket_exists = True
        logger.info("Bucket exists")
    return bucket_exists


# to check whether a particular file exists in the given s3 bucket
def file_exists_in_s3_bucket(s3_file):
    file_exists = False
    if s3_bucket_exists(s3_bucket):
        try:
            s3_client.head_object(Bucket=s3_bucket, Key=s3_file)
            file_exists = True
        except ClientError:
            # Not found

            logger.warning("file not found in s3")
    return file_exists


# to upload the given file in the given s3 bucket
def upload_to_aws_s3(local_file, s3_file):
    if not s3_bucket_exists(s3_bucket):
        logger.error("Bucket does not exist")
    else:
        try:
            s3_client.upload_file(local_file, s3_bucket, s3_file)
            print("Upload Successful")
            return True
        except FileNotFoundError:
            print("The file was not found")
            return False


# download a file from s3 bucket
def download_from_aws_s3(local_file, s3_file):
    s3_client.download_file(s3_bucket, s3_file, local_file)


# this method has to be improved to apply regex
def header_footer_regex_based(word_cords, page_config, apply_regex_footer):
    if page_config['pageheaderidentifier'] != [""] and len(page_config['pageheaderidentifier']) > 0 and \
            len(page_config['pagefooteridentifier']) > 0:
        if apply_regex_footer == True:
            top = word_cords.iloc[-1]['top']
            page_word_cords = word_cords[word_cords['pageno'] == pageno]
            footer_word_cords = page_word_cords[(word_cords['top'] > top - 5) & (word_cords['top'] < top + 6)]
            footer_text = " ".join(footer_word_cords['word'])
            reg_expression = "".join(page_config['pagefooteridentifier'])
            reg_expression = re.compile(reg_expression)
            reg_result = re.findall(reg_expression, footer_text)
            if len(reg_result) > 0:
                footer_start_index = list(footer_word_cords.index)[0]
        else:
            if page_config['pagefooteridentifier'] != [""]:
                footer_start_index = get_table_refstr_pos(page_wise_df, page_config['pagefooteridentifier'][0], "", 0)

    return header_start_index, footer_start_index


def get_index(page_wise_df, reg_expression):
    # reg_expression = "\d{1,2}-\w{3}-\d{2,4} \d{2}:\d{2}"
    row_index = None
    text = ""
    for row_index in range(len(page_wise_df), len(page_wise_df)-50, -1):
        # print("row_index=", row_index)
        text = str(page_wise_df.iloc[row_index-1]["text"]) + " " + str(text)
        text = text.strip()
        reg_result = re.findall(reg_expression, text)
        if len(reg_result) > 0:
            # print("break = ", reg_result)
            row_index = int(str(page_wise_df.iloc[row_index-1]).split("Name:")[-1].split(', dtype')[0].strip())
            break

    return row_index


def get_pagewise_footer_position_regex(word_cords, page_nums, words_regex, all_index_list):
    words_regex = words_regex.replace("Regex::", "").replace("regex::", "").replace("\\\\", "\\")
    pagewise_dict = {}
    for pageno in page_nums:
        header_index_list = []
        reg_expression = re.compile(words_regex)
        page_wise_df = word_cords[word_cords["pageno"] == pageno]
        # print("page_wise_df = ", page_wise_df)
        word_index = get_index(page_wise_df, reg_expression)
        if word_index:
            header_index_list = [word_index]

        sorted_list = list(set(header_index_list))
        sorted_list.sort()
        pagewise_dict[pageno] = sorted_list
    return pagewise_dict

def get_pagewise_footer_position(word_cords, page_nums, words_list, all_index_list):
    pagewise_dict = {}
    for pageno in page_nums:
        header_index_list = []
        header_index_list_all = []
        for header_string in words_list:
            page_wise_df = word_cords[word_cords["pageno"] == pageno]
            word_index = get_table_refstr_pos(page_wise_df, header_string, "", 0)
            if word_index:
                header_index_list = page_wise_df.index[list(page_wise_df.index).index(word_index):]
                header_index_list_all.extend(header_index_list)
            all_index_list.extend(header_index_list_all)
        sorted_list = list(set(header_index_list_all))
        sorted_list.sort()
        pagewise_dict[pageno] = sorted_list
    return pagewise_dict

def get_pagewise_header_position(word_cords, page_nums, words_list, all_index_list):
    pagewise_dict = {}
    for pageno in page_nums:
        header_index_list = []
        header_index_list_all = []
        for header_string in words_list:
            page_wise_df = word_cords[word_cords["pageno"] == pageno]
            if pageno != 0:
                word_index = get_table_refstr_pos(page_wise_df, header_string, "", 0)
                if word_index:
                    header_index_list = page_wise_df.index[0:list(page_wise_df.index).index(word_index)+1]
                    header_index_list = list(header_index_list)
                    if len(words_list[0].split(" ")) > 1:
                        header_index_list.append(header_index_list[-1]+len(words_list[0].split(" "))-1)
                    header_index_list_all.extend(header_index_list)
            all_index_list.extend(header_index_list_all)
        pagewise_dict[pageno] = list(set(header_index_list_all))
    return pagewise_dict

def get_header_footer_position(word_cords, page_config_json):
    page_nums = word_cords["pageno"].unique()
    page_nums.sort()
    header_footer_dict = {}
    header_footer_index_all = {}
    all_index_list = []
    footer_dict = {}

    all_header_words = []
    all_footer_words = []
    for page_config in page_config_json['pages']:
        if len(page_config['pageheaderidentifier']) > 0:
            all_header_words.append(" ".join(page_config['pageheaderidentifier']))
        if len(page_config['pagefooteridentifier']) > 0:
            all_footer_words.append(" ".join(page_config['pagefooteridentifier']))

    all_header_words = [word for word in all_header_words if word]
    all_footer_words = [word for word in all_footer_words if word]
    header_dict = get_pagewise_header_position(word_cords, page_nums, all_header_words, all_index_list)
    #print("all_footer_words = ", all_footer_words)
    #print("all_header_words = ", all_header_words)
    if len(all_footer_words) > 0:
        if "regex" in all_footer_words[0].lower():
            #all_footer_words = "\d{2}-\w+-\d{4} \d{2}[:]\d{2}"
            #footer_dict = get_pagewise_footer_position_regex(word_cords, page_nums, all_footer_words, all_index_list)
            footer_dict = get_pagewise_footer_position_regex(word_cords, page_nums, all_footer_words[0], all_index_list)
        else:
            footer_dict = get_pagewise_footer_position(word_cords, page_nums, all_footer_words, all_index_list)

    pageno = 0
    #print(header_dict)
    for key in header_dict.keys():
        header_index_list = header_dict[key]
        header_index_list.sort()
        if key in footer_dict.keys():
            footer_index_list = footer_dict[key]
            footer_index_list.sort()
        else:
            footer_index_list = []
        header_footer_dict[pageno] = {'header_index_list': header_index_list, 'footer_index_list': footer_index_list}
        pageno += 1

    header_footer_index_all["index"] = all_index_list

    return header_footer_dict, header_footer_index_all


def get_all_occurences_data(lists_of_text, seperator):
    separator_flag = False
    section_data = []
    sub_section_list = []
    for each_ele in lists_of_text:
        if each_ele.lower().strip().startswith(seperator.lower().strip()):
            if separator_flag == True:
                section_data.append(sub_section_list)
                sub_section_list = []
            separator_flag = True
        sub_section_list.append(each_ele)
    section_data.append(sub_section_list)
    return section_data


def get_key_row_position(words_df, word_string, coords, afterref_indx):
    word_index = None
    page = words_df.iloc[afterref_indx]['pageno']
    if word_string in ("", None):
        word_index = list(words_df[words_df['pageno'] == page].iloc[-1:].index.values)[0]
    else:
        list_words = word_string.strip("\n").split(" ")
        list_words.append(word_string)
        words_df = words_df.iloc[afterref_indx:]
        try:
            words_df_filtered = words_df[words_df['text'].isin(list_words)]
        except:
            words_df_filtered = words_df[words_df['word'].isin(list_words)]
        if coords:
            plumber_coords = convert_UI_coord_to_plumber(coords)
            words_df_filtered['left_diff'] = abs(words_df_filtered['left'] - plumber_coords['left'])
            words_df_filtered['top_diff'] = abs(words_df_filtered['top'] - plumber_coords['top'])
            words_df_filtered = words_df_filtered.rename_axis('indx').sort_values(by=['left_diff', 'indx'], axis=0,
                                                                                  ascending=[True, True])
            if len(words_df_filtered) > 0:
                word = words_df_filtered.iloc[0:1]
                word_index = list(word.index.values)[0]
            else:
                if afterref_indx != 0:
                    word_index = list(words_df[words_df['pageno'] == page].iloc[-1:].index.values)[0]
        else:
            index_found = False
            for indx in range(0, len(words_df_filtered)):
                concate_words = ""
                for no_indx in range(0, len(list_words)):
                    if no_indx + indx < len(words_df_filtered):
                        try:
                            concate_words = concate_words + " " + words_df_filtered.iloc[no_indx + indx]['text']
                        except:
                            # 'word' is the column name mentioned for image pdf
                            concate_words = concate_words + " " + words_df_filtered.iloc[no_indx + indx]['word']
                    if fuzz.ratio(word_string, concate_words.strip()) > fuzzy_threshold:
                        word_index = int(str(words_df_filtered.iloc[indx]).split("Name:")[-1].split(', dtype')[0].strip())
                        index_found = True
                        break
                if index_found:
                    break
    return word_index


def get_afterref_pos(words_df, config_data, afterref_indx):
    SIMILARITY_THRESH = 95
    word_string = config_data['afterrefstr']
    coords = config_data['afterrefcoords']
    word_index = None
    start_page = config_data['pageno']
    list_words = word_string.strip("\n").split(" ")
    list_words.append(word_string)
    words_df = words_df.iloc[afterref_indx:]
    words_df_filtered = words_df[words_df['word'].isin(list_words)]
    # assuming annotcord and after reference string are in same page always
    words_df_filtered = words_df_filtered[words_df_filtered['pageno'] == start_page]
    if len(words_df_filtered) > 0:
        for indx in range(0, len(words_df_filtered)):
            concate_words = ""
            for no_indx in range(0, len(list_words)):
                if no_indx + indx < len(words_df_filtered):
                    concate_words = concate_words + " " + words_df_filtered.iloc[no_indx + indx]['word']
                    if len(concate_words.split(" ")) == len(word_string):
                        break
            sim_score = fuzz.ratio(word_string.lower(), concate_words.lower())
            if sim_score > SIMILARITY_THRESH:
                words_df_filtered = words_df_filtered[indx:indx + len(list_words)]
                break
        if len(words_df_filtered) > len(list_words) and coords:
            plumber_coords = convert_UI_coord_to_plumber(coords)
            words_df_filtered['left_diff'] = abs(plumber_coords['left'] - words_df_filtered['left'])
            words_df_filtered['top_diff'] = abs(plumber_coords['top'] - words_df_filtered['top'])
            words_df_filtered = words_df_filtered.rename_axis('indx').sort_values(by=['left_diff', 'indx'], axis=0,
                                                                                  ascending=[True, True])
        word = words_df_filtered.iloc[0:1]
        word_index = list(word.index.values)[0]
        word_pos = 0
        for word in list_words:
            if fuzz.ratio(word, words_df_filtered.iloc[0]['word']) < fuzzy_threshold:
                word_pos += 1
            else:
                break
        # word_index = word_index - word_pos  # to be used in future
    return word_index


def get_ref_string_pos(words_df, start_page, afterref_indx, word_string, coords):
    SIMILARITY_THRESH = 95
    word_index = None
    list_words = word_string.strip("\n").split(" ")
    list_words.append(word_string)
    words_df = words_df.iloc[afterref_indx:]

    # assuming annotcord and after reference string are in same page always
    words_df_filtered = words_df[words_df['pageno'] == start_page]
    if len(words_df_filtered) > 0:
        for indx in range(0, len(words_df_filtered)):
            concate_words = ""
            for no_indx in range(0, len(list_words)-1):
                if no_indx + indx < len(words_df_filtered):
                    concate_words = concate_words + " " + str(words_df_filtered.iloc[no_indx + indx]['word'])
                    if len(concate_words.split(" ")) == len(word_string):
                        break

            sim_score = fuzz.ratio(word_string.lower(), concate_words.strip().lower())
            if sim_score > SIMILARITY_THRESH:
                words_df_filtered = words_df_filtered[indx:indx + len(list_words)]
                break
        if len(words_df_filtered) > len(list_words) and coords:
            plumber_coords = convert_UI_coord_to_plumber(coords)
            words_df_filtered['left_diff'] = abs(plumber_coords['left'] - words_df_filtered['left'])
            words_df_filtered['top_diff'] = abs(plumber_coords['top'] - words_df_filtered['top'])
            words_df_filtered = words_df_filtered.rename_axis('indx').sort_values(by=['left_diff', 'indx'], axis=0,
                                                                                  ascending=[True, True])
        word = words_df_filtered.iloc[0:1]
        word_index = list(word.index.values)[0]
        word_pos = 0
        for word in list_words:
            if fuzz.ratio(word, str(words_df_filtered.iloc[0]['word'])) < fuzzy_threshold:
                word_pos += 1
            else:
                break
        # word_index = word_index - word_pos  # to be used in future
    return word_index


def get_table_refstr_pos(words_df, word_string, coords, afterref_indx):
    word_index = None
    list_words = word_string.strip("\n").split(" ")
    list_words.append(word_string)
    words_df_filtered = words_df.iloc[afterref_indx:]
    words_df_filtered_final = []

    for indx in range(0, len(words_df_filtered)):
        concate_words = ""
        for no_indx in range(0, len(list_words)):
            if no_indx + indx < len(words_df_filtered):
                try:
                    concate_words = concate_words + " " + str(words_df_filtered.iloc[no_indx + indx]['word'])
                except:
                    concate_words = concate_words + " " + str(words_df_filtered.iloc[no_indx + indx]['text'])
                if len(concate_words.split(" ")) >= len(list_words):
                    break
        if fuzz.ratio(word_string.lower().strip(), concate_words.lower().strip()) >= fuzzy_threshold:
            words_df_filtered_final = words_df_filtered[indx:indx + len(list_words)]
            break

    if len(words_df_filtered_final) > len(list_words) and coords:
        plumber_coords = convert_UI_coord_to_plumber(coords)
        words_df_filtered_final['left_diff'] = abs(plumber_coords['left'] - words_df_filtered_final['left'])
        words_df_filtered_final['top_diff'] = abs(plumber_coords['top'] - words_df_filtered_final['top'])
        words_df_filtered_final = words_df_filtered_final.rename_axis('indx').sort_values(by=['left_diff', 'indx'],
                                                                                          axis=0,
                                                                                          ascending=[True, True])
    if len(words_df_filtered_final) > 0:
        word = words_df_filtered_final.iloc[0:1]
        word_index = list(word.index.values)[0]

    return word_index


def convert_pdf_to_png(input_file_path, output_folder, png_filename):
    conversion_density = CONFIG_JSON['png-conversion-factor']
    if conversion_density in ("", None):
        conversion_density = "500"
    cmd = "convert -density " + conversion_density + " " + input_file_path + " -quality 100 -background white -alpha remove -compress zip +adjoin " + output_folder + png_filename + ".png"
    ret = system(cmd)
    return ret


def get_mapping_type(annotation):
    if annotation["annotation"]["datastring"]["image"] in TRUE_CHECK:
        mapping_type = "image"

    elif annotation["annotation"]["datastring"]["freetext"] in TRUE_CHECK or \
            annotation["annotation"]["datastring"]["paragraph"] in TRUE_CHECK:
        mapping_type = "freetext"

    elif annotation["annotation"]["datastring"]["delimited"] in TRUE_CHECK:
        mapping_type = "delimited"

    elif annotation["annotation"]["datastring"]["setofrows"]["borderedtable"] in TRUE_CHECK or \
            annotation["annotation"]["datastring"]["setofrows"]["virtualtable"] in TRUE_CHECK:
        mapping_type = "table"

    elif annotation["annotation"]["datastring"]["keyvaluepairs"]["keyvaluepair"] in TRUE_CHECK:
        mapping_type = "keyvaluepairs"

    return mapping_type


def reading_json(config_json_path):
    with open(config_json_path, encoding="utf-8") as json_file:
        config_data = json.load(json_file)
        return config_data


def get_no_of_workers(config_json):
    workers = str(config_json["cpu_cores"])
    if workers not in [None, ""]:
        workers = int(workers)
    else:
        workers = 2*os.cpu_count()+1
    config_json["cpu_cores"] = workers
    return config_json


def return_config(form_id):
    config_param_path = path.join(BACKEND_FOLDER, "template/form_configurations",
                                  "configuration_" + str(form_id) + ".json")
    form_config_params = reading_json(config_param_path)
    if form_config_params["default_param"] in FALSE_CHECK:
        config_json = form_config_params
    else:
        config_json = CONFIG_JSON
    config_json = get_no_of_workers(config_json)
    return config_json


# slicing of the extracted tabular data based on startrow and endrow
def eliminate_header_rows_using_startrow(table_data, config_data):
    startrow = 1
    endrow = len(table_data)
    if config_data['startrow']:
        try:
            startrow = int(config_data['startrow'])
        except:
            pass
        if config_data['endrow']:
            try:
                endrow = int(config_data['endrow'])
            except:
                pass
    return table_data[startrow - 1:endrow]


def garbage_removed_data(data, page_config_json):
    garbage_regex = page_config_json.get("garbageremovalregex", "")
    final_data = []
    if garbage_regex not in ['', None] and len(data) > 0:
        for row_index in range(len(data)):
            row_data = []
            for indx in range(len(data[row_index])):
                row_data.append(re.sub(garbage_regex, '', data[row_index][indx]))
            final_data.append(row_data)
    else:
        final_data = data
    return final_data