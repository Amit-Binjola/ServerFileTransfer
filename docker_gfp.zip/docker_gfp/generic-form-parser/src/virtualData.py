
import re


def checkDataType(val):
    val=re.sub(" ","",val)
    if val.isdigit():
        return "integer"
    elif any(i.isdigit() for i in val):
        return "alphanum"
    else:
        return "string"



def nestedAnnotations(annotation_id,all_annotations):
    nested_annotation=[]
    
    for annotation in all_annotations:
        if annotation["annotation"]["annotid"]==annotation_id:
            nested_annotation=annotation
            delimiter=annotation["annotation"]["datastring"]["setofrows"]["rowseparator"]
            break
    nested_elements=nested_annotation["annotation"]["datastring"]["elements"]
    return nested_elements,delimiter



def getMultipleElements(elements,val,all_annotations,valdict):
    used_element=[]
    ix=-1
    for i in elements:
        if elements.index(i)>ix:
            for j in elements:
                if elements.index(j)>ix:
                    name=j['elemententity']+j['elementname']
                    datatype=j['datatype']
                    if name not in used_element:
                         aftermarkerstring=i["alwaysafter"]["aftermarkerstring"]
                         start_tag=re.findall(aftermarkerstring,val)[0]
                         start=val.find(re.findall(aftermarkerstring,val)[0])+len(start_tag)-1
                         end=-1
                         if j["alwaysbefore"]["beforemarkerstringflag"]=="true":
                             beforemarkerstring=j["alwaysbefore"]["beforemarkerstring"]
                         else:
                             beforemarkerstring="~end~"  
                         ix=elements.index(j)
                         if re.search(beforemarkerstring,val)!=None:
                                 end=val[start:].find(re.findall(beforemarkerstring,val)[0])
                                 end=end+start
                         elif beforemarkerstring!="~end~":
                             while(ix<len(elements)):
                                 beforemarkerstring=elements[ix]["alwaysbefore"]["beforemarkerstring"]
                                 if re.search(beforemarkerstring,val)!=None:
                                     end=val[start:].find(re.findall(beforemarkerstring,val)[0])
                                     end=end+start
                                     if end==start:
                                         ix+=1
                                         continue
                                     break
                                 ix+=1
                         if end==-1:
                             tempval=val[start+1:]
                             tempval=tempval.strip()
                             
                             if datatype=="string":
                                 if checkDataType(tempval)!=datatype:
                                     ix=elements.index(j)
                                     continue
                            
                             used_element.append(j['elementname'])
                             valdict[j['elemententity']+j['elementname']]=tempval
                             val="" 
                             break
                             
                         if end > start:
                             tempval=val[start+1:end]
                             tempval=tempval.strip()
                             
                             if datatype=="string":
                                 if checkDataType(tempval)!=datatype:
                                     ix=elements.index(j)
                                     continue
      
                             used_element.append(j['elemententity']+j['elementname'])
                             val=val[end-2:] 
                             if j['elementtype']=='referenceonly':
                                 valdict['parentreferrence']=tempval
                                 break
                             elif j['elementtype']=='virtual':
                                nested_annot_id=j['virtualannotationreference']
                                nested_elements,delimiter=nestedAnnotations(nested_annot_id,all_annotations)
                                if delimiter!="":
                                    mulvals=tempval.split(delimiter)
                                    for singleval in mulvals:
                                        singleval=aftermarkerstring+singleval+beforemarkerstring
                                        singleval=re.sub("\\\\","",singleval)
                                        valdict=getMultipleElements(nested_elements,singleval,all_annotations,valdict)
                                else:
                                    valdict=getMultipleElements(nested_elements,tempval,all_annotations,valdict) 
                                break
                             if j['elemententity']+j['elementname'] in valdict:
                                if type(valdict[j['elemententity']+j['elementname']])==list():
                                    valdict[j['elemententity']+j['elementname']].append(tempval)
                                else:
                                    prev_val=valdict[j['elemententity']+j['elementname']]
                                    valdict[j['elemententity']+j['elementname']]=[prev_val]
                                    valdict[j['elemententity']+j['elementname']].append(tempval)
                                break
                             else:
                                valdict[j['elemententity']+j['elementname']]=tempval
                                break
                         else:
                             continue

    return valdict








########################################################3          
#val="#3 ) RX Prod 1 Trade (RX Prod Gen) 100 mg"

#val="#1 ) Oraprofen, 200 milligram {Lot # 5712; Exp.Dt. MAR-2019}"
                             
"""
allbeforemarker=[]
for element in elements:
    allbeforemarker.append(element["alwaysbefore"]["beforemarkerstring"])

"""

"""
for i in elements:
    for j in elements:
        if j['elementname'] not in used_element:
             aftermarkerstring=i["alwaysafter"]["aftermarkerstring"]
             beforemarkerstring=j["alwaysbefore"]["beforemarkerstring"]
             start=val.find(re.findall(aftermarkerstring,val)[0])
             end=-1
             if re.search(beforemarkerstring,val)!=None:
                     end=val.find(re.findall(beforemarkerstring,val)[0])
             allbeforemarker=[]
             ix=elements.index(j)
             if end!=-1:
                 allbeforemarker.append(end)
             while(ix<len(elements)):
                 beforemarkerstring=elements[ix]["alwaysbefore"]["beforemarkerstring"]
                 print(beforemarkerstring)
                 if re.search(beforemarkerstring,val)!=None:
                     end=val.find(re.findall(beforemarkerstring,val)[0])
                     allbeforemarker.append(end)
                 ix+=1
             
             allbeforemarker.sort()
             end=allbeforemarker[0]
             if end > start:
                 tempval=val[start+1:end]
                 val=val[end-2:] 
                 used_element.append(j['elementname'])
                 valdict[j['elementname']]=tempval
                 break
             else:
                 continue
             
        

val='#1 ) Rxstudy1 (Code not broken) Capsule {Lot # 12345; Exp.Dt. 01-SEP-2016}'
val="#1 ) Cipla US Tablet (P-COUMARIC ACID 100 g) Injection, 100 millimole {Lot # 12345; Exp.Dt. 01-SEP-2016}"        
val="#1 ) Orampexin (AMPICILLIN) Tablet, 500 milligram"
val="#1 ) AVELUMAB (PARACETAMOL, ANAESTHESIN) Capsule {Lot # Rx-378}"
;;result={}
element_id=0
for element in elements:
    tempval=""
    if element["alwaysafter"]["aftermarkerstringflag"]=="true":
        aftermarkerstring=element["alwaysafter"]["aftermarkerstring"]
    if element["alwaysbefore"]["beforemarkerstringflag"]=="true":
        beforemarkerstring=element["alwaysbefore"]["beforemarkerstring"]
    if element_id==0:
        start_index=re.search(aftermarkerstring, val).start()
        end_index=re.search(beforemarkerstring, val).start()
        temp_val=val[start_index+1:end_index].strip()
        val=val[end_index+1:].strip()
        element_id=1
    else:
        end_index=val.find(re.findall(beforemarkerstring,val)[0])
        temp_val=val[:end_index].strip()
        if "\\d" in beforemarkerstring or "\\w" in beforemarkerstring:
            val=val[end_index:]
        else:
            val=val[end_index+1:]
            
    result[element["elementname"]]=temp_val      
    
   
group=mapping_data[6]  
annotations=group['annotations']
annotation=annotations[0]['annotation']
elements=annotation['datastring']['elements']
all_annotations=annotations
"""
    
    
    
