from digitalpdf_dataextraction import find_occcurences, get_key_row_position
from config import CONFIG_JSON, NULL_CHECK
import pandas as pd
import numpy as np
import re

# extracts raw data from the given form and filters out unwanted strings and special characters
def extract_txt_form_rawdata(filepath, strings_to_remove, form_config_params):

    delimiter = form_config_params["delimited_form_param"]["delimiter"]
    lstrip_strings = form_config_params["delimited_form_param"]["lstrip_strings"]
    encoding_string = form_config_params["delimited_form_param"]["encoding_string"]

    with open(filepath, "rb") as file_object:
        row_line = ""
        for line in file_object.readlines():
            line = line.decode()
            line = [line.lstrip(given_str) for given_str in lstrip_strings][0]
            for indx in range(len(strings_to_remove)):
                line = [re.sub(rm_str, " ", line).strip() for rm_str in strings_to_remove][indx]
            if line not in NULL_CHECK:  # to be decided
                line = line.strip("'").strip()  # striping off left and right most single quotes
                row_line = " ".join([row_line, line]).strip() + "\n"

    row_line = [row_line.replace(key, encoding_string[key]) for key in encoding_string.keys()][0]

    # adds a space whenever delimiter string is found
    row_line = row_line.replace(delimiter, " " + delimiter).replace(delimiter, delimiter + " ")
    row_line = row_line + " FORM_END"
    return row_line.strip()


def get_text_form_dataframe(filepath, config, page_config_json, form_config_params):
    strings_to_remove = page_config_json.get("garbageremovalregex", "")
    if strings_to_remove not in NULL_CHECK:
        strings_to_remove = strings_to_remove.split("||")

    sentence = extract_txt_form_rawdata(filepath, strings_to_remove, form_config_params)
    data = {"text": sentence.split(" "), "pageno": list(np.zeros(len(sentence.split(" ")), dtype=int))}
    words_df = pd.DataFrame(data)

    return words_df


def get_data_dict(ref_str_pos_all, words_df, delimiter):
    all_extracted_data = []
    for key in ref_str_pos_all.keys():
        for pos in ref_str_pos_all[key]:
            data_dict = {key: " ".join(words_df.iloc[pos[0] + 1:pos[1]]["text"]).lstrip(delimiter)}
            all_extracted_data.append(data_dict)
    return all_extracted_data


def get_record_separated_data(data_dict_all, record_separater):
    all_extracted_data = []
    for data_index in range(len(data_dict_all)):
        key = list(data_dict_all[data_index].keys())[0]
        value = list(data_dict_all[data_index].values())[0]
        record_separater_index = value.find(record_separater)
        if record_separater_index != -1:
            value = value[0:record_separater_index]
        all_extracted_data.append({key: value})
    return all_extracted_data


def get_keyvaluepairs_data(config_data, data_df):
    ref_str_pos_all = {}
    data_dict_all = {}
    str_occurance_pos = find_occcurences(data_df, config_data["extstartstr"], config_data["extendstr"])

    if len(str_occurance_pos) > 0:
        ref_str_pos_all[config_data["extstartstr"]] = str_occurance_pos
        data_dict_all = get_data_dict(ref_str_pos_all, data_df, config_data["keyvalseperator"])
        if config_data["recordseperator"] not in NULL_CHECK:
            data_dict_all = get_record_separated_data(data_dict_all, config_data["recordseperator"])

    return data_dict_all


def get_delimited_textform_data(file_path, REQ_FOLDER, page_config_json, config, form_config_params):
    words_df = get_text_form_dataframe(file_path, config, page_config_json, form_config_params)

    extracted_data_json = []
    for indx in range(len(config)):
        config_data = config.iloc[indx]
        data_df = words_df
        data_dict_all = []
        if config_data["startpos"] == "afterstring":
            word_index = get_key_row_position(words_df, config_data["extstartstr"], "", 0)
            if word_index not in [None, ""]:
                data_df = words_df.iloc[word_index+1:]
                data_df.reset_index(drop=True, inplace=True)

        if config_data['datastringtype'] == "keyvaluepairs":
            data_dict_all = get_keyvaluepairs_data(config_data, data_df)

        json_data = {"AnnotID": config_data['annotid'], "class": config_data['name'], "value": data_dict_all}
        extracted_data_json.append(json_data)

    return extracted_data_json
