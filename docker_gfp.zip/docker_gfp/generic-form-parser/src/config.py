from logging import getLogger
from logging.config import fileConfig
import json
from os import path, getenv, mkdir

ALLOWED_MODULES = ['json', 'fuzzywuzzy', 're', 'copy', 'numpy', 'pandas', 'boto3', 'requests', 'dateutil']
TRUE_CHECK = ("true", "True", True)
NULL_CHECK = ("null", "", None)
FALSE_CHECK = ("False", "false", False)
BACKEND_FOLDER = path.join(getenv("HOME"), "backendservice/utility")
UPLOAD_FOLDER = path.join(BACKEND_FOLDER, "uploads")
TEMPLATE_FOLDER = path.join(BACKEND_FOLDER, "template")
METADATAJSON_UPLOAD_FOLDER = path.join(TEMPLATE_FOLDER, "metadata_json")
CUSTOMIZATION_FOLDER = path.join(TEMPLATE_FOLDER, "customizations")
REFERENCE_JSON_FOLDER = path.join("/".join(path.dirname(path.abspath(__file__)).split("/")[:-1]), "reference_json")
CONFIG_FOLDER = path.join("/".join(path.dirname(path.abspath(__file__)).split("/")[:-1]), "config")

config_json_path = path.join(CONFIG_FOLDER, "configuration.json")
CONFIG_JSON = json.load(open(config_json_path))

log_config_path = "/".join(path.dirname(path.abspath(__file__)).split("/")[:-1]) + "/config/log-config.ini"
logfilepath = getenv("HOME") + CONFIG_JSON["logs-folder"]
fileConfig(log_config_path, disable_existing_loggers=True, defaults={'logfilename': logfilepath})
logger = getLogger("apiLogger")

# getting aws s3 credentials from configuration json
s3_ACCESS_KEY = CONFIG_JSON["S3-credentials"]["ACCESS_KEY"]
s3_SECRET_KEY = CONFIG_JSON["S3-credentials"]["SECRET_KEY"]
s3_bucket = CONFIG_JSON["S3-credentials"]["bucket"]
