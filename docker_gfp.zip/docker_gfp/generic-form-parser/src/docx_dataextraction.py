#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun 13 11:40:29 2020

@author: aditya
"""
from docx_config_generate import fill_json, iter_unique_cells
import docx
import pandas as pd
import math
import json


# maps given reference id to data for annotation from table
def map_reference_id_to_annotation(config_data, mapping_reference_id, table):
    data = ""
    mapping_row_start = int(config_data["startrow"]) if config_data["startrow"] not in (None, "null", "") else 1 if mapping_reference_id["rowreferenceid"] is None else mapping_reference_id[
        "rowreferenceid"]
    mapping_row_end = int(config_data["endrow"]) if config_data["endrow"] not in (None, "null", "") else len(table["rows"]) if mapping_reference_id["rowreferenceid"] is None else mapping_row_start + (
            mapping_reference_id["rowreferencelength"] - 1)
    mapping_column_start = 1 if mapping_reference_id["cellreferenceid"] is None else mapping_reference_id["cellreferenceid"]
    mapping_column_end = max([len(row["cells"]) for row in table["rows"]]) if mapping_reference_id["cellreferenceid"] is None else mapping_column_start + (
            mapping_reference_id["cellreferencelength"] - 1)

    for row_index, row in enumerate(table["rows"]):
        if mapping_row_start <= row_index + 1 <= mapping_row_end:
            rowdata = ""
            for cell_index, cell in enumerate(row["cells"]):
                if mapping_column_start <= cell_index + 1 <= mapping_column_end:
                    rowdata += cell["celldata"]["value"]
            data += "\n" + rowdata

    return "\n" + data.strip()


# returns reference id of annotation in dict format
def get_reference_id(config_data):
    reference_id = {
        "tablereferenceid"   : int(config_data["tablereferenceid"]),
        "cellreferenceid"    : int(config_data["cellreferenceid"]) if config_data["cellreferenceid"] not in (None, "null", "none", "") else None,
        "rowreferenceid"     : int(config_data["rowreferenceid"]) if config_data["rowreferenceid"] not in (None, "null", "none", "") else None,
        "cellreferencelength": int(config_data["cellreferencelength"]) if config_data["cellreferencelength"] not in (None, "null", "none", "") else None,
        "rowreferencelength" : int(config_data["rowreferencelength"]) if config_data["rowreferencelength"] not in (None, "null", "none", "") else None
    }
    return reference_id


# returns required table and table_id corresponding to given annotation from metadata json
def get_table(config_data, train_metadata_json, test_metadata_json):
    reference_id = get_reference_id(config_data)
    table_indx = reference_id["tablereferenceid"] - 1
    table = test_metadata_json['tables'][table_indx]
    template_table = train_metadata_json['tables'][table_indx]

    if table_indx <= len(train_metadata_json['tables']):
        if table['tableid'] == template_table['tableid']:
            config_data["tablereferenceid"] = table['tableid']
        else:
            for template_table in train_metadata_json['tables']:
                if table['texttomatch']['rownum'] == template_table['texttomatch']['rownum']:
                    if table['texttomatch']['cellnum'] == template_table['texttomatch']['cellnum']:
                        if table['texttomatch']['text'] == template_table['texttomatch']['text']:
                            config_data["tablereferenceid"] = template_table['tableid']
                            break

    return config_data, table


def map_dataframe_to_annotation(table_data):
    extracted_data = []
    for row_index, row in table_data.iterrows():
        row_data = []
        for cell in row:
            if isinstance(cell, list):
                cell_data = []
                for each in cell:
                    cell_data.append(map_dataframe_to_annotation(each))
                row_data.append([cell_data])
            else:
                if pd.notnull(cell):
                    cell_data = cell
                    row_data.append(cell_data)
        extracted_data.append(row_data)
    return extracted_data


def update_window(table_df, start_row, start_cell, row_length, cell_length):
    window = pd.DataFrame()
    iterator_obj = table_df.values
    for row_index in range(start_row, start_row + row_length):
        row_window = []
        for cell_index in range(start_cell, start_cell + cell_length):
            if row_index < len(iterator_obj) and cell_index < len(iterator_obj[0]):
                row_window.append(iterator_obj[row_index][cell_index])
        while len(row_window) < cell_length:
            row_window.append(None)
        window = window.append([row_window])
    while len(window) < row_length:
        window = window.append([None] * cell_length)
    window.reset_index(drop=True, inplace=True)
    return window


def transform_tables(table_df, config_data):
    transformed_table = pd.DataFrame()
    rowtransformlength = int(config_data["rowtransformlength"])
    celltransformlength = int(config_data["celltransformlength"])

    if celltransformlength == 1 and rowtransformlength == 1:
        # transpose directly
        transformed_table = table_df.transpose()
    else:
        # sliding window
        max_row_iter = math.ceil(len(table_df) / rowtransformlength)
        max_cell_iter = math.ceil(len(table_df.columns) / celltransformlength)
        for row_index in range(max_row_iter):
            for cell_index in range(max_cell_iter):
                window = update_window(table_df, row_index * rowtransformlength,
                                       cell_index * celltransformlength, rowtransformlength, celltransformlength)
                insertion_data = []
                for index, row in window.iterrows():
                    for cell in row:
                        insertion_data.append(cell)
                transformed_table = transformed_table.append([insertion_data])

    transformed_table.reset_index(drop=True, inplace=True)

    return transformed_table


def convert_table_to_dataframe(table):
    table_data = pd.DataFrame()
    for row_index, row in enumerate(table["rows"]):
        row_data = []
        for cell_index, cell in enumerate(row["cells"]):
            try:
                temp_celldata = json.loads(cell["celldata"]["value"])
                nested_array = []
                for nested_table_index, nested_table in enumerate(temp_celldata["tables"]):
                    nested_dataframe = convert_table_to_dataframe(nested_table)
                    nested_array.append(nested_dataframe)
                row_data.append(nested_array)
            except json.JSONDecodeError:
                row_data.append(cell["celldata"]["value"])
        table_data = table_data.append([row_data])
    table_data.reset_index(drop=True, inplace=True)
    return table_data


def get_delimited_data(config_data, train_metadata_json, test_metadata_json):
    extracted_data = None
    # Functionality to be defined later as no use case currently available

    return extracted_data


def get_keyvalue_data(config_data, train_metadata_json, test_metadata_json):
    extracted_data = None
    # Functionality to be defined later as no use case currently available

    return extracted_data


def get_tabular_data(config_data, train_metadata_json, test_metadata_json):
    data_start_row = int(config_data["startrow"]) - 1
    transformtable = config_data["transformtable"]
    config_data, table = get_table(config_data, train_metadata_json, test_metadata_json)
    table_dataframe = convert_table_to_dataframe(table)
    trimmed_table_dataframe = table_dataframe.iloc[data_start_row:, :]
    if transformtable:
        trimmed_table_dataframe = transform_tables(trimmed_table_dataframe, config_data)
    extracted_tabular_data = map_dataframe_to_annotation(trimmed_table_dataframe)
    return extracted_tabular_data


# returns extracted checkbox data from annotation
def get_checkbox_data(config_data, input_doc, train_metadata_json, test_metadata_json):
    config_data, table = get_table(config_data, train_metadata_json, test_metadata_json)
    checkbox_op, cell_objects = [], []
    reference_id = get_reference_id(config_data)
    table_id = reference_id["tablereferenceid"] - 1
    row_id = 0 if reference_id["rowreferenceid"] is None else reference_id["rowreferenceid"] - 1
    row_length = 1 if reference_id["rowreferencelength"] is None else reference_id["rowreferencelength"]
    cell_id = 0 if reference_id["cellreferenceid"] is None else reference_id["cellreferenceid"] - 1
    cell_length = 1 if reference_id["cellreferencelength"] is None else reference_id["cellreferencelength"]

    for row in range(row_id, row_id + row_length):
        for cell in range(cell_id, cell_id + cell_length):
            cells_to_map = [cell for cell in iter_unique_cells(input_doc.tables[table_id].rows[row])]
            cell_objects.append(cells_to_map[cell])

    for cell_object in cell_objects:
        if cell_object._element.xpath('.//w:checkBox'):
            for child in cell_object._element.xpath('.//w:checkBox'):
                for ele in child:
                    if ele.tag == '{%s}%s' % (
                            'http://schemas.openxmlformats.org/wordprocessingml/2006/main', 'default'):
                        for attr, value in ele.items():
                            checkbox_op.append(value)
    return checkbox_op


# returns extracted freetext data from annotation
def get_freetext_data(config_data, train_metadata_json, test_metadata_json):
    config_data, table = get_table(config_data, train_metadata_json, test_metadata_json)
    mapping_reference_id = get_reference_id(config_data)
    extracted_freetext_data = map_reference_id_to_annotation(config_data, mapping_reference_id, table)
    return extracted_freetext_data


def read_file(filepath):
    file = open(filepath, 'rb')
    document = docx.Document(file)
    file.close()
    return document


# main method called from ws1 for creation of extracted data json for docx
def get_docx_data(filepath, train_metadata_json, config):
    input_doc = read_file(filepath)
    input_metadata_json = fill_json(input_doc)
    extracted_data_json = []
    for indx in range(len(config)):
        config_data = config.iloc[indx]
        if config_data["annotationtype"] != "virtual":
            json_data = {"AnnotID": config_data['annotid'], "class": config_data['name']}
            if config_data['datastringtype'] == "freetext":
                extracted_data = get_freetext_data(config_data, train_metadata_json, input_metadata_json)
            elif config_data['datastringtype'] == "image":
                extracted_data = get_checkbox_data(config_data, input_doc, train_metadata_json, input_metadata_json)
            elif config_data['datastringtype'] == "keyvaluepairs":
                extracted_data = get_keyvalue_data(config_data, train_metadata_json, input_metadata_json)
            elif config_data['datastringtype'] == "table":
                extracted_data = get_tabular_data(config_data, train_metadata_json, input_metadata_json)
            elif config_data['datastringtype'] == "delimited":
                extracted_data = get_delimited_data(config_data, train_metadata_json, input_metadata_json)

            json_data["value"] = extracted_data
            extracted_data_json.append(json_data)

    return extracted_data_json
