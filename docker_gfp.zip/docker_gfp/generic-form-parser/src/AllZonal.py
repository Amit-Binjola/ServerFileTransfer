from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import time
import pandas as pd
import os
import flask
import numpy as np
from PIL import Image


AbbyyInstallPath_fullpage = '/opt/ABBYY/FREngine12/Samples/Outproc/Multithreading1/multithreading'  # /SampleImages/saved_image.png  /SampleImages/Demo.txt'
AbbyyInstallPath_zonal = '/opt/ABBYY/FREngine12/Samples/Zonal_ICR/Icr'
target_file = "/opt/ABBYY/FREngine12/Samples/tempdata/temp_out.txt"
desti = "/opt/ABBYY/FREngine12/Samples/tempdata/form.png"

def remove_targetfile():
    if os.path.exists(target_file):
        os.remove(target_file)
        print('File Deleted: ', target_file)
    else:
        print("Can not delete the file as it doesn't exists")

def read_file(filename):
    filename = "/opt/ABBYY/FREngine12/Samples/tempdata/"+filename
    try:
        with open(filename, 'r',encoding='utf-8-sig') as file:
            data = file.read()
            data = data.replace('\n', ' ')
            data = data.replace('\r', '')
            data = data.replace('\t', '')
            data = data.replace('^', '')
            data = data.replace('\xef', '')
            data = data.replace('\xbb', '')
            data = data.replace('\xbf', '')
            data = data.replace('\ufeff', '')
            data = data.strip('.?! ')
            return data
    except:
        return "OCR Error"

def call_command(filename, x1, y1, x2, y2, textType,language ,pageno ):
    filename = "/opt/ABBYY/FREngine12/Samples/tempdata/"+filename+".txt"
    args = " ".join(list(map(str,[x1,y1,x2,y2,textType,language])))
    cmd = "export LD_LIBRARY_PATH=/opt/ABBYY/FREngine12/Bin;"+AbbyyInstallPath_zonal + " " + inputdir[pageno] +" "+filename+" "+args
    os.system(cmd)

def extractAllZones(ix):
    try:
        filename = df.iloc[ix]['filename']
        #print(filename)
        x1 = df.iloc[ix]['x1']
        y1 = df.iloc[ix]['y1']
        x2 = df.iloc[ix]['x2'] + x1
        y2 = df.iloc[ix]['y2'] + y1
        textType = df.iloc[ix]['textType'].lower() + "-zonal"
        textType = textType.split("-")
        pageno = df.iloc[ix]['pageNo']
        language = df.iloc[ix]['language'].capitalize()
        if "full" in textType[1]:
            im = Image.open(inputdir[pageno])
            im1 = im.crop((x1,y1,x2,y2))
            fullzone = "/".join(inputdir[pageno].split("/")[:-1] +["fullzone.tiff"])
            inputdir.append(fullzone)
            im1.save()
            call_command(str(ix), 0,0,0,0, textType[0], language, -1)
        elif "zonal" in textType[1]:
            call_command(str(ix), x1, y1, x2, y2, textType[0], language, pageno)
        val = read_file(str(ix)+".txt")
        return {filename:val}
    except:
        return {df.iloc[ix]['filename'] : "error in input"}

def multiprocessing(func, args, workers):
    with ProcessPoolExecutor(max_workers=workers) as executor:
        res = executor.map(func, args)
    return list(res)

#csv file path and inputdirpath - location of png files- inputdirpath = tmp/tmp______/input/
def getFullData(csv_file_path,inputdirpath):
    global df
    df = pd.read_csv(csv_file_path,"|")
    df.columns = ['filename', 'x1', 'y1', 'x2', 'y2', 'textType', 'language', 'pageNo']
    global inputdir
    inputdir = inputdirpath
    ner_data_combined = multiprocessing(extractAllZones, [ix for ix in range(df.shape[0])], 5)
    data = {"label":[list(i.keys())[0] for i in ner_data_combined ],
        "text" :[i[list(i.keys())[0]] for i in ner_data_combined ]}
    df123 = pd.DataFrame(data)
    outputfilename = "/".join(inputdir[0].split("/")[:-1] +["dataframe.csv"])
    df123.to_csv(outputfilename,sep="|",index=False)
    return outputfilename
