from dateutil.parser import parse
from datetime import datetime
from config import logger
import copy

NULL_CHECK = ("null", "", None)
months_dict = {1: 'JAN', 2: 'FEB', 3: 'MAR', 4: 'APR', 5: 'MAY', 6: 'JUN',
               7: 'JUL', 8: 'AUG', 9: 'SEP', 10: 'OCT', 11: 'NOV', 12: 'DEC'}

fullname_months_dict = {1: 'January', 2: 'February', 3: 'March', 4: 'April', 5: 'May', 6: 'June',
                        7: 'July', 8: 'August', 9: 'September', 10: 'October', 11: 'November', 12: 'December'}


# checking partial dates
def check_partial_dates(value):
    date_present, month_present, year_present = True, True, True
    jan_01_2001 = datetime.strptime('01/01/01', '%m/%d/%y')
    feb_02_2002 = datetime.strptime('02/02/02', '%m/%d/%y')
    try:
        ''' using two default dates (01-Jan-2001 and 02-Feb-2002) for assigning default values in case any of the 
        component(date,month or year) is not able to be detected by the date parser '''

        parsed_date_jan_01_2001 = parse(value, default=jan_01_2001)  # Case 1
        parsed_date_feb_02_2002 = parse(value, default=feb_02_2002)  # Case 2

        '''checking whether any of the date component got default value for both the cases which means that
         particular component is missing from the arsed date '''

        if parsed_date_jan_01_2001.day == 1 and parsed_date_feb_02_2002.day == 2:
            date_present = False
        if parsed_date_jan_01_2001.month == 1 and parsed_date_feb_02_2002.month == 2:
            month_present = False
        if parsed_date_jan_01_2001.year == 2001 and parsed_date_feb_02_2002.year == 2002:
            year_present = False

    except ValueError as error:
        logger.error("Error in date parsing %s", error)
        date_present, month_present, year_present = False, False, False
    return (date_present, month_present, year_present)


def get_time_date_month_year(date_obj, output_dateformat):
    # time
    time = str(date_obj.time())
    # date
    if output_dateformat:
        if date_obj.day < 10:
            date = '0' + str(date_obj.day)
        else:
            date = str(date_obj.day)

        # month
        if output_dateformat.count("m") == 2:
            if date_obj.month < 10:
                month = '0' + str(date_obj.month)
            else:
                month = str(date_obj.month)

        elif output_dateformat.count("m") == 3:
            month = months_dict[date_obj.month]

        else:
            month = fullname_months_dict[date_obj.month]

        # year
        if output_dateformat.count("y") == 2:
            year = str(date_obj.year % 100)
        else:
            year = str(date_obj.year)
    else:
        date = '0' + str(date_obj.day)
        month = months_dict[date_obj.month]
        year = str(date_obj.year)

    return time, date, month, year


def get_ordered_components(components_presence, output_dateformat, date, month, year):
    date_present, month_present, year_present = components_presence[0], components_presence[1], components_presence[2]
    ordered_date_components = []
    seperator = "-" if "-" in output_dateformat else "/"
    date_components = output_dateformat.split(seperator)
    for component_index, component in enumerate(date_components):
        if "m" in component:
            ordered_date_components.append(("month", component_index, month_present, month))
        elif "d" in component:
            ordered_date_components.append(("date", component_index, date_present, date))
        else:
            ordered_date_components.append(("year", component_index, year_present, year))

    return ordered_date_components, seperator


def build_output(ordered_date_components, seperator):
    first_component = second_component = third_component = ""
    ordered_date_components.count(True)
    for component in ordered_date_components:
        if component[2]:
            if component[1] == 0:
                first_component = component[3]
            elif component[1] == 1:
                second_component = component[3]
            elif component[1] == 2:
                third_component = component[3]
    if first_component and second_component and third_component:
        transformed_date = first_component + seperator + second_component + seperator + third_component
    elif first_component and second_component:
        transformed_date = first_component + seperator + second_component
    elif first_component and third_component:
        transformed_date = first_component + seperator + third_component
    elif second_component and third_component:
        transformed_date = second_component + seperator + third_component
    return transformed_date


def transform_date(value, matchesvaluemap):
    transformed_date = copy.deepcopy(value)
    try:
        value = value.replace("\n", "").replace("Unk", "").replace("Un", "").strip("-").strip("/").strip("--").strip()
        output_dateformat = matchesvaluemap["outputdateformat"]
        components_presence = check_partial_dates(value)
        if any(components_presence):
            monthbeforedate = matchesvaluemap.get("monthbeforedate", True)
            if monthbeforedate:
                date_obj = parse(value, dayfirst=False, fuzzy=True)
            else:
                date_obj = parse(value, dayfirst=True, fuzzy=True)
            time, date, month, year = get_time_date_month_year(date_obj, output_dateformat)
            ordered_date_components, seperator = get_ordered_components(components_presence, output_dateformat,
                                                                        date, month, year)
            if components_presence.count(True) > 1:
                transformed_date = build_output(ordered_date_components, seperator)
            else:
                for ordered_component in ordered_date_components:
                    if ordered_component[2]:
                        transformed_date = ordered_component[3]
                        break
            outputtime = matchesvaluemap.get("outputtime", True)
            if outputtime and time:
                transformed_date = transformed_date + " " + time
    except:
        pass
    return transformed_date
