import requests
from PIL import Image
import pandas as pd
from config import CONFIG_JSON
from os import path
from lxml import etree

port = CONFIG_JSON['abbyy_port']
base_URL = "http://" + CONFIG_JSON['base-url-internal'] + ":" + str(port)
target_file = "/opt/ABBYY/FREngine12/Samples/tempdata/temp_out.txt"
#base_URL = "http://18.213.8.225" + ":" + str(port)

def generate_df_using_abbyy_hocr(xml_file_path):
    doc = etree.parse(xml_file_path)
    abbyy_df = pd.DataFrame(columns=['word', 'confidence', 'pageno', \
                                     'left', 'top', 'right', 'bottom', 'width', 'height'])
    for doc_index, doc_path in enumerate(doc.xpath('//*')):
        if 'EnglishUnitedStates' in doc_path.values():
            if doc_path.text:
                if doc_path.text.strip(" ").strip("\n") not in ("", " "):
                    coords = doc.xpath('//*')[doc_index - 1].values()
                    df1 = {'word': doc_path.text, 'confidence': 0, 'pageno': '', 'left': coords[1],
                           'top': coords[2], 'right': coords[3], 'bottom': coords[4],
                           'width': int(coords[3]) - int(coords[1]),
                           'height': int(coords[4]) - int(coords[2])}
                    abbyy_df = abbyy_df.append(df1, ignore_index=True)

    return abbyy_df


def generate_abbyy_hocr(req_folder, png_filepaths):
    hocr_df = pd.DataFrame()
    ocr_folder = path.join(req_folder, "ocr")
    for png_indx in range(len(png_filepaths)):
        getFullPageOCR(req_folder)
        xml_file_path = path.join(ocr_folder, "form_png-" + str(png_indx) + ".png.hocr")
        if len(hocr_df) == 0:
            hocr_df = generate_df_using_abbyy_hocr(xml_file_path)
            hocr_df.pageno[0::] = int(png_indx)
            hocr_df.sort_values(by='top', inplace=True, ascending=True)
        else:
            new_df = generate_df_using_abbyy_hocr(xml_file_path)
            new_df.pageno[0::] = int(png_indx)
            new_df.sort_values(by='top', inplace=True, ascending=True)
            hocr_df = hocr_df.append(new_df)
    hocr_df = hocr_df.reset_index(drop=True)

    return hocr_df
                       
def read_file():
    try:
        with open(target_file, 'r', encoding='utf-8-sig', errors='ignore') as file:
            data = file.read()
            data = data.replace('\n', ' ')
            data = data.replace('\r', '')
            data = data.replace('\t', '')
            data = data.replace('^', '')
            data = data.replace('\xef', '')
            data = data.replace('\xbb', '')
            data = data.replace('\xbf', '')
            data = data.strip('.?! ')
            return data
    except:
        return None


# possible values for textType and ocrType
# textType - handwritten, normal
# ocrType - fullpage, zonal
def getZonalOCR(source_file, bbox_dict, textType, ocrType, language="English"):
    url_zonal = base_URL + "/api/zonal"
    try:
        x1 = bbox_dict['left']
        y1 = bbox_dict['top']
        x2 = bbox_dict['left'] + bbox_dict['width']
        y2 = bbox_dict['top'] + bbox_dict['height']

        if language.lower() == "digits":
            language = "Digits"
        textType = textType.lower()
        if "full" in ocrType.lower():
            filename = source_file.split("/")[:-1]
            filename.append("tempzone.png")
            filename = "/".join(filename)
            im = Image.open(source_file)
            print(im.size)
            im1 = im.crop((x1, y1, x2, y2))
            im1.save(filename)
            post_data = {"x1": "0", "y1": "0", "x2": "0", "y2": "0", "textType": textType, "language": language}

        elif "zonal" in ocrType.lower():
            filename = source_file
            post_data = {"x1": str(x1), "y1": str(y1), "x2": str(x2), "y2": str(y2), "textType": textType,
                         "language": language}

        files = {'file1': (open(filename, 'rb'))}
        r = requests.post(url_zonal, files=files, headers=post_data)
        print(r)
        return r.json()["data"]
    except:
        return "OCR error"


def getCheckMark(source_file, x1, y1, x2, y2):
    bbox_dict = {}
    bbox_dict["left"] = x1
    bbox_dict["top"] = y1
    bbox_dict["width"] = x2
    bbox_dict["height"] = y2
    
    val = getZonalOCR(source_file, bbox_dict, "", "zonal", "checkmark")
    return val


def getCausality(source_file, x1, y1, x2, y2, textType="normal"):
    url_zonal = base_URL + "/api/zonal"
    post_data = {"x1": str(x1), "y1": str(y1), "x2": str(x2), "y2": str(y2), "textType": textType}
    files = {'file1': (open(source_file, 'rb'))}
    r = requests.post(url_zonal, files=files, headers=post_data)
    val = r.json()["data"]
    circle = 1
    # print((val))
    if len(val) == 1 and (val is "Y" or val is "N"):
        circle = 0
    return circle


def getFullPageOCR(req_folder):
    png_folder = path.join(req_folder, "png/")
    ocr_folder = path.join(req_folder, "ocr/")
    url_fullpage = base_URL + "/api/fullpage"
    headers = {"input path": png_folder, "output path": ocr_folder}
    r = requests.post(url_fullpage, data=headers)
    return r.json()["data"]


def getmultizonal(csv_file_path, inputdirpath):
    url_multizonal = base_URL + "/api/multizonal"
    files = {"csv": (open(csv_file_path, "rb"))}
    for i in range(len(inputdirpath)):
        files["tiff" + str(i)] = open(inputdirpath[i], "rb")

    r = requests.post(url_multizonal, files=files)
    try:
        returnData = r.json()["data"]

        data = {"label": [list(i.keys())[0] for i in returnData], "text": [i[list(i.keys())[0]] for i in returnData]}
        df = pd.DataFrame(data)
        outputfilename = "/".join(inputdirpath[0].split("/")[:-1] + ["dataframe.csv"])
        df.to_csv(outputfilename, sep="|", index=False)

        return outputfilename
    except:
        return "no output file"
