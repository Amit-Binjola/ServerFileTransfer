from docx_config_generate import fill_json, iter_unique_cells
from common_utils import reading_json
import docx
import pandas as pd
import math


def getData(structural_json_data, metadata_json_data, *arg):
    arg_len = len(arg)
    tableid = arg[0]
    if (arg_len == 1):
        tableid = arg[0]
        rowid = 0
    if (arg_len == 2):
        rowid = arg[1]
        cellid = 0
    if (arg_len == 3):
        rowid = arg[1]
        cellid = arg[2]

    if (tableid) > 0 and tableid <= int(structural_json_data['numberoftables']):
        if (rowid) > 0 and rowid <= int(structural_json_data['tables'][int(tableid) - 1]['numberofrows']):
            if (cellid) > 0 and cellid <= int(
                    structural_json_data['tables'][int(tableid) - 1]['rows'][int(rowid) - 1]['numberofcells']):
                data = metadata_json_data['tables'][int(tableid) - 1]['rows'][int(rowid) - 1]['cells'][int(cellid) - 1][
                    'celldata']
            else:
                if (cellid == 0):
                    data = []
                    for indx in range(len(metadata_json_data['tables'][tableid - 1]['rows'][int(rowid) - 1]['cells'])):
                        data.append(
                            metadata_json_data['tables'][int(tableid) - 1]['rows'][int(rowid) - 1]['cells'][indx][
                                'celldata'])
                else:
                    return "NOT A VALID CELLID"
        else:
            if (rowid == 0):
                data = []
                for indx in range(len(metadata_json_data['tables'][tableid - 1]['rows'])):
                    data2 = []
                    for indx2 in range(len(metadata_json_data['tables'][tableid - 1]['rows'][indx]['cells'])):
                        data2.append(
                            metadata_json_data['tables'][int(tableid) - 1]['rows'][indx]['cells'][indx2]['celldata'])
                    data.append(data2)
            else:
                return "NOT A VALID ROWID"
    else:
        return "NOT A VALID TABLEID"
    return data


def map_table_row_cellid_to_annotation(annotation, form_metadata_json_data, mappingdata_table_row_cell_id, nested_table,
                                       table_id_tomatch, table_id_original):
    json_free_text_data = {}
    mappingdata_row_id = '0'
    mappingdata_cell_id = '0'

    mappingdata_table_id = mappingdata_table_row_cell_id[0]
    mappingdata_row_id = mappingdata_table_row_cell_id[1]
    mappingdata_cell_id = mappingdata_table_row_cell_id[-1]

    if (annotation["annotation"]["annotationtype"] == "simple"):
        if int(mappingdata_table_id) == int(table_id_tomatch):
            data = []
            if not nested_table:
                if mappingdata_row_id == '0':
                    for row in form_metadata_json_data['tables'][int(table_id_tomatch) - 1]['rows']:
                        rowdata = []
                        for cell in row['cells']:
                            rowdata.append(cell['celldata'])
                        data.append(rowdata)
                elif mappingdata_row_id != '0':
                    for row in form_metadata_json_data['tables'][int(table_id_tomatch) - 1]['rows']:
                        if row['rowid'] == mappingdata_row_id:
                            row_tomap = row
                            break
                    if mappingdata_cell_id != '0':
                        for cell in row_tomap["cells"]:
                            if cell["cellid"] == mappingdata_cell_id:
                                cell_tomap = cell
                                break
                        data = cell_tomap['celldata']
                    elif mappingdata_cell_id == '0':
                        rowdata = []
                        for cell in row["cells"]:
                            rowdata.append(cell['celldata'])
                        data.append(rowdata)
            else:
                for row in form_metadata_json_data['tables'][int(table_id_original) - 1]['rows']:
                    rowdata = []
                    for cell in row['cells']:
                        rowdata.append(cell['celldata'])
                    data.append(rowdata)

            json_free_text_data["AnnotID"] = annotation["annotation"]["annotid"]
            json_free_text_data["class"] = annotation["annotation"]["datastring"]["name"]
            json_free_text_data["value"] = data

            return json_free_text_data


def map_tableid_to_annotation(mapping_data, form_metadata_json_data, nested_table, table_id_tomatch, table_id_original):
    json_freetext_list = []
    json_data = {}

    for mapping_vars in mapping_data:
        for annotation in mapping_vars["annotations"]:
            mappingdata_table_row_cell_id = annotation["annotation"]["tablereferenceid"].split("-")
            #            mappingdata_table_id = '4'
            mappingdata_table_id = mappingdata_table_row_cell_id[0]
            if (mappingdata_table_id == table_id_tomatch):

                if len(mappingdata_table_row_cell_id) == 1:
                    mappingdata_table_id = mappingdata_table_row_cell_id[-1]
                    if (annotation["annotation"]["annotationtype"] == "simple"):
                        if int(mappingdata_table_id) == int(table_id_tomatch):
                            data = []
                            if not nested_table:
                                for row in form_metadata_json_data['tables'][int(table_id_tomatch) - 1]['rows']:
                                    rowdata = []
                                    for cell in row['cells']:
                                        rowdata.append(cell['celldata'])
                                    data.append(rowdata)
                            else:
                                for row in form_metadata_json_data['tables'][int(table_id_original) - 1]['rows']:
                                    rowdata = []
                                    for cell in row['cells']:
                                        rowdata.append(cell['celldata'])
                                    data.append(rowdata)

                            json_data["AnnotID"] = annotation["annotation"]["annotid"]
                            json_data["class"] = annotation["annotation"]["datastring"]["name"]
                            json_data["value"] = data

                elif len(mappingdata_table_row_cell_id) == 2:
                    mappingdata_table_id = mappingdata_table_row_cell_id[0]
                    mappingdata_row_id = mappingdata_table_row_cell_id[-1]

                elif len(mappingdata_table_row_cell_id) == 3:
                    print("tablereferenceid = ", mappingdata_table_row_cell_id)
                    json_free_text_data = map_table_row_cellid_to_annotation(annotation, form_metadata_json_data,
                                                                             mappingdata_table_row_cell_id,
                                                                             nested_table,
                                                                             table_id_tomatch, table_id_original)
                    json_freetext_list.append(json_free_text_data)

    if len(json_freetext_list) > 0:
        return json_freetext_list
    else:
        return json_data


def extract_repeated_nested_tables(repeated_nested_tables, mapping_data, metadata_json_data, form_metadata_json_data):
    repeated_nested_tables_data = []
    for repeated_nested_table in repeated_nested_tables:
        if (int(repeated_nested_table['headerrow']) > 0):
            table_id_original = repeated_nested_table['tableid']
            for table in metadata_json_data['tables']:
                if (int(table['headerrow']) > 0):
                    allheaders_check = 0
                    for repeated_header in repeated_nested_table['headertext']:
                        for header in table['headertext']:
                            if (repeated_header['headerrowtext'] == header['headerrowtext']):
                                allheaders_check += 1
                    if (allheaders_check == int(len(table['headerrow']))):
                        table_id_tomatch = table['tableid']
                        break

                    elif (repeated_nested_table['texttomatch']['rownum'] == table['texttomatch']['rownum']):
                        if (repeated_nested_table['texttomatch']['cellnum'] == table['texttomatch']['cellnum']):
                            if (repeated_nested_table['texttomatch']['text'] == table['texttomatch']['text']):
                                table_id_tomatch = table['tableid']
                                break

        elif (repeated_nested_table['texttomatch']['rownum'] and repeated_nested_table['texttomatch']['cellnum'] and
              repeated_nested_table['texttomatch']['text']):

            for table in metadata_json_data['tables']:
                if (repeated_nested_table['texttomatch']['rownum'] == table['texttomatch']['rownum']):
                    if (repeated_nested_table['texttomatch']['cellnum'] == table['texttomatch']['cellnum']):
                        if (repeated_nested_table['texttomatch']['text'] == table['texttomatch']['text']):
                            table_id_tomatch = table['tableid']
                            table_id_original = repeated_nested_table['tableid']
        nested_table = True
        retjson_object = map_tableid_to_annotation(mapping_data, form_metadata_json_data, nested_table,
                                                   table_id_tomatch, table_id_original)

        repeated_nested_tables_data.append(retjson_object)
    return repeated_nested_tables_data


def get_docx_data(filepath, metadata_json_data, mapping_data):
    input_doc = read_file(filepath)
    form_metadata_json_data = fill_json(input_doc)

    retjson = []
    repeated_nested_tables = []
    table_id_original = ""
    nested_table = False

    for table_indx, table in enumerate(form_metadata_json_data['tables']):
        if (int(table['tableid']) <= int(metadata_json_data['numberoftables'])):
            if (form_metadata_json_data['tables'][table_indx]['tableid'] ==
                    metadata_json_data['tables'][table_indx]['tableid']):
                table_id_tomatch = form_metadata_json_data['tables'][table_indx]['tableid']

            else:
                if (int(form_metadata_json_data['tables'][table_indx]['headerrow']) > 0):
                    allheaders_check = 0
                    for header_indx, header in enumerate(
                            form_metadata_json_data['tables'][table_indx]['headertext']):
                        if (form_metadata_json_data['tables'][table_indx]['headertext'][header_indx][
                            'headerrowtext'] == metadata_json_data['tables'][table_indx]['headertext'][header_indx][
                            'headerrowtext']):
                            allheaders_check += 1
                    if (allheaders_check == int(len(form_metadata_json_data['tables'][table_indx]['headerrow']))):
                        table_id_tomatch = form_metadata_json_data['tables'][table_indx]['tableid']

                    elif (form_metadata_json_data['tables'][table_indx]['texttomatch']['rownum'] ==
                          metadata_json_data['tables'][table_indx]['texttomatch']['rownum']):
                        if (form_metadata_json_data['tables'][table_indx]['texttomatch']['cellnum'] ==
                                metadata_json_data['tables'][table_indx]['texttomatch']['cellnum']):
                            if (form_metadata_json_data['tables'][table_indx]['texttomatch']['text'] ==
                                    metadata_json_data['tables'][table_indx]['texttomatch']['text']):
                                table_id_tomatch = form_metadata_json_data['tables'][table_indx]['tableid']


                elif (form_metadata_json_data['tables'][table_indx]['texttomatch']['rownum'] ==
                      metadata_json_data['tables'][table_indx]['texttomatch']['rownum']):
                    if (form_metadata_json_data['tables'][table_indx]['texttomatch']['cellnum'] ==
                            metadata_json_data['tables'][table_indx]['texttomatch']['cellnum']):
                        if (form_metadata_json_data['tables'][table_indx]['texttomatch']['text'] ==
                                metadata_json_data['tables'][table_indx]['texttomatch']['text']):
                            table_id_tomatch = form_metadata_json_data['tables'][table_indx]['tableid']

                retjson_object = map_tableid_to_annotation(mapping_data, form_metadata_json_data, nested_table,
                                                           table_id_tomatch, table_id_original)

            if type(retjson_object) == dict:
                retjson.append(retjson_object)
            elif type(retjson_object) == list:
                retjson.extend(retjson_object)

        elif (int(table['tableid']) > int(metadata_json_data['numberoftables'])):
            repeated_nested_tables.append(table)

    if repeated_nested_tables:
        retjson.extend(extract_repeated_nested_tables(repeated_nested_tables, mapping_data, metadata_json_data,
                                                      form_metadata_json_data))
    return retjson

