#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 31 11:56:10 2020

@author: suresh
"""
import copy
import os
import cv2
import numpy as np
import pandas as pd
import pdfplumber
from digitalpdf_dataextraction import get_key_row_position, get_dataframe
# from imagepdf_dataextraction import generate_df_using_hocr


def hocr_pdf_generator(png_file, pagenum, dpi=500):
    cmd = 'tesseract --dpi'
    cmd = cmd + ' ' + str(dpi)
    cmd = cmd + ' ' + png_file
    cmd = cmd + ' ' + pagenum
    cmd = cmd + ' ' + 'pdf'
    cmd = cmd + ' ' + 'hocr'
    os.system(cmd)
    return "hocr and readable pdf file generated"


def generate_hocr1(png_file):
    hocr_df = pd.DataFrame()

    pagenum = "0"
    hocr_pdf_generator(png_file, pagenum, dpi=300)
    output_hocr = "0.hocr"
    if len(hocr_df) == 0:
        hocr_df = generate_df_using_hocr(output_hocr)
        hocr_df.page_no[0::] = int(pagenum)
    else:
        new_df = generate_df_using_hocr(output_hocr)
        new_df.page_no[0::] = int(pagenum)
        hocr_df = hocr_df.append(new_df)
    hocr_df = hocr_df.reset_index(drop=True)
    hocr_df.to_csv("./word_coordinates.csv", sep="|")
    return hocr_df


#
# png_file = "cropped.png"
# generate_hocr1(png_file)

def get_word_cords1(png_files):
    word_cords = generate_hocr1(png_files)
    word_cords["word"] = word_cords.word.str.strip()
    word_cords["page_no"] = word_cords["page_no"].apply(pd.to_numeric)
    word_cords['word'] = word_cords.word.str.strip()

    return word_cords


def get_dataframe(pdf_file):
    pdf = pdfplumber.open(pdf_file)
    all_text_list = []
    for page_indx in range(len(pdf.pages)):
        page_text = pdf.pages[page_indx].extract_words()
        for word_indx in range(len(page_text)):
            page_text[word_indx]["pageno"] = page_indx
        all_text_list.extend(page_text)
    data = pd.DataFrame(all_text_list)
    return data, pdf


def get_striked_data(pdf_file, start_key, end_key):
    all_word_cords, pdf = get_dataframe(pdf_file)
    all_word_cords["text"] = all_word_cords["text"].astype(str)
    start_time = time.time()
    start_index = 0
    coords = ""
    start_key_pos = get_key_row_position(all_word_cords, start_key, coords, start_index)
    if start_key_pos:
        end_key_pos = get_key_row_position(all_word_cords, end_key, coords, start_key_pos)
        if end_key_pos is None:
            end_key_pos = max(all_word_cords['bottom']) + 1

        if start_key_pos < end_key_pos:
            extracted_data = all_word_cords.iloc[start_key_pos + len(start_key.split(" ")):end_key_pos]
            original_text = " ".join(extracted_data["text"].tolist())

            start_coords = all_word_cords.iloc[start_key_pos]
            end_coords = all_word_cords.iloc[end_key_pos]
            bbox = (extracted_data.iloc[0]['x0'], start_coords['top'], max(extracted_data['x1']), end_coords['top'])
            # bbox = (extracted_data.iloc[0]['x0'], start_coords['top'],max(extracted_data['x1']),end_coords['top'])

            cropped_section = pdf.pages[all_word_cords.iloc[start_key_pos]['pageno']].crop(bbox)
            # cropped_section.to_image(resolution=150).save('cropped.png', format="PNG")

            strike_lines = []
            for line in cropped_section.lines:
                if line['top'] - extracted_data.iloc[0]['top'] >= 1 and extracted_data.iloc[-1]['bottom'] - line['bottom'] >= 1:
                    strike_lines.append(line)

            extracted_data = extracted_data.reset_index(drop=True)
            striked_words_indices = []
            for word_indx, word in extracted_data.iterrows():
                for strike_line in cropped_section.lines:
                    if word['x0'] >= strike_line['x0'] and strike_line['top'] > word['top'] + 2 and \
                            strike_line['bottom'] < word['bottom'] - 2 and strike_line['x1'] >= word['x1']:
                        striked_words_indices.append(word_indx)
                        break
            striked_text =[]
            if striked_words_indices:
                for striked_word_indx in striked_words_indices:
                    striked_text.append(extracted_data.iloc[striked_word_indx]["text"])

                final_text_df = extracted_data.drop(striked_words_indices)
                final_text = " ".join(final_text_df["text"])
            else:
                final_text = original_text
    
    end_time = time.time()

    return original_text, striked_text , final_text


#pdf_file = "/home/aditya/sample_forms/icsr_new_updated2.pdf"
start_key = "Signs and Symptoms"
end_key = "Clinical Course"

import time


original_text , striked_text , final_text = get_striked_data(pdf_file, start_key, end_key)




'''

 4th line
 {'x0': Decimal('183.825'),
 'y0': Decimal('277.793'),
 'x1': Decimal('600.433'),
 'y1': Decimal('277.793'),
 'width': Decimal('416.608'),
 'height': Decimal('0.000'),
 'pts': [(Decimal('183.825'), Decimal('277.793')),
  (Decimal('600.433'), Decimal('277.793'))],
 'linewidth': Decimal('0.207'),
 'stroke': True,
 'fill': False,
 'evenodd': False,
 'stroking_color': None,
 'non_stroking_color': 0,
 'object_type': 'line',
 'page_number': 1,
 'top': Decimal('513.207'),
 'bottom': Decimal('513.207'),
 'doctop': Decimal('513.207')}
'''

# def get_dataframe_new(pdf_file):
#     pdf = pdfplumber.open(pdf_file)
#     all_text_list = []
#     for page_indx in range(len(pdf.pages)):
#         page_text = pdf.pages[page_indx].extract_words()
#         for word_indx in range(len(page_text)):
#             page_text[word_indx]["pageno"] = page_indx
#         all_text_list.extend(page_text)
#     data = pd.DataFrame(all_text_list)
#     data.to_csv("/home/suresh/Desktop/Aries_digitalpdf_git/generic-form-parser/src/word_cords.csv", index=False)
#     all_word_cords = pd.read_csv("/home/suresh/Desktop/Aries_digitalpdf_git/generic-form-parser/src/word_cords.csv",
#                                  sep=',')
#     return all_word_cords, pdf


# def get_strikethrough_underline_coords(gray_image):
#    if len(gray_image.shape)==3:
#        gray_image = cv2.cvtColor(gray_image,cv2.COLOR_BGR2GRAY)
#    thresh = cv2.threshold(gray_image, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
#    cv2.imshow("img",thresh)
#    cv2.waitKey(0)
#    cv2.destroyAllWindows()
#    # Remove horizontal
#    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15,1))
#    detected_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, horizontal_kernel, iterations=2)
#    contours_list = cv2.findContours(detected_lines, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#    contours_list = contours_list[0] if len(contours_list) == 2 else contours_list[1]
#
#    cv2.imshow("img",detected_lines)
#    cv2.waitKey(0)
#    cv2.destroyAllWindows()
#
#    # cnts = [left,top;right,bottom]
#    line_coords = []
#    for contour in contours_list:
#        line_coords.append((contour[0][0][0],contour[0][0][1],contour[1][0][0],contour[1][0][1]))
#
#    MIN_LINE_PATTERN_LENGTH = 15
#    ADDITIONAL_ROWS_TO_IGNORE = 2
#    ADDITIONAL_ROWS_TO_CONSIDER = 2
#    white_line = (np.ones((2,gray_image.shape[1]),dtype="int32"))*255
#    strike_line_coord = []
#    underline_coord = []
#    for coord in line_coords:
#        line_length = abs(coord[2]-coord[0])
#        row_start = coord[1]+ADDITIONAL_ROWS_TO_IGNORE
#        row_end = coord[1]+ADDITIONAL_ROWS_TO_IGNORE+ADDITIONAL_ROWS_TO_CONSIDER
#        if row_start < gray_image.shape[0] and row_end <= gray_image.shape[1]:
#            next_two_rows = gray_image[coord[1]+ADDITIONAL_ROWS_TO_IGNORE:row_end,:]
#            row_diff = sum(sum(white_line-next_two_rows))
#            if row_diff > 255*19 and coord[1]>1 and line_length > MIN_LINE_PATTERN_LENGTH:
#                strike_line_coord.append(coord)
#            else:
#                 if coord[1] > 1 and line_length > MIN_LINE_PATTERN_LENGTH:
#                    underline_coord.append(coord)
#        else:
#            underline_coord.append(coord)
#    underline_coord = sorted(underline_coord, key=lambda x: x[1])
#    strike_line_coord = sorted(strike_line_coord, key=lambda x: x[1])
#    return strike_line_coord, underline_coord
#
# gray_image = cv2.imread("/home/suresh/Desktop/strikethrough_pcs/2.png",0)
# strike_line_coord, underline_coord = get_strikethrough_underline_coords(gray_image)
# print("strike_line_coord = ",strike_line_coord, "underline_coord = ",underline_coord)
#
# def get_data():
#    pdf_file = "/home/suresh/Desktop/forms/Aries_pvi/Fw__ARIES_PVI_-_PDF_follow--up_processing/icsr_new_updated.pdf"
#    all_word_cords,pdf = get_dataframe_new(pdf_file)
#    all_word_cords["text"] = all_word_cords["text"].astype(str)
#    start_index = 0
#    coords = ""
#
#    start_key = "Signs and Symptoms"
#    end_key = "Clinical Course"
#    start_index = 0
#    coords = ""
#
#    start_key_pos = get_key_row_position(all_word_cords,start_key,coords,start_index)
#
#    if start_key_pos:
#        end_key_pos = get_key_row_position(all_word_cords,end_key,coords,start_key_pos)
#        print('start key =', start_key_pos,'\nend key =',end_key_pos)
#
#        extracted_data = all_word_cords.iloc[start_key_pos+len(start_key.split(" ")):end_key_pos]
#        print("\nextracted data = \n",extracted_data)
#        start_coords = all_word_cords.iloc[start_key_pos]
#        end_coords = all_word_cords.iloc[end_key_pos]
#        bbox = (extracted_data.iloc[0]['x0'], start_coords['top']+2.5,max(extracted_data['x1']),end_coords['top'])
#        cropped_section = pdf.pages[extracted_data['pageno'].iloc[0]].crop(bbox)
#        cropped_section.to_image(resolution=150).save('cropped.png',format="PNG")
#        gray_image = cv2.imread("cropped.png",0)
#        strike_line_coord, underline_coord = get_strikethrough_underline_coords(gray_image)
#        strike_line_plumber_coord = []
#        for coord in strike_line_coord:
#            strike_line_plumber_coord.append(convert_UI_coord_list_to_plumber(coord))
#        underline_plumber_coord = []
#        for coord in underline_coord:
#            underline_plumber_coord.append(convert_UI_coord_list_to_plumber(coord))
#
#        left,top,right,bottom = bbox
#        bottom = extracted_data.iloc[0]['bottom']
#        strike_line_new = []
#        for cord in strike_line_plumber_coord:
#            strike_line_new.append([cord[0]+left,cord[1]+top,cord[2]+right,cord[3]+bottom])
#
#        extracted_data[(extracted_data["x0"]>=strike_line_new[0][0]-2) &
#                       (extracted_data["top"]>=strike_line_new[0][1]-2)]['text']
#
##                       (extracted_data["bottom"]>=strike_line_new[0][3]-2)]['text']
#
#        extracted_data[(extracted_data['x0']>183) & (extracted_data['top']<509) & (extracted_data['top']>508) & (extracted_data['x1']>194)]['text']
#        extracted_data[(extracted_data['x0']>183) & (extracted_data['top']<509) & (extracted_data['top']>508) & (extracted_data['x1']>194)]['text']
#        extracted_data[(extracted_data['x0']>183) & (extracted_data['top']<512.46) & (extracted_data['top']>508) & (extracted_data['x1']>194)]['text']
#
#
#    return ""

# get_data(pdf_file)


#
# linebyline_data = []
# temp = []
# temp_indx = 0
# for i in range(0,len(extracted_data)):
#    btm = extracted_data.iloc[i]['bottom']
#    top = extracted_data.iloc[i]['top']
#    if i==0:
#        temp.append(extracted_data.iloc[i]['text'])
#
#    if i>0:
#        previous_btm = extracted_data.iloc[i-1]['bottom']
#        previous_top = extracted_data.iloc[i-1]['top']
#        if abs(btm - previous_btm) < 2: # and abs(btm - previous_top) < 3:
#            temp.append(extracted_data.iloc[i]['text'])
#        else:
#            temp.append(extracted_data.iloc[i]['text'])
#            linebyline_data.append(temp)
#            temp = []
#    if i == len(extracted_data):
#        if abs(btm - previous_btm) < 2: # and abs(btm - previous_top) < 3:
#            temp.append(extracted_data.iloc[i]['text'])


# def get_data(pdf_file,start_key,end_key):
#    ORIGINAL_TEXT = ""
#    extracted_data_copy = ""
#    all_word_cords,pdf = get_dataframe_new(pdf_file)
#    all_word_cords["text"] = all_word_cords["text"].astype(str)
#
#    start_index = 0
#    coords = ""
#    start_key_pos = get_key_row_position(all_word_cords,start_key,coords,start_index)
#    if start_key_pos:
#        end_key_pos = get_key_row_position(all_word_cords,end_key,coords,start_key_pos)
#        if end_key_pos is None:
#            end_key_pos = max(all_word_cords['bottom'])+1
#        if start_key_pos < end_key_pos:
#            extracted_data = all_word_cords.iloc[start_key_pos+len(start_key.split(" ")):end_key_pos]
#
#            start_coords = all_word_cords.iloc[start_key_pos]
#            end_coords = all_word_cords.iloc[end_key_pos]
#            bbox = (extracted_data.iloc[0]['x0'], start_coords['top']+2.5,max(extracted_data['x1']),end_coords['top'])
##                bbox = (extracted_data.iloc[0]['x0'], start_coords['top'],max(extracted_data['x1']),end_coords['top'])
#
#            cropped_section = pdf.pages[extracted_data['pageno'].iloc[0]].crop(bbox)
#            try:
#                cropped_section.to_image(resolution=150).save('cropped.png',format="PNG")
#                strike_lines_plumber_coords = cropped_section.lines
#            except:
#                strike_lines_plumber_coords = []
##            print("\nstrike_lines_plumber_coords=",strike_lines_plumber_coords)
#            index_to_drop = []
#            for line_no in range(len(strike_lines_plumber_coords)):
#                indices = extracted_data[(extracted_data['x0']>=strike_lines_plumber_coords[line_no]["x0"]-2)
#                & (extracted_data['bottom']<=strike_lines_plumber_coords[line_no]["bottom"]+8) &
#                (extracted_data['top']>=strike_lines_plumber_coords[line_no]["top"]-8) &
#                 (extracted_data['x1']<=strike_lines_plumber_coords[line_no]["x0"]+strike_lines_plumber_coords[line_no]["width"]+1) ].index
#
#                if indices.tolist():
#                    index_to_drop.extend(indices.tolist())
#
#            extracted_data_copy = extracted_data.drop(index_to_drop,axis=0)['text'].tolist()
#            extracted_data_copy = " ".join(extracted_data_copy)
#            ORIGINAL_TEXT = " ".join(extracted_data["text"].tolist())
#
#    return ORIGINAL_TEXT,extracted_data_copy
#

# def get_data(pdf_file,start_key,end_key):
#    ORIGINAL_TEXT = ""
#    extracted_data_copy = ""
#    all_word_cords,pdf = get_dataframe_new(pdf_file)
#    all_word_cords["text"] = all_word_cords["text"].astype(str)
#
#    start_index = 0
#    coords = ""
#    start_key_pos = get_key_row_position(all_word_cords,start_key,coords,start_index)
#
#
#    if start_key_pos:
#        end_key_pos = get_key_row_position(all_word_cords,end_key,coords,start_key_pos)
#        if end_key_pos is None:
#            end_key_pos = max(all_word_cords['bottom'])+1
#        if start_key_pos < end_key_pos:
#            extracted_data = all_word_cords.iloc[start_key_pos+len(start_key.split(" "))-1:end_key_pos]
#
#            start_coords = all_word_cords.iloc[start_key_pos]
#            end_coords = all_word_cords.iloc[end_key_pos]
#            bbox = (extracted_data.iloc[0]['x0'], start_coords['top'],max(extracted_data['x1']),end_coords['top'])
##                bbox = (extracted_data.iloc[0]['x0'], start_coords['top'],max(extracted_data['x1']),end_coords['top'])
#
#            cropped_section = pdf.pages[extracted_data['pageno'].iloc[0]].crop(bbox)
#            try:
#                cropped_section.to_image(resolution=150).save('cropped.png',format="PNG")
#                strike_lines_plumber_coords = cropped_section.lines
#            except:
#                strike_lines_plumber_coords = []
##            print("\nstrike_lines_plumber_coords=",strike_lines_plumber_coords)
#            index_to_drop = []
#            for line_no in range(len(strike_lines_plumber_coords)):
#                indices = extracted_data[(extracted_data['x0']>=strike_lines_plumber_coords[line_no]["x0"]-2)
#                & (extracted_data['bottom']<=strike_lines_plumber_coords[line_no]["bottom"]+12) &
#                (extracted_data['top']>=strike_lines_plumber_coords[line_no]["top"]-12) &
#                 (extracted_data['x1']<=strike_lines_plumber_coords[line_no]["x0"]+strike_lines_plumber_coords[line_no]["width"]+1) ].index
#
#                if indices.tolist():
#                    index_to_drop.extend(indices.tolist())
#
#            extracted_data_copy = extracted_data.drop(index_to_drop,axis=0)['text'].tolist()
#            extracted_data_copy = " ".join(extracted_data_copy)
#            ORIGINAL_TEXT = " ".join(extracted_data["text"].tolist())
#
#    return ORIGINAL_TEXT,extracted_data_copy


# def get_data(pdf_file,start_key,end_key):
#    ORIGINAL_TEXT = ""
#    extracted_data_copy = ""
#    all_word_cords,pdf = get_dataframe_new(pdf_file)
#    all_word_cords["text"] = all_word_cords["text"].astype(str)
#
#    start_index = 0
#    coords = ""
#    start_key_pos = get_key_row_position(all_word_cords,start_key,coords,start_index)
#
#    if start_key_pos:
#        end_key_pos = get_key_row_position(all_word_cords,end_key,coords,start_key_pos)
#        if end_key_pos is None:
#            end_key_pos = max(all_word_cords['bottom'])+1
#        if start_key_pos < end_key_pos:
#            extracted_data = all_word_cords.iloc[start_key_pos+len(start_key.split(" "))-1:end_key_pos]
#
#            start_coords = all_word_cords.iloc[start_key_pos]
#            end_coords = all_word_cords.iloc[end_key_pos]
#            bbox = (extracted_data.iloc[0]['x0'], start_coords['top'],max(extracted_data['x1']),end_coords['top'])
#            cropped_section = pdf.pages[extracted_data['pageno'].iloc[0]].crop(bbox)
##            cropped_section.to_image(resolution=150).save('cropped.png',format="PNG")
#            strike_lines_plumber_coords = cropped_section.lines
##
##            all_lines_top_coords = []
##            for coord in strike_lines_plumber_coords:
##                all_lines_top_coords.append(float(coord["top"]))
##
##            all_lines_top_coords = list(set(all_lines_top_coords))
##            all_lines_top_coords.sort(reverse = False)
#
#            index_to_drop = []
#            extracted_data_indices = list(extracted_data.index)
#            for row_num in range(len(extracted_data)):
#                word = extracted_data.iloc[row_num]
#                for line in strike_lines_plumber_coords:
#                    if word['top'] < float(line['y0']) and word['bottom']>float(line['bottom']) and word['x0'] == float(line['x0']) and word['x1']==float(line['x1']):
#                        index_to_drop.append(extracted_data_indices[row_num])
#
#
#            extracted_data_copy = extracted_data.drop(index_to_drop,axis=0)['text'].tolist()
#            extracted_data_copy = " ".join(extracted_data_copy)
#            ORIGINAL_TEXT = " ".join(extracted_data["text"].tolist())
#
#    return ORIGINAL_TEXT,extracted_data_copy

pdf_file = "/home/suresh/Desktop/forms/Aries_pdf/icsr_new_updated2.pdf"
# pdf_file = "/home/suresh/Desktop/forms/Aries_pvi/Fw__ARIES_PVI_-_PDF_follow--up_processing/icsr_new_updated_deletd.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/ARIES_Form_Demo1.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/ARIES_Form_Demo6.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/ARIES_Form_DemoAll3.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/ARIES_Form_Demostrikeonly.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/ARIES_Form_Demonormalonly.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/ARIES_Form_Demounderlineonly.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/ARIES_Form_Demounderlineandnormal.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/underlinestrikeout.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/normalstrikeout.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/complex.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/font.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/font8.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/font8_normal.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/font9_normal.pdf"
# pdf_file = "/home/suresh/Desktop/aries_pdf/font9_all.pdf"
#pdf_file = "/home/suresh/Desktop/aries_pdf/font10.pdf"


# ORIGINAL_TEXT,extracted_data_copy = get_data(pdf_file,start_key,end_key)
# print("\n ORIGINAL_TEXT = \n",ORIGINAL_TEXT)
# print("\n OUTPUT = \n",extracted_data_copy)

#
# start_key = "Course of Treatment"
# end_key = "Evidence Supporting Recovery"
# ORIGINAL_TEXT,extracted_data_copy = get_data(pdf_file,start_key,end_key)
# print("\n ORIGINAL_TEXT = \n",ORIGINAL_TEXT)
# print("\n OUTPUT = \n",extracted_data_copy)
#
#
# start_key = "Narrative"
# end_key = ""
# ORIGINAL_TEXT,extracted_data_copy = get_data(pdf_file,start_key,end_key)
# print("\n ORIGINAL_TEXT = \n",ORIGINAL_TEXT)
# print("\n OUTPUT = \n",extracted_data_copy)
#
#
# start_key = "Follow up Clinical Course"
# end_key = "Toxicity Grade"
# ORIGINAL_TEXT,extracted_data_copy = get_data(pdf_file,start_key,end_key)
# print("\n ORIGINAL_TEXT = \n",ORIGINAL_TEXT)
# print("\n OUTPUT = \n",extracted_data_copy)
