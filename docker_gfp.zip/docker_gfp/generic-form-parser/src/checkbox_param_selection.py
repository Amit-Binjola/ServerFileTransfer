#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 17:39:01 2020

@author: suresh
"""

import cv2, json, urllib, numpy as np
from config import config_json_path, CONFIG_JSON


def url_to_image(url):
    resp = urllib.request.urlopen(url)
    image = np.asarray(bytearray(resp.read()), dtype="uint8")
    image = cv2.imdecode(image, cv2.IMREAD_COLOR)
    return image


def filter_white_pixel_index(white_indx, edges):
    row, col = edges.shape
    filtered_white_position = []
    for pix in white_indx:
        if abs(pix[0] - row) > 10 and abs(pix[1] - col) > 10 and pix[1] > 10 and pix[1] < col - 5 and pix[0] > 10 and \
                pix[0] < row - 5:
            filtered_white_position.append(list(pix))

    return filtered_white_position


def get_params(config_checkbox, req_folder):
    cbox_params_all = {}

    #    WIDTH_THRESH = CONFIG_JSON['checkbox_constants']['WIDTH_THRESH']
    GRAY_REMOVAL_THRESH = CONFIG_JSON['checkbox_constants']['GRAY_REMOVAL_THRESH']

    for cord_index in range(len(config_checkbox)):
        img_path = "/home/suresh/backendservice/utility/uploads/temp1/png/form_png-0.png"
        pageno = config_checkbox.iloc[cord_index]['pageno']
        if pageno == "-1.0":
            pageno = "0"
        #        img_path = req_folder + "/png/form_png-" + pageno + ".png"
        cbox_cords = config_checkbox.iloc[cord_index]['annotcoords'].split(",")
        left, top, right, bottom = int(cbox_cords[0].strip()), int(cbox_cords[1].strip()), int(
            cbox_cords[2].strip()), int(cbox_cords[3].strip())
        img = cv2.imread(img_path, 0)
        _, img = cv2.threshold(img, GRAY_REMOVAL_THRESH, 255, 0)
        cbox_img = img[top:top + bottom, left:left + right]
        #        cv2.imwrite("/home/suresh/Desktop/cbox/cbox/" + str(config_checkbox.iloc[cord_index]['annotcoords'].replace(",","_")) + ".png",cbox_img)
        #        cv2.imshow('new_img', cbox_img)
        #        cv2.waitKey(0)
        #        cv2.destroyAllWindows()
        try:
            _, contours, __ = cv2.findContours(cbox_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        except:
            contours, __ = cv2.findContours(cbox_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
        #        x_pos_max, y_pos_max, width_max, height_max = cv2.boundingRect(max(contours, key=cv2.contourArea))
        #        cbox_img_max = cbox_img[y_pos_max:y_pos_max+height_max,x_pos_max:x_pos_max+width_max]
        #        cv2.imshow('cbox_img_max', cbox_img_max)
        #        cv2.waitKey(0)
        #        cv2.destroyAllWindows()
        x_pos_min, y_pos_min, width_min, height_min = cv2.boundingRect(min(contours, key=cv2.contourArea))
        cbox_img_min = cbox_img[y_pos_min:y_pos_min + height_min, x_pos_min:x_pos_min + width_min]
        #        cv2.imshow('cbox_img_min', cbox_img_min)
        #        cv2.waitKey(0)
        #        cv2.destroyAllWindows()
        cv2.imwrite("/home/suresh/Desktop/cbox/cbox/" + str(
            config_checkbox.iloc[cord_index]['annotcoords'].replace(",", "_")) + "_cbox.png", cbox_img_min)
        #        cv2.imwrite("/home/suresh/Desktop/cbox/cbox/" + str(config_checkbox.iloc[cord_index]['annotcoords'].replace(",","_")) + "_max.png",cbox_img_max)
        cbox_dict = {}
        cbox_dict['height_min'] = height_min - 12
        cbox_dict['height_max'] = height_min + 25
        cbox_dict['width_min'] = width_min - 12
        cbox_dict['width_max'] = width_min + 25

        cbox_params_all = {config_checkbox.iloc[cord_index]['name']: cbox_dict}

    CONFIG_JSON['checkbox_params'] = cbox_params_all
    with open(config_json_path, "w") as outfile:
        outfile.write(json.dumps(CONFIG_JSON, indent=4))

    return "done"


def get_cbox_params(img_path, cbox_cords, checkbox_type):
    cbox_params_all = {}
    GRAY_REMOVAL_THRESH = CONFIG_JSON['checkbox_constants']['GRAY_REMOVAL_THRESH']

    cbox_cords = cbox_cords.split(",")
    left, top, right, bottom = int(cbox_cords[0].strip()), int(cbox_cords[1].strip()), int(cbox_cords[2].strip()), int(
        cbox_cords[3].strip())
    img = cv2.imread(img_path, 0)
    _, img = cv2.threshold(img, GRAY_REMOVAL_THRESH, 255, 0)
    cbox_img = img[top:top + bottom, left:left + right]
    try:
        _, contours, __ = cv2.findContours(cbox_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    except:
        contours, __ = cv2.findContours(cbox_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    x_pos, y_pos, width, height = cv2.boundingRect(min(contours, key=cv2.contourArea))
    cbox_img = cbox_img[y_pos:y_pos + height, x_pos:x_pos + width]

    cbox_dict = {}
    cbox_dict['height_min'] = height - 12
    cbox_dict['height_max'] = height + 25
    cbox_dict['width_min'] = width - 12
    cbox_dict['width_max'] = width + 25

    cbox_params_all[checkbox_type] = cbox_dict

    CONFIG_JSON['checkbox_params'] = cbox_params_all
    with open(config_json_path, "w") as outfile:
        outfile.write(json.dumps(CONFIG_JSON, indent=4))

    return "done"


# get rectangle checkbox paramaters automatically,  get checked checkbox from UI
# getting checked checkbox is not possible always
def get_rectangle_checkbox_params(img_path, coords):
    WIDTH_THRESH = CONFIG_JSON['checkbox_constants']['WIDTH_THRESH']
    GRAY_REMOVAL_THRESH = CONFIG_JSON['checkbox_constants']['GRAY_REMOVAL_THRESH']

    try:
        img = url_to_image(img_path)
    except:
        img = cv2.imread(img_path, 0)

    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if coords:
        x_pos, top, y_pos, bottom = coords.split(",")
        x_pos = int(x_pos.strip())
        y_pos = int(y_pos.strip())
        top = int(top.strip())
        bottom = int(bottom.strip())
        cbox_img = img[y_pos:y_pos + bottom, x_pos:x_pos + top]

    row, col = img.shape
    _, img = cv2.threshold(cbox_img, GRAY_REMOVAL_THRESH, 255, 0)
    cv2.imshow('new_img', cbox_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    CLASSIFIER_THRESH = []
    try:
        _, contours, __ = cv2.findContours(cbox_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    except:
        contours, __ = cv2.findContours(cbox_img, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    img = 255 - img
    width_all = []
    height_all = []
    for cnt in contours:
        x_pos, y_pos, width, height = cv2.boundingRect(cnt)
        if x_pos > 0 and y_pos > 0 and width >= WIDTH_THRESH:
            cbox_img = cbox_img[y_pos:y_pos + height, x_pos:x_pos + width]
            #            cv2.imshow('new_img', cbox_img)
            #            cv2.waitKey(0)
            #            cv2.destroyAllWindows()
            edges = cv2.Canny(cbox_img, 100, 200)
            white_indx = np.argwhere(edges == 255)
            filtered_white_position = filter_white_pixel_index(white_indx, edges)
            #            diag_pixels = cbox_img.diagonal()[DIAGONAL_PIXELS_TO_IGNORE:-DIAGONAL_PIXELS_TO_IGNORE]
            #            CLASSIFIER_THRESH.append(np.sum(diag_pixels))
            if len(filtered_white_position) > 0:
                CLASSIFIER_THRESH.append(len(filtered_white_position) / 3)
            else:
                CLASSIFIER_THRESH.append(0)

            width_all.append(width)
            height_all.append(height)

    CLASSIFIER_THRESH = np.mean(CLASSIFIER_THRESH)
    if len(width_all) > 0 and len(height_all):
        width_min = min(width_all)
        width_max = max(width_all)
        height_min = min(height_all)
        height_max = max(height_all)

        CONFIG_JSON['checkbox_params']["width_min"] = width_min
        CONFIG_JSON['checkbox_params']["height_min"] = height_min
        CONFIG_JSON['checkbox_params']["width_max"] = width_max
        CONFIG_JSON['checkbox_params']["height_max"] = height_max
        CONFIG_JSON['checkbox_params']["classifier_threshold"] = CLASSIFIER_THRESH
        json_object = json.dumps(CONFIG_JSON, indent=4)
        with open(config_json_path, "w") as outfile:
            outfile.write(json_object)
        output_status = "checkbox parameters are updated in config file"
    else:
        output_status = "try again"
    return output_status

# img_path = "/home/suresh/Desktop/cbox/Screenshot from 2020-08-17 16-46-59.png"  # bw image  unchecked - works
# img_path = "/home/suresh/Desktop/cbox/Screenshot from 2020-08-19 15-29-09.png"  # bw image  checked  - not working bcos checkbox size is small
# img_path = "/home/suresh/Desktop/cbox/Screenshot from 2020-08-19 12-41-57.png"  # gray image unchecked - works
# img_path = "/home/suresh/Desktop/cbox/Screenshot from 2020-08-19 12-42-08.png"  # gray image checked  - works
# img_path = "/home/suresh/Desktop/cbox/Screenshot from 2020-08-19 15-49-26.png"  # bw image checked - working

#
# img_path = "/home/suresh/backendservice/utility/uploads/temp1/png/form_png-0.png"
# coords = "3673 , 1683 , 93 , 97"
# cbox_cords = coords.split(",")
# left, top, right, bottom = int(cbox_cords[0].strip()), int(cbox_cords[1].strip()),int(cbox_cords[2].strip()),int(cbox_cords[3].strip())
# img = cv2.imread(img_path,0)
# cbox_img = img[top:top + bottom, left:left + right]
##cv2.imshow('new_img', cbox_img)
##cv2.waitKey(0)
##cv2.destroyAllWindows()
#
#
# get_rectangle_checkbox_params(img_path,coords)
