import pytesseract
import re
from config import NULL_CHECK

#this is to split given OCR text into rows
def RegexBasedTableRowSplitter(text, row_pattern):
    row_list = []
    flag = True
    table_raw_data = text.split("\n")
    table_raw_data = list(filter(None, table_raw_data))
    if table_raw_data!=[]:
        if row_pattern in ["\n", "\\n"]:
            row_list = table_raw_data
        else:
            row = ""
            for row_data in table_raw_data:
                row_match = re.search(row_pattern, row_data)
                if row_match:
                    if flag:
                        row = row_data
                        flag = False
                    else:
                        row_list.append(row)
                        row = row_data
                else:
                    if flag == False:
                        row = row + " " + row_data
            row_list.append(row)
    return row_list


#this is to split given OCR text into columns
def RegexBasedTableColumnSplitter(row_list, column_pattern):
    if column_pattern not in [None, ""]:
        table_list = []
        patterns = column_pattern.split("||")
        for row_data in row_list:
            col_data = []
            for col_pattern in patterns:
                matched_col_data = re.search(col_pattern, row_data)
                if matched_col_data == None:
                    value = ""
                else:
                    value = matched_col_data.group()
                col_data.append(value)
            table_list.append(col_data)
    else:
        table_list = row_list
    return table_list

'''
# this is to split given OCR text into rows
def RegexBasedTableRowSplitter(text, row_pattern):
    row_pattern = re.compile(row_pattern)
    rows_data = re.split(row_pattern, text)
    rows_data = list(filter(None,rows_data))
    return rows_data


# this is to split given OCR text into columns
def RegexBasedTableColumnSplitter(rows_data, column_pattern):
    table_data = []
    if column_pattern not in NULL_CHECK:
        col_pattern = re.compile(column_pattern)
        for row_data in rows_data:
            if re.findall(col_pattern,row_data):
                table_data.append(re.split(col_pattern, row_data))

    if not table_data or column_pattern in NULL_CHECK:
        table_data = [[row] for row in rows_data]

    return table_data
'''

# method calling starts form here
def RegexBasedTableParser(data, config_data):
    row_pattern = config_data["rowdelimiter"].replace("regex::", "")
    column_pattern = config_data["columndelimiter"].replace("regex::", "")
    if row_pattern not in NULL_CHECK:
        data = RegexBasedTableRowSplitter(data, row_pattern)

    data = RegexBasedTableColumnSplitter(data, column_pattern)

    return data




"""
image1 = Image.open("/home/akshatha/Desktop/img3.png")
image2 = Image.open("/home/akshatha/Desktop/img2.png")
Table_data1 = RegexBasedTableParser(image1, "^#\d{1,2}\s*\)", "(^#\d{1,2}\s*\))||\).*\(||\(.*\)||;.*$")
Table_data2 = RegexBasedTableParser(image2, "\n", "^.*\s\[||\s\[.*$")
print(Table_data1)
print(Table_data2)
"""

#data = "STROKE [Cerebrovascular accident]\nTHROMBOEMBOLIC COMPLICATION (BRAINSTEM) [Embolism]\nCase Description: MCN: 2019-25067"
#data = RegexBasedTableParser(data, "\n")
#print(data)