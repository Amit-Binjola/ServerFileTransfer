
import os
import time
import pandas as pd
from digitalpdf_dataextraction import *
from multiprocessing import Pool

global pagewise_annot_data_list

'''pagewise_annot_df = pd.DataFrame(columns=["annotationid", "annotation_type", "annotation_data",
                                                                   "words_df", "confidence", "startstring_pageno",
                  "endstring_pageno", "bbox", "REQ_FOLDER", "garbageremovalregex", "form_config_params",
                  "config", "misc_data", "extracted_data_json"])'''


def get_eval_type(givendata, data_type):
    if type(givendata) == data_type:
        givendata = eval(givendata)
    return givendata


def get_checkbox_status(page_annot_df):
    form_config_params = page_annot_df["form_config_params"]
    bbox = page_annot_df["bbox"]
    afterstr_dict = page_annot_df["misc_data"]["afterstr_dict"]
    cbox_img = np.array(pdf.pages[afterstr_dict['pageno']].crop(bbox).to_image().original)
    cbox_img = cv2.resize(cbox_img, None, fx=form_config_params["checkbox_scale_factor"]["CHECKBOX_X_SCALE_FACTOR"],
                          fy=form_config_params["checkbox_scale_factor"]["CHECKBOX_Y_SCALE_FACTOR"], interpolation=cv2.INTER_CUBIC)
    checkbox_op = checkbox_classifier(cbox_img, "multiple_rectangular_checkbox", form_config_params)
    if checkbox_op == []:
        checkbox_op = ["0"]
    return checkbox_op


def parallelize_words_df(func, pdf):
    global form_config_params
    page_text_df = pd.DataFrame(columns=["x0", "x1", "top", "bottom", "text", "pageno"])
    df1 = pd.DataFrame({"pageno": [i for i in range(len(pdf.pages))]})
    df_split = np.array_split(df1, len(df1))
    pool = Pool(1)
    thread_output = pool.map(func, df_split)
    page_text_df = pd.concat(thread_output, ignore_index=True)
    pool.close()
    pool.join()
    # this part will be used in future
    '''for pno in range(len(df1)):
        op1 = plum_data_ext_thread(df_split[pno], pdf)
        if len(page_text_df) == 0:
            page_text_df = op1
        else:
            page_text_df = pd.concat([page_text_df, op1])'''
    return page_text_df


def plum_data_ext_thread(pno):
    global form_config_params
    pageno = pno.to_dict("records")[0]["pageno"]
    try:
        page_text1 = pdf.pages[pageno].extract_words(y_tolerance=form_config_params["plumber_tolerance"]["PLUMBER_Y_TOLERANCE"], x_tolerance=form_config_params["plumber_tolerance"]["PLUMBER_X_TOLERANCE"])

        if len(page_text1) > 0:
            page_text = pd.DataFrame(page_text1)
            page_text["pageno"] = [pageno for i in range(len(page_text))]
        else:
            page_text = pd.DataFrame([{'pageno': "", 'bottom': "", 'text': 'unwnated_row_to_remove',
                                       'top': "", 'x0': "", 'x1': ""}])
    except:
        page_text = pd.DataFrame([{'pageno': "", 'bottom': "", 'text': 'unwnated_row_to_remove',
                                   'top': "", 'x0': "", 'x1': ""}])
    return page_text


# to extract text based on bbox position
def get_freetext(data_json, REQ_FOLDER, garbage_regex, words_df):
    page_no = int(float(data_json["startstring_pageno"]))

    bbox = get_eval_type(data_json["bbox"], str)
    misc_data = get_eval_type(data_json["misc_data"], str)

    is_beforerefstring_present = misc_data["is_beforerefstring_present"]

    data = []
    if is_beforerefstring_present not in [None, ""]:
        cropped_section = pdf.pages[page_no].crop(bbox)
        extracted_data = ""
        if garbage_regex not in NULL_CHECK and not np.isnan(garbage_regex):
            crp_text = cropped_section.extract_text()
            if crp_text:
                extracted_data = re.sub(garbage_regex, "", crp_text)
        else:
            extracted_data = cropped_section.extract_text()
        if extracted_data:
            extracted_data = extracted_data.split("\n")
            data.extend(extracted_data)
    else:
        start_page = page_no
        bbox_top = bbox[1]
        bbox_left = bbox[0]
        bbox_right = bbox[2]
        last_word_bottom = float(words_df[words_df['pageno'] == start_page].iloc[-1]['bottom']) + 0.5
        bbox = (bbox_left, bbox_top, bbox_right, last_word_bottom)
        cropped_section = pdf.pages[start_page].crop(bbox)
        if garbage_regex not in NULL_CHECK:
            extracted_data = re.sub(garbage_regex, "", cropped_section.extract_text())
        else:
            extracted_data = cropped_section.extract_text()
        if extracted_data:
            extracted_data = extracted_data.split("\n")
            data.extend(extracted_data)

    return data


def get_words_df(page_config_json, pdf):
    words_df = parallelize_words_df(plum_data_ext_thread, pdf)
    garbage_regex = page_config_json.get("garbageremovalregex", "")
    if garbage_regex not in ['', None]:
        for row_index in range(len(words_df['text'])):
            words_df['text'][row_index] = re.sub(garbage_regex, '', words_df['text'][row_index])
            if words_df['text'][row_index] in ['', None]:
                words_df = words_df.drop(row_index)
    words_df.drop(words_df[words_df["text"] == "unwnated_row_to_remove"].index, inplace=True)
    words_df.reset_index(drop=True, inplace=True)
    words_df['text'] = words_df['text'].str.strip()
    words_df = words_df.rename(columns={'x0': 'left', 'x1': 'right'}, index={'ONE': 'one'})
    words_df['left'] = pd.to_numeric(words_df['left'], downcast="float")
    words_df['right'] = pd.to_numeric(words_df['right'], downcast="float")
    words_df['top'] = pd.to_numeric(words_df['top'], downcast="float")
    words_df['bottom'] = pd.to_numeric(words_df['bottom'], downcast="float")
    words_df['pageno'] = pd.to_numeric(words_df['pageno'], downcast="integer")

    header_footer_dict, header_footer_index_all = get_header_footer_position(words_df, page_config_json)

    return words_df, header_footer_dict, header_footer_index_all, garbage_regex


def get_table_output_dict(form_config_params, REQ_FOLDER, page_annot_df):
    page_no = page_annot_df["startstring_pageno"]
    bbox = page_annot_df["bbox"]
    if type(bbox) == str:
        bbox = eval(bbox)
    misc_data = page_annot_df["misc_data"]
    if type(misc_data) == str:
        misc_data = eval(misc_data)
    plumber_matrix_coords = misc_data["plumber_matrix_coords"]

    output_dict = get_table_data(pdf, page_no, bbox, REQ_FOLDER, form_config_params,
                                plumber_matrix_coords, page_annot_df)

    return output_dict


def get_all_data(page_annot_df):
    output = ""
    page_annot_df = page_annot_df.to_dict('records')[0]
    if page_annot_df["annotationid"] not in [None, ""]:
        if page_annot_df["annotation_type"] == "freetext":
            output = get_freetext(page_annot_df, page_annot_df["REQ_FOLDER"], page_annot_df["garbageremovalregex"],
                                       page_annot_df["words_df"])
        elif page_annot_df["annotation_type"] == "table":
            output = get_table_output_dict(page_annot_df["form_config_params"], page_annot_df["REQ_FOLDER"],
                                                page_annot_df)
        elif page_annot_df["annotation_type"] == "image":
            output = get_checkbox_status(page_annot_df)

    return output


# to extract table data for the given page-wise annotation info: will be called multithreaded method
def get_table_data(pdf, page_no, bbox, REQ_FOLDER, form_config_params,
                   plumber_matrix_coords, pagewise_annot_df):
    page_no = int(float(page_no))
    columntypes_initial = get_eval_type(pagewise_annot_df["annotation_data"], str)
    columntypes = columntypes_initial["coltypes"].split("||")
    table_data = []
    if pagewise_annot_df["annotation_data"]["borderedtable"] and "text" not in columntypes and "image" in columntypes:
        cropped_table = pdf.pages[page_no].crop(bbox)
        cropped_table_df = pd.DataFrame(cropped_table.extract_words())
        data = get_table_with_only_checkboxes(pdf, page_no, bbox, pagewise_annot_df["annotation_data"], REQ_FOLDER, form_config_params, cropped_table_df)
        # 2nd page_no - crosscheck: whether to increment by 1 or not
        table_data = appending_tabledata(table_data, data, page_no, page_no, pagewise_annot_df["annotation_data"])

    elif pagewise_annot_df["annotation_data"]["borderedtable"] and "text" in columntypes:
        data = crop_and_extract(pdf, page_no, bbox, pagewise_annot_df["annotation_data"], plumber_matrix_coords)
        if len(data) > 0:
            table_data = data[0]
    elif pagewise_annot_df["annotation_data"]["virtualtable"] and pagewise_annot_df["annotation_data"]["colsep"].lower() == "position":
        header_footer_dict = pagewise_annot_df["misc_data"]["header_footer_dict"]
        words_df = pagewise_annot_df["words_df"]
        tableendstr_dict = pagewise_annot_df["misc_data"]["tableendstr_dict"]
        form_config_params = pagewise_annot_df["form_config_params"]
        page_type = pagewise_annot_df["misc_data"]["page_type"]
        data, merge_cell = crop_and_extract_virtual(pdf, page_no, bbox, pagewise_annot_df["annotation_data"], plumber_matrix_coords,
                                                    header_footer_dict, words_df, page_type, tableendstr_dict,
                                                    form_config_params)
        table_data = appending_virtual_table_data(table_data, data, merge_cell)

    elif pagewise_annot_df["annotation_data"]["virtualtable"] and pagewise_annot_df["annotation_data"]["rowsep"] in \
            ["Regex", "regex"] and pagewise_annot_df["annotation_data"]["colsep"] in ["Regex", "regex"]:
        left = float(pagewise_annot_df["annotation_data"]["annotcoords"].split(",")[0].strip()) * (72 / 500)
        right = left + float(pagewise_annot_df["annotation_data"]["annotcoords"].split(",")[2].strip()) * (72 / 500)
        bbox = [left, bbox[1] - 0.2, right, bbox[3] + 0.2]
        cropped_region = pdf.pages[page_no].crop((bbox))
        regex_text = cropped_region.extract_text(y_tolerance=form_config_params["plumber_tolerance"]["PLUMBER_Y_TOLERANCE"],
                                                 x_tolerance=form_config_params["plumber_tolerance"]["PLUMBER_X_TOLERANCE"])
        data = []
        if regex_text:
            data = RegexBasedTableParser(regex_text, pagewise_annot_df["annotation_data"])
        if len(data) > 0:
            table_data.extend(data)

    elif pagewise_annot_df["annotation_data"]["coltypes"] and "image" in pagewise_annot_df["annotation_data"]["coltypes"].split("||")\
            and "text" in pagewise_annot_df["annotation_data"]["coltypes"].split("||") and plumber_matrix_coords:
            config_data = pagewise_annot_df["words_df"]
            header_footer_dict = pagewise_annot_df["misc_data"]["header_footer_dict"]
            words_df = pagewise_annot_df["words_df"]
            tablestartstr_dict = pagewise_annot_df["misc_data"]["tablestartstr_dict"]
            tableendstr_dict = pagewise_annot_df["misc_data"]["tableendstr_dict"]
            form_config_params = pagewise_annot_df["form_config_params"]
            table_data = get_column_checkboxes(pdf, words_df, config_data, table_data, plumber_matrix_coords,
                                           tablestartstr_dict, tableendstr_dict, REQ_FOLDER, header_footer_dict,
                                           form_config_params)

    table_data = garbage_removed_data(table_data, pagewise_annot_df)
    return table_data


def assign_values_to_dict(output_dict, pagewise_annot_df):
    pagewise_annot_df["extracted_data_json"] = [output_dict[indx][indx] for indx in range(len(output_dict)) ]
    return pagewise_annot_df


def filtering_row_data(data, pagewise_annot_df_tab):
    row_all = data
    if len(pagewise_annot_df_tab) > 0:
        no_of_col = pagewise_annot_df_tab.iloc[0]["annotation_data"].get("coltypes", None)
        if no_of_col:
            no_of_col = len(no_of_col.split("||"))
            row_all = []
            for row in data:
                if len(row) >= no_of_col:
                    row_all.append(row)
    return row_all


def table_dict(pagewise_annot_df, annotid):
    pagewise_annot_df_tab = pagewise_annot_df[pagewise_annot_df["annotationid"] == annotid]
    data = [val for indx in range(len(pagewise_annot_df_tab)) for val in pagewise_annot_df_tab[pagewise_annot_df_tab["annotationid"] == annotid].iloc[indx]["extracted_data_json"] ]
    data = filtering_row_data(data, pagewise_annot_df_tab)
    id = pagewise_annot_df[pagewise_annot_df["annotationid"] == annotid]["extracted_data_json"].keys()[0]

    startrow = ""
    endrow = ""
    if id not in ["", None]:
        startrow = pagewise_annot_df[pagewise_annot_df["annotationid"] == annotid]["annotation_data"][id]["startrow"]
        endrow = pagewise_annot_df[pagewise_annot_df["annotationid"] == annotid]["annotation_data"][id]["endrow"]

    start_end_row_dict = {"startrow": startrow, "endrow": endrow}
    data = eliminate_header_rows_using_startrow(data, start_end_row_dict)

    return data


def freetext_dict(pagewise_annot_df, annotid):
    pagewise_annot_df_free = pagewise_annot_df[pagewise_annot_df["annotationid"] == annotid]["extracted_data_json"]
    text = ""
    for indx in range(len(pagewise_annot_df_free)):
        text = text + " ".join(pagewise_annot_df_free.values[indx])
    return text


def get_extracted_data_json(pagewise_annot_df):
    extracted_data_json = []
    for annotid in pagewise_annot_df["annotationid"].unique():
        output = []
        if len(pagewise_annot_df[pagewise_annot_df["annotationid"] == annotid]) > 0:
            annot_type = pagewise_annot_df[pagewise_annot_df["annotationid"] == annotid].iloc[0]["annotation_type"]
            if annot_type == "table":
                output = table_dict(pagewise_annot_df, annotid)
            elif annot_type == "freetext":
                output = [freetext_dict(pagewise_annot_df, annotid)]
            elif annot_type == "image":
                output = pagewise_annot_df[pagewise_annot_df["annotationid"] == annotid].iloc[0]["extracted_data_json"]

            if output not in [[], None, ""]:
                extracted_data_json.append({"AnnotID": annotid, "class": pagewise_annot_df[pagewise_annot_df["annotationid"] ==
                                                annotid].iloc[0]["annotation_data"]["name"], "value": output})

    return extracted_data_json


def get_pagewise_annot_data(config):
    config = config.to_dict("records")[0]
    words_df = config["words_df"]
    header_footer_dict = config["header_footer_dict"]
    page_config_json = config["page_config_json"]
    REQ_FOLDER = config["REQ_FOLDER"]
    form_config_params = config["form_config_params"]

    if config['datastringtype'] == "freetext":
        # prepare pagewise annotation information
        pagewise_annot_data = get_freetext_data(config, pdf, words_df, header_footer_dict,
                                                       config.get('garbageremovalregex', None),
                                                       REQ_FOLDER, form_config_params,
                                                       config)

    elif config['datastringtype'] == "table":
        pagewise_annot_data = get_tabular_data(config, words_df, pdf,
                                                     page_config_json, REQ_FOLDER,
                                                     header_footer_dict, form_config_params)

    elif config['datastringtype'] == "image":
        pagewise_annot_data = get_checkbox_data(config, words_df, pdf, page_config_json, REQ_FOLDER,
                                                         header_footer_dict,
                                                         form_config_params)
    return pagewise_annot_data


def parallelize_dataframe_page(df, func, n_cores):
    data = []
    df_split = np.array_split(df, len(df))
    pool = Pool(n_cores)
    op = pool.map(func, df_split)
    data.extend(op)
    pool.close()
    pool.join()
    return data


def get_pagewise_annot_df_parallellized(config, words_df, header_footer_dict, page_config_json, REQ_FOLDER, form_config_params, n_cores):
    global pagewise_annot_df
    global pagewise_annot_data_list
    config["words_df"] = [words_df for indx in range(len(config))]
    config["REQ_FOLDER"] = [REQ_FOLDER for indx in range(len(config))]
    config["form_config_params"] = [form_config_params for indx in range(len(config))]
    config["page_config_json"] = [page_config_json.get('garbageremovalregex', None) for indx in range(len(config))]
    config["header_footer_dict"] = [header_footer_dict for indx in range(len(config))]

    pagewise_annot_data_list = parallelize_dataframe_page(config, get_pagewise_annot_data, n_cores)

    # if section is not present in form
    page_annot_info = []
    for indx in range(len(pagewise_annot_data_list)):
        if len(pagewise_annot_data_list[indx]) > 0:
            page_annot_info.extend(pagewise_annot_data_list[indx])

    pagewise_annot_df = pd.DataFrame(page_annot_info, columns=["annotationid", "annotation_type", "annotation_data",
                                                                   "words_df", "confidence", "startstring_pageno",
                  "endstring_pageno", "bbox", "REQ_FOLDER", "garbageremovalregex", "form_config_params",
                  "config", "misc_data", "extracted_data_json"])


def parallelize_dataframe(func, n_cores, pagewise_annot_df):
    # n_cores will be used in future
    output_list = []
    df_split = np.array_split(pagewise_annot_df, len(pagewise_annot_df))
    pool = Pool(1)
    op = pool.map(func, df_split)
    output_list.extend(op)
    pool.close()
    pool.join()
    return output_list


def get_multihread_digitalpdf(pdf_file, config, form_config_params_outer, page_config_json, REQ_FOLDER):
    print("*** multithreaded digitalpdf data extraction ***")    
    global pdf
    global form_config_params
    global pagewise_annot_df
    form_config_params = form_config_params_outer
    pdf = pdfplumber.open(pdf_file)
    words_df, header_footer_dict, header_footer_index_all, garbage_regex = get_words_df(page_config_json, pdf)
    get_pagewise_annot_df_parallellized(config, words_df, header_footer_dict, page_config_json, REQ_FOLDER,
                                        form_config_params, form_config_params["cpu_cores"])

    output_list = []
    output_list.append(parallelize_dataframe(get_all_data, form_config_params["cpu_cores"], pagewise_annot_df))

    data_output = []
    for data in output_list:
        data_output.extend(data)
    pagewise_annot_df["extracted_data_json"] = data_output

    result = get_extracted_data_json(pagewise_annot_df)

    return result
