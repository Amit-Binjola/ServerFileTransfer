#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 31 11:34:20 2019

@author: aditya
"""

import json, copy

table_sample = {'tableid'     : '',
                'tabletype'   : 'fixed',
                'rowalignment': 'regular',
                'rowsize'     : '',
                'rowseperator': '',
                'tablename'   : 'null',
                'optional'    : 'false',
                'repeatable'  : 'false',
                'texttomatch' : {
                    'text'   : '',
                    'rownum' : '1',
                    'cellnum': '1'
                }
                }


def reading_json(config_json_path):
    with open(config_json_path) as json_file:
        config_data = json.load(json_file)
        return config_data


def iter_unique_cells(row):
    global merged_row
    merged_row = 0
    len1 = len(set([cell._tc for cell in row.cells]))
    if len1 == 1:
        merged_row = 1

    else:
        merged_rows = 0
    """Generate cells in row skipping empty grid cells."""
    prior_tc = None
    for cell in row.cells:
        this_tc = cell._tc
        if this_tc is prior_tc:
            continue
        prior_tc = this_tc
        yield cell


def get_table_objects(object1, table_id):
    tbls = []
    local_table_id = table_id
    if len(object1.tables) > 0:
        for table in object1.tables:
            table_object = {}
            local_table_id += 1
            table_object["tableid"] = local_table_id
            table_object["tableobject"] = table
            unique_table = table
            cell_details = []
            for index, row in enumerate(unique_table.rows):
                cell_object = {}
                cell_index = 0
                for cell in iter_unique_cells(row):
                    if len(cell.tables) != 0:
                        nested_tables = []
                        for nested_table in cell.tables:
                            nested_table_object = {}
                            local_table_id += 1
                            nested_table_object["tableid"] = local_table_id
                            nested_table_object["tableobject"] = nested_table
                            nested_tables.append(nested_table_object)
                        if len(nested_tables) > 0:
                            cell_object["cellreference"] = cell_index + 1
                            cell_object["rowreference"] = index + 1
                            cell_object["nestedtables"] = nested_tables
                    cell_index += 1
                if len(cell_object) > 0:
                    cell_details.append(cell_object)
            if len(cell_details) > 0:
                table_object["cell"] = cell_details
            tbls.append(table_object)

    tableidcount = 0
    for table in tbls:
        tableidcount += 1
        table['tableid'] = tableidcount

    return tbls


"""
 ##############################TO FIND HEADERS#############################################################
    header_rows = {}
    # try:
    #     header_rows = get_headers_new(table['tableobject'])
    #     if (len(header_rows) > 0):
    #         table_json['headerrow'] = str(len(header_rows))
    #         headerrowstext = []
    #         for row, header in header_rows.items():
    #             headertext = {}
    #             headertext['headerrowtext'] = header
    #             headerrowstext.append(headertext)
    #         table_json['datastartrow'] = str(len(header_rows) + 1)
    #         table_json['headertext'] = headerrowstext
    #
    # except:
    #     header_rows = {}
############################################################################################################
def get_headers(table_object):
    cell_background_color = re.compile(r'w:fill=\"(\d|[A-Z]){6}\"')
    font_color = re.compile(
        r'w:color\sw:val=\"(\d|[A-Z]){6}\" | w:color=\"(\d|[A-Z]){6}\" | w:val=\"([a-z]|[A-Z]|[0-9])+\"')
    font_color_black = re.compile(r'w:color\sw:val=\"0{6}\"')
    header_rows = {}
    table_data = get_table_data(table_object)[1]
    for row_indx in range(len(table_data) - 1):
        if len(table_data[row_indx + 1]) != len(table_data[row_indx]):
            if (type(table_data[row_indx][0])) == docx.table._Cell:
                # headers_list.append(table_data[row_indx][0].text)
                header_rows[row_indx + 1] = table_data[row_indx][0].text
        else:
            cell_header = []
            for cell_indx in range(len(table_data[row_indx])):
                if (table_data[row_indx][cell_indx].text):
                    if (len(re.findall(cell_background_color, table_data[row_indx][cell_indx]._tc.xml)) > 0 or len(
                            re.findall(font_color, table_data[row_indx][cell_indx]._tc.xml)) > 0):
                        cell_header.append(table_data[row_indx][cell_indx].text)
            #                                headers_list.append(' '.join(cell_header))
            #                for header_list_indx in range(len(headers_list)):
            #                    header_rows[header_list_indx] = headers_list[header_list_indx]
            if (len(cell_header)) == len(table_data[row_indx]):
                if len(cell_header) > 0:
                    header_rows[row_indx + 1] = ' '.join(cell_header)
    header_rows = {k: v for k, v in header_rows.items() if '#' not in v}

    return header_rows


def get_table_data(table):
    unique_table = table
    # rows = unique_table.rows
    all_rows_ls = []
    nested_cells = []
    for index, row in enumerate(unique_table.rows):
        # row_index = unique_table.rows.index(row)
        row_ls = []
        cell_index = 0
        for cell in iter_unique_cells(row):
            if len(cell.tables) != 0:
                nested_cell_object = {"rowreference": index + 1, "cellreference": cell_index + 1}
                for nested_table in cell.tables:
                    nested_table_ls = []
                    for nested_table_row in nested_table.rows:
                        nested_row_ls = []
                        for nested_cell_index, nested_table_cell in iter_unique_cells(nested_table_row):
                            nested_row_ls.append(nested_table_cell)
                        nested_table_ls.append(nested_row_ls)
                    row_ls.append(nested_table_ls)
                if len(nested_cell_object) > 0:
                    nested_cells.append(nested_cell_object)
            else:
                row_ls.append(cell)
            cell_index += 1
        all_rows_ls.append(row_ls)
    return nested_cells, all_rows_ls
"""


def fill_utility_json(tbls):
    json_data = {}
    table_details_all = []
    for table in tbls:
        table_json = copy.deepcopy(table_sample)
        table_json["tableid"] = str(table['tableid'])
        table_json["texttomatch"]["text"] = table["tableobject"].rows[0].cells[0].text

        nestedcells = []
        if 'cell' in table:
            for nested_cell in table['cell']:
                nested_cell_object = {"rowreference" : nested_cell['rowreference'],
                                      "cellreference": nested_cell['cellreference'],
                                      "nestedtables" : nested_cell['nestedtables']}
                nestedcells.append(nested_cell_object)

        row_count = 0
        row_details_all = []
        nested_table_ids = []
        for row in table['tableobject'].rows:
            row_count += 1
            row_json = {'rowid': str(row_count), 'rowoptional': 'false', 'rowheader': 'null'}
            cell_details_all = []
            cell_index = 0
            for cell in iter_unique_cells(row):
                cell_json = {'cellid'    : str(cell_index + 1), 'celltype': 'standard',
                             'cellheader': 'null', 'celldata': {"value": cell.text}}
                if len(nestedcells) > 0:
                    for nested_cell in nestedcells:
                        if (cell_index + 1) == nested_cell['cellreference'] and row_count == nested_cell['rowreference']:
                            nested_tables = []
                            for table_id, nested_table in enumerate(nested_cell['nestedtables'], 1):
                                nested_table_id = {'value': "{}.{}.{}.{}".format(table['tableid'], nested_cell["rowreference"],
                                                                                 nested_cell["cellreference"], table_id)}
                                nested_table_ids.append(nested_table_id)
                                nested_table["tableid"] = nested_table_id["value"]
                                nested_tables.append(nested_table)
                            cell_json['celldata'] = {"value": json.dumps(fill_utility_json(nested_tables))}
                cell_index += 1
                cell_details_all.append(cell_json)
            row_json['cells'] = cell_details_all
            row_details_all.append(row_json)

        table_json['rows'] = row_details_all
        table_json['nestedtableids'] = nested_table_ids
        table_details_all.append(table_json)

    json_data['tables'] = table_details_all
    json_data['numberoftables'] = str(len(table_details_all))
    json_data['paragraphs'] = [{'paragraphid': '', 'paragraphtext': ''}]
    json_data['numberofparagraphs'] = ""
    return json_data


def fill_json(input_doc):
    tbls = get_table_objects(input_doc, 0)
    metadata_json = fill_utility_json(tbls)
    return metadata_json

# filepath = "/home/aditya/generic_poc/inputs/pdf/NNI-release2/AE_form.docx"
# metadata_json = fill_json("/home/aditya/generic_poc/inputs/pdf/NNI-release2/AE_form.docx")
#
# with open("/home/aditya/generic_poc/inputs/pdf/NNI-release2/metadata.json", 'w') as outfile:
#     outfile.write(metadata_json)

#    with open(structural_json_path, 'w') as outfile:
#        json.dump(structure_json, outfile)

# with open("/home/aditya/genericFormParser_new/generic-form-parser/src/config/output.json",'w') as outfile:
#         json.dump(metadata_json, outfile)
# datastring = tesserOcr2(image_file,3518, 945, 1019, 132)
# getid(structural_json_path,json_path,datastring)

# UPLOAD_FOLDER = '/home/aditya/generic_poc/docx/uploads'
# outputfile = '/home/aditya/generic_poc/docx/json/output/output.json'
# json_path = '/home/aditya/generic_poc/docx/json/output/output.json'
# outputfile2 = '/home/aditya/generic_poc/docx/json/output/output_structure.json'
# structural_json_path = '/home/aditya/generic_poc/docx/json/output/output_structure.json'

# filepath = "/home/aditya/inputs/merckAries/MR9.docx"
# filepath = "/home/aditya/generic_poc/docx/uploads/AE3.docx"
# structural_json_path = "/home/aditya/inputs/structuraljson.json"
# metadatajsonpath = "/home/aditya/inputs/metadatajson.json"
# config_json_path = "/home/aditya/generic_poc/docx/json/table_config_new.json"
# config_structure_json_path = "/home/aditya/generic_poc/docx/json/table_structure_config.json"

# fill_json(config_json_path,config_structure_json_path,filepath)
# fill_structural_json(config_structure_json_path,filepath)
