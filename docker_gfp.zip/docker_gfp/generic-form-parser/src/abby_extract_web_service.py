from flask import request, Flask, jsonify
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import time
import pandas as pd
import os
from config import CONFIG_JSON, UPLOAD_FOLDER, TEMPLATE_FOLDER, logger
import numpy as np
import glob
from PIL import Image
import json

URL = CONFIG_JSON['base-url-internal']
PORT = CONFIG_JSON['abbyy_port']

AbbyyInstallPath_fullpage = '/opt/ABBYY/FREngine12/Samples/Outproc/Multithreading1/multithreading'  # /SampleImages/saved_image.png  /SampleImages/Demo.txt'
AbbyyInstallPath_zonal = '/opt/ABBYY/FREngine12/Samples/Zomal_ICR/Icr'
AbbyyInstallPath_zonal_multi = '/opt/ABBYY/FREngine12/Samples/Zonal_ICR/Icr'
target_file = "/opt/ABBYY/FREngine12/Samples/tempdata/temp_out.txt"
desti = "/opt/ABBYY/FREngine12/Samples/tempdata/form.png"

app = Flask(__name__)


def remove_targetfile():
    if os.path.exists(target_file):
        os.remove(target_file)
        print('File Deleted: ', target_file)
    else:
        print("Can not delete the file as it doesn't exists")


def read_file(filename):
    # filename = "/opt/ABBYY/FREngine12/Samples/tempdata/"+filename
    try:
        with open(filename, 'r', encoding='utf-8-sig') as file:
            data = file.read()
            data = data.replace('\n', ' ')
            data = data.replace('\r', '')
            data = data.replace('\t', '')
            data = data.replace('^', '')
            data = data.replace('\xef', '')
            data = data.replace('\xbb', '')
            data = data.replace('\xbf', '')
            data = data.replace('\ufeff', '')
            data = data.strip('.?! ')
            return data
    except:
        return "OCR Error"


def call_command(filename, x1, y1, x2, y2, textType, language, pageno):
    filename = "/opt/ABBYY/FREngine12/Samples/tempdata/" + filename + ".txt"
    # filename = inputdir[pageno]
    args = " ".join(list(map(str, [x1, y1, x2, y2, textType, language])))
    # args = " ".join(list(map(str,[x1,y1,x2,y2,textType])))
    cmd = "export LD_LIBRARY_PATH=/opt/ABBYY/FREngine12/Bin;" + AbbyyInstallPath_zonal_multi + " " + inputdir[
        pageno] + " " + filename + " " + args
    # print(cmd)
    os.system(cmd)


def extractAllZones(ix):
    try:
        # print(df)
        filename = df.iloc[ix]['filename']
        # print(filename)
        x1 = df.iloc[ix]['x1']
        y1 = df.iloc[ix]['y1']
        x2 = df.iloc[ix]['x2'] + x1
        y2 = df.iloc[ix]['y2'] + y1
        textType = df.iloc[ix]['textType'].lower() + "-zonal"
        textType = textType.split("-")
        pageno = df.iloc[ix]['pageNo']
        language = "English"  # df.iloc[ix]['language'].capitalize()
        if "full" in textType[1]:
            im = Image.open(inputdir[pageno])
            im1 = im.crop((x1, y1, x2, y2))
            fullzone = "/".join(inputdir[pageno].split("/")[:-1] + ["fullzone.tiff"])
            inputdir.append(fullzone)
            im1.save()
            call_command(str(ix), 0, 0, 0, 0, textType[0], language, -1)
        elif "zonal" in textType[1]:
            call_command(str(ix), x1, y1, x2, y2, textType[0], language, pageno)
        # val = getZonalOCR(source_file, x1, y1, x2, y2, textType)
        # call_command(filename, x1, y1, x2, y2, textType, language, pageno)
        # call_command(str(ix), x1, y1, x2, y2, textType, pageno)
        val = read_file(str(ix) + ".txt")

        # everything done except storing value in dataframe [text] could not figrure it

        # df.loc[int(str(ix)),'text'] = val
        # df.iloc[ix]['text'] = val
        # os.system("rm /opt/ABBYY/FREngine12/Samples/tempdata/"+str(ix)+".txt")
        return {filename: val}
    except:
        return {df.iloc[ix]['filename']: "error in input"}


def multiprocessing(func, args, workers):
    with ProcessPoolExecutor(max_workers=workers) as executor:
        res = executor.map(func, args)
    return list(res)


def getFullData(csv_file_path, inputdirpath):
    global df
    df = pd.read_csv(csv_file_path, "|")
    df.columns = ['filename', 'x1', 'y1', 'x2', 'y2', 'textType', 'pageNo']
    # df["text"]=np.nan
    # print(df)
    global inputdir
    inputdir = inputdirpath
    begin_time = time.time()
    ner_data_combined = multiprocessing(extractAllZones, [ix for ix in range(df.shape[0])], 5)
    # print(df)
    # print(ner_data_combined)
    end_time = time.time()
    print("Time Taken in seconds:", (end_time - begin_time))
    return {"data": ner_data_combined}


# def getOCR(source_file, x1, y1, x2, y2, textType):

@app.route('/api/zonal', methods=['POST'])
def getZonalOCR():
    data = request.headers
    print(data)
    file = request.files[(list(request.files))[0]]
    file.save(desti)
    # val = getOCR(source_file, x1, y1, x2, y2, textType)
    remove_targetfile()
    lis = " ".join(list(map(str, [data["x1"], data["y1"], data["x2"], data["y2"], data["textType"]])))

    os.system("export LD_LIBRARY_PATH=/opt/ABBYY/FREngine12/Bin;" +
              AbbyyInstallPath_zonal + " /tempdata/form.png /tempdata/temp_out.txt " + lis + ";rm -f " + desti)
    val = read_file(target_file)
    return jsonify({"data": val})


# def getCheckMark(source_file, x1, y1, x2, y2):
#    val = getOCR(source_file, x1, y1, x2, y2, "", "checkmark")
#    return val

@app.route('/api/fullpage', methods=['POST'])
def getFullPageOCR():
    print("kjfdsksj")
    remove_targetfile()
    # file = request.files[(list(request.files))[0]]
    # file.save(desti)
    data = request.form
    print(data)
    os.system("rm -fr " + data["output path"] + ";")
    cmd = "export LD_LIBRARY_PATH=/opt/ABBYY/FREngine12/Bin;mkdir " + data[
        "output path"] + ";" + AbbyyInstallPath_fullpage + " " + data["input path"] + " " + data["output path"]
    print(cmd)
    os.system(cmd)
    out_folder = data["output path"]
    all_files = glob.glob(out_folder + "/*.txt")
    out_dict = {}
    for index in range(len(all_files)):
        with open(all_files[index], 'r') as f:
            out_dict["page " + str(index)] = f.read()
    all_data = json.dumps({"data": out_dict})
    return all_data

@app.route('/api/multizonal', methods=['POST'])
def multizonal():
    print("kjfdsksj")
    multiZoneStorage = "/opt/ABBYY/FREngine12/Samples/tempdata/"
    fileNo = len(list(request.files))
    inputdir = []
    if fileNo > 1:
        csv_file = request.files[(list(request.files))[0]]
        csv_file.save(multiZoneStorage + "coord.csv")
        for i in range(1, fileNo):
            data = request.files[(list(request.files))[i]]
            data.save(multiZoneStorage + str(i) + ".png")
            inputdir.append(multiZoneStorage + str(i) + ".png")
    else:
        return jsonify({"val": "less than 2 files"})
    # getFullData(multiZoneStorage+"coord.csv" , inputdir)
    return jsonify(getFullData(multiZoneStorage + "coord.csv", inputdir))


def read_env_var(config_file_path):
    env_var_list = []
    lines = open(config_file_path, "r")
    for line in lines:
        line.strip()
        if line[0] == "#":
            continue
        line.strip().upper()
        temp_line = line.split()
        env_var_list = env_var_list + temp_line
    env_var = {env_var_list[i]: env_var_list[i + 1] for i in range(0, len(env_var_list), 2)}
    return env_var


if __name__ == "__main__":
    app.run(URL, port=PORT, debug=False)
