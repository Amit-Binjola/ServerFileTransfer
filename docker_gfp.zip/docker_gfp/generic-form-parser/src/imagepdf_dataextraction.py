# !/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 19 16:26:30 2020

@author: suresh
"""
from tesserocr import PyTessBaseAPI, PSM, OEM
import multiprocessing as mp
from fuzzywuzzy import fuzz
from PIL import Image
from glob import glob
import pandas as pd
import numpy as np
import copy, cv2, re, os, json
from py_tableparser.regex_table_extraction import RegexBasedTableParser
from os import path, remove, getenv
from surf_aligning import align_images
from checkbox_classifier import checkbox_classifier, multiple_rectangular_checkbox
from config import CONFIG_JSON, logger, TEMPLATE_FOLDER, TRUE_CHECK, FALSE_CHECK, BACKEND_FOLDER
from py_tableparser.table_type_detection import find_table_type as table_type_detector
from py_tableparser.table_without_lines import table_without_lines
from py_tableparser.table_with_hlines import table_with_hlines
from py_tableparser.table_with_vlines import table_with_column_lines
from py_tableparser.table_parser import Table_Data_Extraction
from utility_get_keyval import get_dict_from_list
from utility_convert_coord import get_calc_coord_imagepdf
from common_utils import get_key_row_position, get_all_occurences_data, get_header_footer_position, \
    download_from_aws_s3, file_exists_in_s3_bucket, get_afterref_pos, get_table_refstr_pos, get_ref_string_pos
from py_tableparser.table_parser import morphing_image
from py_tableparser.table_parser import draw_row_column_lines
from random import random
import pickle
#Image.MAX_IMAGE_PIXELS = None
# loading ocr module based on configuration set in the config file
########################################################################################################################
if CONFIG_JSON["ocr"]["required"]:
    OCR_tool = CONFIG_JSON["ocr"]["tools"][0].lower()
    if OCR_tool == "tesserocr":
        from tesserocr_utilities import extract_text_tesserOCR, generate_hocr
    elif OCR_tool == "abbyy":
        from AbbyyExtract import getmultizonal, getZonalOCR, generate_abbyy_hocr

handwritten_sections = []
handwritten = CONFIG_JSON["handwritten_text"]["handle_handwritten"]
if handwritten.lower() == "yes":
    handwritten_sections = CONFIG_JSON["handwritten_text"]["handwritten_sections"]


########################################################################################################################

def get_string_pos(words_df, word_string):
    words_df.sort_values(by='top', inplace=False, ascending=True)
    word_index = None
    list_words = word_string.strip("\n").split(" ")
    list_words.append(word_string)
    words_df_filtered = words_df
    words_df_filtered_final = []
    for indx in range(0, len(words_df_filtered)):
        concate_words = ""
        for no_indx in range(0, len(list_words)):
            if no_indx + indx < len(words_df_filtered):
                concate_words = concate_words + " " + words_df_filtered.iloc[no_indx + indx]['word']
                if len(concate_words.split(" ")) >= len(list_words):
                    break
        if fuzz.ratio(word_string.lower().strip(), concate_words.lower().strip()) >= 95:
            if concate_words.strip().lower().startswith(list_words[0].lower().strip()):
                words_df_filtered_final = words_df_filtered[indx:indx + len(list_words)]
                break
            elif len(concate_words.strip().split(" ")) >= 2:
                if concate_words.strip().split(" ")[1].lower().startswith(list_words[0].lower().strip()):
                    words_df_filtered_final = words_df_filtered[indx + 1:indx + 1 + len(list_words)]
                    break

    if len(words_df_filtered_final) > 0:
        word = words_df_filtered_final.iloc[0:1]
        word_index = list(word.index.values)[0]

    return word_index


def remove_unwanted_pages(page_config_json, png_filepaths, word_cords_all):
    pagewise_keywords = {}
    for page_data in page_config_json["pages"]:
        pagewise_keywords[page_data["pageno"]] = page_data["sectionheaders"]

    page_match = {}
    pages = word_cords_all["pageno"].unique()
    for page in pages:
        for key in pagewise_keywords.keys():
            for search_word in pagewise_keywords[key]:
                df = word_cords_all[word_cords_all["pageno"] == page]
                key_indx = get_string_pos(df, search_word.strip())

                if key_indx is not None:
                    page_match[key] = page  # {"page of test form" : "page of template form"}
                    break

    word_df = pd.DataFrame()
    pageno = 0
    for page in page_match.values():
        temp_df = word_cords_all[word_cords_all["pageno"] == page]
        temp_df["pageno"] = pageno
        word_df = word_df.append(temp_df)
        pageno += 1

    return word_cords_all


def get_text_based_on_ocrtool(png_filepath, bbox_dict, textType):
    if OCR_tool == "tesserocr":
        extracted_data = extract_text_tesserOCR(png_filepath, bbox_dict)
    elif OCR_tool == "abbyy":
        # textType - handwritten, normal
        extracted_data = getZonalOCR(png_filepath, bbox_dict, textType, "zonal", language="English")
    return extracted_data


def remove_empty_str_in_list(given_list):
    output_list = [words for words in given_list if words]
    return output_list


# this method is to identify page number based on header/footers
def identify_page_number(df, header_list, footer_list, page_no):
    header_list.extend(footer_list)
    header_list = remove_empty_str_in_list(header_list)
    SIMILARITY_THRESH = 80
    pagenum = -1
    count = 0
    for identifiers in header_list:
        size = len(identifiers.split(" "))
        for index, row in df.iterrows():
            word = " ".join([df.word[x] for x in range(index, index + size) if index < len(df) - size])
            sim_score = fuzz.partial_ratio(word.lower(), identifiers.lower())
            if sim_score > SIMILARITY_THRESH:
                count += 1
                pagenum = row["pageno"]
                break
        if count == len(header_list):
            break
    return pagenum


def get_images_to_realign(png_filepaths, word_cords, pages_config, form_id):
    page_mapping = {}

    for png_indx in range(len(png_filepaths)):
        test_img_path = png_filepaths[png_indx]
        template_img_path = path.join(TEMPLATE_FOLDER, form_id + "_" + str(png_indx) + ".png")
        s3_file_path = "/".join(template_img_path.split("/")[3:])
        template_image_found = True
        if not template_img_path:
            if file_exists_in_s3_bucket(s3_file_path):
                download_from_aws_s3(template_img_path, s3_file_path)
            else:
                template_image_found = False
        page_config = pages_config[png_indx]

        if template_image_found and page_config["pagetype"].lower() == "fixed form":
            header_list = page_config["pageheaderidentifier"]
            footer_list = page_config["pagefooteridentifier"]
            if page_config['repeatablepage'] in ("true", "True", True):
                pagelist = []
                word_cords_cpy = word_cords.copy()
                pagenum = identify_page_number(word_cords_cpy, header_list, footer_list, page_config["pageno"])
                pagelist.append(test_img_path)
                while (pagenum != -1):
                    word_cords_cpy = word_cords_cpy[word_cords_cpy.pageno != pagenum]
                    pagenum = identify_page_number(word_cords_cpy, header_list, footer_list, page_config["pageno"])
                    pagelist.append(test_img_path)
                page_mapping[template_img_path] = pagelist
            else:
                pagenum = identify_page_number(word_cords, header_list, footer_list, page_config["pageno"])
                word_cords = word_cords[word_cords.pageno != pagenum]
                page_mapping[template_img_path] = [test_img_path]

    return page_mapping


def cleaned_image(cropped_cb_img):
    cropped_cb_img = cv2.multiply(cropped_cb_img, 1.2)
    kernel = np.ones((1,1),np.uint8)
    cropped_cb_img = cv2.erode(cropped_cb_img, kernel, iterations=1)
    return cropped_cb_img

def get_checkbox_values(req_folder, word_cords, config_data, png_filepaths, form_config_params):
    extracted_cb_data = []
    annot_coords = config_data['annotcoords'].split(",")

    if config_data['annotcoords'] in [None, " ", ""]:
        data = ""  # TBD
    else:
        bbox_dict = {'left': int(float(annot_coords[0])), 'top': int(float(annot_coords[1])),
                     'width': int(float(annot_coords[2])),
                     'height': int(float(annot_coords[3]))}
        page_num = int(config_data['pageno'])
        img = cv2.imread(png_filepaths[page_num], 0)
        if config_data['annotationtype'] != "virtual":
            if config_data['afterrefstr'] and config_data['beforerefstr']:
                afterstr_indx = get_afterref_pos(word_cords, config_data, 0)
                if afterstr_indx:
                    calc_afterref_dict = word_cords.iloc[afterstr_indx].to_dict()
                    beforestr_indx = get_key_row_position(word_cords, config_data['beforerefstr'],
                                                          config_data['beforerefcoords'], afterstr_indx)
                    if beforestr_indx:
                        calc_beforeref_dict = word_cords.iloc[beforestr_indx].to_dict()
                        calc_annot_coord = get_calc_coord_imagepdf(config_data, calc_afterref_dict, calc_beforeref_dict,
                                                                   afterstr_indx, beforestr_indx, word_cords)
                        bbox_dict = {position: int(coord_value) for position, coord_value in calc_annot_coord.items()}

        crop_img_path = path.join(req_folder, config_data['name'] + ".png")
        cropped_cb_img = img[bbox_dict['top']:bbox_dict['top'] + bbox_dict['height'],
                         bbox_dict['left']:bbox_dict['left'] + bbox_dict['width']]
        cropped_cb_img = cleaned_image(cropped_cb_img)
        # --- To be used
        #        if OCR_tool.lower() == "abbyy":
        #            extracted_cb_data = getZonalOCR(crop_img_path, bbox_dict, "", "zonal", "checkmark")
        #            if extracted_cb_data.lower() in ["ocrerror","ocr error"]:
        #                extracted_cb_data = 0
        #        else:
        # -----
        if type(cropped_cb_img) != np.array:
            cv2.imwrite(crop_img_path, cropped_cb_img)
        extracted_cb_data = checkbox_classifier(cropped_cb_img, config_data['imagetype'], form_config_params)

        if len(extracted_cb_data) == 1:
            extracted_cb_data = extracted_cb_data[0]
        elif extracted_cb_data == []:  # checkbox not found
            extracted_cb_data = "0"

    return extracted_cb_data


def get_config_matrixdata_df(config, config_matrixdata, req_folder, png_filepaths):
    config_matrixdata_df = pd.DataFrame([], columns=["label", "left", "top", "right", "bottom", "textType", "pageNo",
                                                     "text"])
    if len(config_matrixdata):
        config_matrix_coord = config[config['label'].str.lower().isin(config_matrixdata['label'])]
        config_matrix_coord.to_csv(path.join(req_folder, "config_matrix_data.csv"), sep="|", index=False)
        matrix_coordinates_config_path = path.join(req_folder, "config_matrix_data.csv")
        if OCR_tool == "abbyy":
            abby_data_csv = getmultizonal(matrix_coordinates_config_path, png_filepaths)
            df_list_of_data = pd.read_csv(abby_data_csv, sep="|")
            list_matrix_data = np.array(df_list_of_data['text'].astype(str))
            config_matrixdata['text'] = list_matrix_data
            config_matrixdata['text'] = config_matrixdata['text'].replace("nan", "")
            config_matrixdata = config_matrixdata.fillna("")
            config_matrixdata_temp_dict = {}
            for items in config_matrixdata['label'].unique():
                grouped_item = config_matrixdata.loc[config_matrixdata["label"] == items]['text']
                data = []
                for gp_item in grouped_item:
                    data.append(gp_item)
                config_matrixdata_temp_dict[items] = data
            config_matrixdata_df['label'] = list(config_matrixdata_temp_dict.keys())
            config_matrixdata_df['text'] = list(config_matrixdata_temp_dict.values())

    return config_matrixdata_df


def get_config_checkbox_in_matrixdata(config_checkbox_in_matrixdata, png_filepaths, form_config_params):
    list_cb_matrix_data = []
    config_checkbox_matrix_data_df = pd.DataFrame([], columns=["label", "left", "top", "right", "bottom", "textType",
                                                               "pageNo", "text"])
    if len(config_checkbox_in_matrixdata) > 0:
        for row_num in range(0, len(config_checkbox_in_matrixdata)):
            cbdata = config_checkbox_in_matrixdata.iloc[row_num]
            left = int(cbdata['left'])
            top = int(cbdata['top'])
            right = int(cbdata['right'])
            bottom = int(cbdata['bottom'])
            pageno = int(cbdata['pageNo'])
            classifier_type = cbdata['textType']
            test_image = cv2.imread(png_filepaths[pageno], 0)
            test_image = test_image[top:top + bottom, left:left + right]
            list_cb_matrix_data.append(int(float(checkbox_classifier(test_image, classifier_type, form_config_params))))

        config_checkbox_in_matrixdata['text'] = list_cb_matrix_data
        grouped_item_df = {}
        for items in config_checkbox_in_matrixdata['label'].unique():
            grouped_item = config_checkbox_in_matrixdata.loc[config_checkbox_in_matrixdata["label"] == items]["text"]
            data = []
            for gp_item in grouped_item:
                data.append(gp_item)
            grouped_item_df[items] = data
        config_checkbox_matrix_data_df['label'] = list(grouped_item_df.keys())
        config_checkbox_matrix_data_df['text'] = list(grouped_item_df.values())
    return config_checkbox_matrix_data_df


def rgb2gray_conversion(png_files):
    for img in png_files:
        imfile = cv2.imread(img, 0)
        cv2.imwrite(img, imfile)


def get_extracted_data_json(config_data_df, extracted_data_df, extracted_data_json):
    for index, row in extracted_data_df.iterrows():
        json_data = {}
        json_data["AnnotID"] = row['label']
        json_data["class"] = config_data_df[config_data_df["annotid"] == row["label"]]['name']
        json_data["value"] = row['text']
        extracted_data_json.append(json_data)
    return extracted_data_json


def get_fixed_pages(page_config_json):
    fixed_pages = []
    for page in page_config_json["pages"]:
        if page["pagetype"].lower() == "fixed form":
            fixed_pages.append(int(page["pageno"]))

    return fixed_pages


def align_images_basedon_template(req_folder, fixed_pages, form_id):
    for pageno in fixed_pages:
        test_img_path = path.join(req_folder, "png/form_png-" + str(pageno) + ".png")
        test_img = cv2.imread(test_img_path, 0)
        template_img = cv2.imread(path.join(TEMPLATE_FOLDER, "png/" + form_id + "_" + str(pageno) + ".png"), 0)
        rot_img = align_images(test_img, form_id, pageno, template_img)
        cv2.imwrite(test_img_path, rot_img)


def get_word_cords(req_folder, png_filepaths, page_config_json, form_id):
    fixed_pages = get_fixed_pages(page_config_json)
    align_images_basedon_template(req_folder, fixed_pages, form_id)
    rgb2gray_conversion(png_filepaths)

    if OCR_tool == "tesserocr":
        word_cords = generate_hocr(req_folder, png_filepaths)
    elif OCR_tool == "abbyy":
        word_cords = generate_abbyy_hocr(req_folder, png_filepaths)

    word_cords["word"] = word_cords.word.str.strip()
    word_cords["pageno"] = word_cords["pageno"].apply(pd.to_numeric)
    word_cords["left"] = word_cords["left"].apply(pd.to_numeric)
    word_cords["top"] = word_cords["top"].apply(pd.to_numeric)
    word_cords["width"] = word_cords["width"].apply(pd.to_numeric)
    word_cords["height"] = word_cords["height"].apply(pd.to_numeric)

    # to be used in future
    # page_mapping = get_images_to_realign(png_filepaths, word_cords, page_config_json, form_id)

    return word_cords


# utility method to extract freetext data (if spanning across multiples pages also)
def extract_freetext_data(req_folder, png_filepaths, words_df, config_data, afterstr_indx, beforestr_indx, textType):
    annot_start_page = int(config_data["pageno"])
    annot_coords = config_data['annotcoords'].split(",")
    bbox_dict = {'left': int(annot_coords[0]), 'top': int(annot_coords[1]),
                 'width': int(annot_coords[2]), 'height': int(annot_coords[3])}

    data = []
    extracted_data = ""
    if afterstr_indx:
        calc_afterref_dict = words_df.iloc[afterstr_indx].to_dict()
        start_page = calc_afterref_dict['pageno']
        bbox_dict['left'] = calc_afterref_dict['left']
        if beforestr_indx:
            calc_beforeref_dict = words_df.iloc[beforestr_indx].to_dict()
            end_page = calc_beforeref_dict['pageno']

            for page_no in range(start_page, end_page + 1):
                if start_page == end_page:
                    calc_annot_coord = get_calc_coord_imagepdf(config_data, calc_afterref_dict, calc_beforeref_dict,
                                                               afterstr_indx, beforestr_indx, words_df)
                    bbox_dict = {position: int(coord_value) for position, coord_value in calc_annot_coord.items()}

                elif page_no == start_page and start_page != end_page:
                    bbox_dict['top'] = calc_afterref_dict['top']
                    bbox_bottom = float(words_df[words_df['pageno'] == page_no].iloc[-1]['bottom']) + 0.5
                    bbox_dict['height'] = int(abs(bbox_bottom - bbox_dict['top']))

                elif page_no > start_page and page_no < end_page:
                    bbox_dict['top'] = int(float(
                        words_df[words_df['pageno'] == page_no].iloc[0]['top']))  # top : first row of a page
                    bbox_bottom = int(float(
                        words_df[words_df['pageno'] == page_no].iloc[-1]['bottom']))  # bottom : last row of a page
                    bbox_dict['height'] = int(abs(bbox_bottom - bbox_dict['top']))

                elif page_no > start_page and page_no == end_page:
                    bbox_dict['top'] = int(float(words_df[words_df['pageno'] == page_no].iloc[0]['top']))
                    bbox_bottom = calc_beforeref_dict['top']
                    bbox_dict['height'] = int(abs(bbox_bottom - bbox_dict['top']))

                img = cv2.imread(png_filepaths[page_no], 0)
                img_path = path.join(req_folder, config_data['name'] + "_" + str(bbox_dict["top"]) + ".png")
                cv2.imwrite(img_path, img[bbox_dict['top']:bbox_dict['top'] + bbox_dict['height'],
                                      bbox_dict['left']:bbox_dict['left'] + bbox_dict['width']])
                extracted_data = get_text_based_on_ocrtool(png_filepaths[page_no], bbox_dict, textType)
                data.append(extracted_data)
        else:
            bbox_dict['top'] = int(calc_afterref_dict['top'])
            last_word_bottom = float(words_df[words_df['pageno'] == start_page].iloc[-1]['bottom']) + 0.5
            bbox_dict['height'] = round(abs(bbox_dict['top'] - last_word_bottom))
            extracted_data = get_text_based_on_ocrtool(png_filepaths[start_page], bbox_dict, textType)
            data.append(extracted_data)
    else:
        extracted_data = get_text_based_on_ocrtool(png_filepaths[annot_start_page], bbox_dict, textType)
        data.append(extracted_data)

    return data


# extraction of freetext annotation data
def get_freetext_data(req_folder, png_filepaths, config_data, word_cords, page_config_json, textType):
    section_raw_text = []
    afterstr_indx = beforestr_indx = None
    if config_data['annotationtype'] != "virtual":
        if config_data['afterrefstr'] and config_data['beforerefstr']:
            afterstr_indx = get_ref_string_pos(word_cords, config_data['pageno'], 0,
                                               config_data['afterrefstr'].split("||")[0], config_data["annotcoords"])
            if afterstr_indx is None and len(config_data['afterrefstr'].split("||")) > 1:
                afterstr_indx = get_ref_string_pos(word_cords, config_data['pageno'], 0,
                                                   config_data['afterrefstr'].split("||")[1],
                                                   config_data["annotcoords"])

            if afterstr_indx:
                beforestr_indx = None
                for before_ref_string in config_data['beforerefstr'].split("||"):
                    beforestr_indx = get_ref_string_pos(word_cords, config_data['pageno'], afterstr_indx + 1,
                                                        before_ref_string, config_data["annotcoords"])
                    if beforestr_indx:
                        break

        section_raw_text = extract_freetext_data(req_folder, png_filepaths, word_cords, config_data, afterstr_indx,
                                                 beforestr_indx, textType)
    if section_raw_text:
        " ".join(section_raw_text)
    return section_raw_text


def get_section_position(word_cords, section_headers):
    all_section_data = []
    section_pos = {}
    coords = None
    all_pages = word_cords.pageno.unique()
    all_pages = np.sort(all_pages, axis=None)
    for page in all_pages:
        for header in section_headers:
            word_cords_filtered_by_page = word_cords[word_cords['pageno'] == page]
            header_pos_in_page = get_key_row_position(word_cords_filtered_by_page, header.split(" "), coords, 0)
            if header_pos_in_page:
                section_pos[header] = header_pos_in_page
                all_section_data.append(section_pos)
    return all_section_data


def extract_data_between_given_keys(start_position, end_position, word_cords_df):
    word_cords_df = word_cords_df.iloc[start_position:end_position]
    word_cords_df = word_cords_df.append(word_cords_df.iloc[-1])
    final_data = []
    partial_data = ""
    total_rows = len(word_cords_df) - 1
    for row_num in range(0, total_rows):
        bottom_diff = word_cords_df.iloc[row_num + 1]['bottom'] - word_cords_df.iloc[row_num]['bottom']
        if bottom_diff >= 0 and bottom_diff < 5:
            try:
                partial_data = partial_data + " " + word_cords_df.iloc[row_num]["text"]
            except:
                partial_data = partial_data + " " + word_cords_df.iloc[row_num]["word"]
        else:
            try:
                partial_data = partial_data + " " + word_cords_df.iloc[row_num]["text"]
            except:
                partial_data = partial_data + " " + word_cords_df.iloc[row_num]["word"]

            final_data.append(partial_data.strip())
            partial_data = ""
        if row_num == total_rows - 1:
            final_data.append(partial_data)
    return final_data


def get_keyvalue_data(config_data, word_cords_df):
    # we are not using after/beforerefstring for keyvalue pairs
    end_position = None
    start_position = get_key_row_position(word_cords_df, config_data['extstartstr'], "", 0)

    if start_position:
        # keeping start_key_page and end_key_page variables for now and have to test it
        start_key_page = word_cords_df.iloc[start_position]['pageno']
        if config_data['extendstr']:
            end_position = get_key_row_position(word_cords_df, config_data['extendstr'], "", start_position)
        if end_position is None and not config_data['extendstr']:
            end_key_page = max(word_cords_df['pageno'])
            end_position = len(word_cords_df) - 1
        elif end_position:
            end_key_page = word_cords_df.iloc[end_position]['pageno']

        lists_of_text = extract_data_between_given_keys(start_position, end_position, word_cords_df)
        lists_of_text = remove_parent_keys(lists_of_text, config_data['extstartstr'], config_data['extendstr'])

        if config_data['formkeylist']:
            if config_data["repeatableannot"] and config_data['recordseperator']:
                key_val_op = []
                section_data = get_all_occurences_data(lists_of_text, config_data['recordseperator'])
                for list_of_text in section_data:
                    key_val_dict = get_dict_from_list(config_data['formkeylist'], list_of_text)
                    key_val_op.append(key_val_dict)
            else:
                key_val_op = get_dict_from_list(config_data['formkeylist'], lists_of_text)

    return key_val_op


# to remove unnecessary keys present as part of required value
def remove_parent_keys(lists_of_text, start_key, end_key):
    start_key = " ".join(start_key)
    end_key = " ".join(end_key)
    text_filtered = []
    for text in lists_of_text:
        if text.startswith(start_key):
            filtered = text[len(start_key):]
            text_filtered.append(filtered.strip())
        elif text.startswith(end_key):
            filtered = text[len(end_key):]
            text_filtered.append(filtered.strip())
        else:
            text_filtered.append(text.strip())
    return text_filtered


def get_checkbox_status(req_folder, cell_img, word_cords, search_word):
    cbox_index = get_key_row_position(word_cords, search_word, "", 0)
    checkbox_status = 0
    if cbox_index:
        cbox_pos = word_cords.iloc[cbox_index]
        cbox_img = cell_img[cbox_pos['top'] - 10:cbox_pos['bottom'] + 20, 0:cbox_pos['left']]
        cv2.imwrite(req_folder + "/checkboxes/" + search_word + ".png", cbox_img)
        checkbox_status = multiple_rectangular_checkbox(cbox_img)
        if len(checkbox_status) == 1:
            checkbox_status = checkbox_status[0]
        if checkbox_status == []:
            checkbox_status = 0

    return str(checkbox_status)


def cell_wise_data(req_folder, table_img_path, table_img, boundingbox_pos_filtered, textType):
    data = []
    for bbox_index in range(len(boundingbox_pos_filtered)):
        cell_bbox = {'left': int(boundingbox_pos_filtered[bbox_index][0]),
                     'top': int(boundingbox_pos_filtered[bbox_index][1]),
                     'width': int(boundingbox_pos_filtered[bbox_index][2]),
                     'height': int(boundingbox_pos_filtered[bbox_index][3])}

        cell_text = get_text_based_on_ocrtool(table_img_path, cell_bbox, textType)
        cell_path = path.join(req_folder, str(boundingbox_pos_filtered[bbox_index][1]) + ".png")
        cell_img = table_img[cell_bbox['top']:cell_bbox['top'] + cell_bbox['height'],
                   cell_bbox['left']:cell_bbox['left'] + cell_bbox["width"]]
        cv2.imwrite(cell_path, cell_img)
        png_filepaths = [cell_path]
        word_cords = generate_hocr(req_folder, png_filepaths)
        word_cords.to_csv(cell_path + "\cell_data.csv", sep=",")
        checkbox_status = ""
        if len(word_cords) > 1:
            word_cords["pageno"] = word_cords["pageno"].apply(pd.to_numeric)
            word_cords["left"] = word_cords["left"].apply(pd.to_numeric)
            word_cords["top"] = word_cords["top"].apply(pd.to_numeric)
            word_cords["width"] = word_cords["width"].apply(pd.to_numeric)
            word_cords["height"] = word_cords["height"].apply(pd.to_numeric)

            search_words_all = ["Revised on", "Clarification as"]
            for search_word in search_words_all:
                checkbox_status = checkbox_status + "||" + search_word + ": " + get_checkbox_status(req_folder,
                                                                                                    cell_img,
                                                                                                    word_cords,
                                                                                                    search_word)

        data.append(cell_text.replace("\n", "") + checkbox_status)
    return data


def get_bundingbox_position(img_final_bin):
    try:
        image_filtered, contours, hierarchy = cv2.findContours(img_final_bin, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    except:
        contours, hierarchy = cv2.findContours(img_final_bin, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Sort all the contours by top to bottom
    boundingbox_pos = [cv2.boundingRect(c) for c in contours]  # left, top, width, height
    boundingbox_pos_filtered = []
    for pos in boundingbox_pos:
        if 0 not in pos and pos[1] > 1 and pos[3] > 15:
            boundingbox_pos_filtered.append(pos)
    boundingbox_pos_filtered.sort(key=lambda x: x[1])

    return boundingbox_pos_filtered


def extract_single_column_grided_table(req_folder, table_img, column_split_position, config_data):
    # crop only table region (removing unwanted left and right margin space if any)
    col_datatype = config_data["coltypes"]
    left = int(column_split_position[0].split(",")[0])
    right = int(column_split_position[0].split(",")[2])
    table_img = table_img[:, left:left + right]
    table_img_path = path.join(req_folder, str(random()) + ".png")
    cv2.imwrite(table_img_path, table_img)
    textType = "normal"
    table_img[2, :] = 0
    table_img[-2, :] = 0
    img_final_bin = morphing_image(table_img, 25, 1)
    img_final_bin = draw_row_column_lines(img_final_bin, column_split_position)
    img_bin_path = path.join(req_folder, str(column_split_position[0]) + "_img_final_bin.png")
    cv2.imwrite(img_bin_path, img_final_bin)
    img_final_bin = cv2.imread(img_bin_path, 0)
    boundingbox_pos_filtered = get_bundingbox_position(img_final_bin)
    data = cell_wise_data(req_folder, table_img_path, table_img, boundingbox_pos_filtered, textType)

    return data


def adjust_column_position(column_split_position):
    val = int(column_split_position[0].split(",")[0]) - 2
    pos_list = []
    for pos in column_split_position:
        pos_list.append([int(pos.split(",")[0]) - val, int(pos.split(",")[1]) - val, int(pos.split(",")[2]),
                         int(pos.split(",")[3])])
    return pos_list


def get_tabledata_after_smoothing_image(req_folder, table_img, column_split_position, column_headers, col_datatype,
                                        row_start_index,
                                        row_end_index, checkbox_type, table_type):
    table_data = []
    cell_pos_all = []
    for neighborhood_pixel_diameter in [7, 5, 3]:
        table_data, cell_pos_all = Table_Data_Extraction(req_folder, table_img, column_split_position, col_datatype,
                                                         row_start_index, row_end_index, checkbox_type, True,
                                                         neighborhood_pixel_diameter, table_type)
        if len(table_data) != 0 and len(table_data[0]) == len(col_datatype.split("||")):
            break
    if len(table_data) == 0 or len(table_data[0]) != len(col_datatype.split("||")):
        if table_type == "gridded":
            LINE_WIDTH = 1
            PIXEL_START_POS = 1

            for pos in column_split_position:
                table_img[1:-1, pos[0]] = 0
                if pos == column_split_position[-1]:
                    table_img[1:-1, pos[0] + pos[-2] - 1]
            # draw row lines
            for index in range(1, table_img.shape[0]):
                if sum(~table_img[index, PIXEL_START_POS:-PIXEL_START_POS]) >= 255 * (table_img.shape[1] * 0.65):
                    table_img[index, LINE_WIDTH:-LINE_WIDTH] = 0
            table_img[1:-1, -2] = 0
            table_img[1:-1, 2] = 0
            cv2.imwrite(req_folder + "/" + str(random()) + ".png", table_img)
            table_data, cell_pos_all = Table_Data_Extraction(req_folder, table_img, column_split_position, col_datatype,
                                                             row_start_index, row_end_index, checkbox_type, False,
                                                             0, table_type)

    return table_data, cell_pos_all


def extract_data_from_table_image(req_folder, table_img, img, table_type, config_data, col_datatype, table_word_cords,
                                  table_start_pos, enhance_img):
    column_split_position = config_data["matrix_coords"]
    checkbox_type = config_data['imagetype']
    row_start_index = 0 if config_data["startrow"] in ["", None] else int(config_data["startrow"])
    row_end_index = -1 if config_data["endrow"] in ["", None] else int(config_data["endrow"])

    if table_type == "regex":
        left = int(column_split_position[0].split(",")[0])
        right = int(column_split_position[0].split(",")[2])
        table_img = table_img[:, left:left + right]
        cell_pos_all = []
        img_path = path.join(req_folder, "cropped_table/regex_" + config_data["name"] + ".png")
        cv2.imwrite(img_path, table_img)
        table_data = RegexBasedTableParser(Image.open(img_path), config_data)

    elif len(column_split_position) == 1 and table_type == "gridded":
        table_data = extract_single_column_grided_table(req_folder, table_img, column_split_position,
                                                        config_data)
        cell_pos_all = []
    else:
        is_header_underline_exist = False
        if config_data["tableheaderseparator"] == "lineborder":
            is_header_underline_exist = True

        column_headers = []
        table_data = []
        cell_pos_all = []
        table_left_pos = int(column_split_position[0].split(",")[0])
        column_split_position = adjust_column_position(column_split_position)

        table_right_pos = table_left_pos + column_split_position[-1][0] + column_split_position[-1][2]
        table_img = table_img[:, table_left_pos:table_right_pos]
        cv2.imwrite(
            path.join(req_folder, "cropped_table/" + str(table_right_pos) + "_" + str(table_right_pos) + ".png"),
            table_img)

        if table_type.lower() == "virtual":
            table_img = table_without_lines(req_folder, config_data, table_img, is_header_underline_exist,
                                            column_split_position, table_word_cords, table_start_pos)
        elif table_type.lower() == "horizontal":
            table_img = table_with_hlines(table_img, column_split_position)
        elif table_type.lower() == "vertical":
            table_img = table_with_column_lines(table_img, column_split_position,
                                                config_data, table_word_cords, table_start_pos)

        # table parser starts here
        if type(table_img) == np.ndarray:
            cv2.imwrite(req_folder + "/" + config_data["name"] + "_" + str(table_img.shape[1]) + "__" + str(
                table_img.shape[0]) + ".png", table_img)

            table_data, cell_pos_all = Table_Data_Extraction(req_folder, table_img, column_split_position,
                                                             col_datatype, row_start_index,
                                                             row_end_index, checkbox_type, False, 0, table_type)

            if len(table_data) == 0 or table_data == [""]:
                table_data, cell_pos_all = get_tabledata_after_smoothing_image(req_folder, table_img,
                                                                               column_split_position, column_headers,
                                                                               col_datatype, row_start_index,
                                                                               row_end_index, checkbox_type, table_type)

    return table_data, cell_pos_all


# finding table type based on configuration
def find_table_type(config_data):
    if config_data["borderedtable"] in [1.0, True, "True", "true"]:
        table_type = "gridded"
    elif config_data["virtualtable"] in [1,"1.0", 1.0, True, "True", "true"] and "Regex" in config_data["colsep"] and "Regex" in \
            config_data["rowsep"]:
        table_type = "regex"
    elif config_data["borderedtable"] in FALSE_CHECK and config_data["rowdelimiter"] in [None, "None"] and config_data[
        "columndelimiter"] not in ["None", None]:
        table_type = "horizontal"
    elif config_data["borderedtable"] in FALSE_CHECK and config_data["rowsep"] not in ["None", None, ""] and config_data[
        "colsep"] not in ["None", None, ""]:
        table_type = "virtual"
    elif config_data["virtualtable"] in [1.0, True, "True", "true"] and config_data["rowsep"] not in ["None", None, ""] and \
            config_data["colsep"] in ["None", None, ""]:
        table_type = "vertical"

    return table_type


def get_pos_table_start_page(config_data, word_cords_all, word_cords, start_key_pos, pagenum, header_footer_dict):
    table_start_pos = word_cords.iloc[start_key_pos]['bottom']
    if config_data['tableheader'] in TRUE_CHECK:
        table_pixels_to_ignore = int(float(config_data["annotcoords"].split(",")[3]))
        table_start_pos += table_pixels_to_ignore
        page_df = word_cords_all[word_cords_all['pageno'] == pagenum]
        page_df = page_df[(page_df["top"] >= table_start_pos - 20) & (page_df["top"] <= table_start_pos + 20)]
        page_df.reset_index(drop=True)
        if len(page_df) > 0:
            table_start_pos = page_df.iloc[0]["top"] - 15

    table_end_pos = word_cords_all[word_cords_all['pageno'] == pagenum].iloc[-1]['top']
    if pagenum in header_footer_dict.keys():
        if len(header_footer_dict[pagenum]['footer_index_list']) > 0:
            table_end = word_cords_all.iloc[min(header_footer_dict[pagenum]['footer_index_list'])]
            if len(table_end) > 0:
                table_end_pos = table_end["top"]
    return table_start_pos, table_end_pos


def get_pos_table_end_page(config_data, word_cords_all, word_cords, header_footer_dict, pagenum, coords, end_key_pos):
    # table in table end string page
    table_start_pos = 0
    table_start_index = None
    PIXELS_TO_IGNORE_FROM_HEADER = 25
    if config_data['repeatingtableheader'] in TRUE_CHECK:
        table_start_index = get_table_refstr_pos(word_cords_all[word_cords_all['pageno'] == pagenum],
                                                 config_data['tablestartstr'].split("||")[0], coords, 0)
        if table_start_index is None and len(config_data['tablestartstr'].split("||")) > 1:
            table_start_index = get_table_refstr_pos(word_cords_all[word_cords_all['pageno'] == pagenum],
                                                     config_data['tablestartstr'].split("||")[1], coords, 0)

    if table_start_index:
        table_start_pos = word_cords_all.iloc[table_start_index]['bottom']
        header_pixels_to_ignore = int(float(config_data["annotcoords"].split(",")[3]))
        table_start_pos += header_pixels_to_ignore
        page_df = word_cords_all[word_cords_all['pageno'] == pagenum]
        page_df = page_df[(page_df["top"] >= table_start_pos - 20) & (page_df["top"] <= table_start_pos + 20)]
        page_df.reset_index(drop=True)
        if len(page_df) > 0:
            table_start_pos = page_df.iloc[0]["top"] - 15
    elif pagenum in header_footer_dict.keys():
        if len(header_footer_dict[pagenum]['header_index_list']):
            table_start_pos = \
                word_cords_all.iloc[max(header_footer_dict[pagenum]['header_index_list'])][
                    "bottom"] + PIXELS_TO_IGNORE_FROM_HEADER

    table_end_pos = word_cords.iloc[end_key_pos]['top']

    return table_start_pos, table_end_pos


def get_pos_table_intermediate_page(config_data, word_cords_all, word_cords, header_footer_dict, pagenum, coords):
    PIXELS_TO_IGNORE_FROM_HEADER = 25
    table_start_index = None
    table_start_pos = 0
    if config_data['repeatingtableheader'] in TRUE_CHECK:
        table_start_index = get_table_refstr_pos(word_cords_all[word_cords_all['pageno'] == pagenum],
                                                 config_data['tablestartstr'].split("||")[0], coords, 0)
        if table_start_index is None and len(config_data['tablestartstr'].split("||")) > 1:
            table_start_index = get_table_refstr_pos(word_cords_all[word_cords_all['pageno'] == pagenum],
                                                     config_data['tablestartstr'].split("||")[1], coords, 0)

    if table_start_index:
        table_start_pos = word_cords_all.iloc[table_start_index]['bottom']
        header_pixels_to_ignore = int(float(config_data["annotcoords"].split(",")[3]))
        table_start_pos += header_pixels_to_ignore

        page_df = word_cords_all[word_cords_all['pageno'] == pagenum]
        page_df = page_df[(page_df["top"] >= table_start_pos - 20) & (page_df["top"] <= table_start_pos + 20)]
        page_df.reset_index(drop=True)

        if len(page_df) > 0:
            table_start_pos = page_df.iloc[0]["top"] - 15

    elif pagenum in header_footer_dict.keys():
        if len(header_footer_dict[pagenum]['header_index_list']):
            table_start_pos = \
                word_cords_all.iloc[max(header_footer_dict[pagenum]['header_index_list'])][
                    "bottom"] + PIXELS_TO_IGNORE_FROM_HEADER

    table_end_pos = word_cords_all[word_cords_all['pageno'] == pagenum].iloc[-1]['top']
    if pagenum in header_footer_dict.keys():
        if len(header_footer_dict[pagenum]['footer_index_list']) > 0:
            table_end = word_cords_all.iloc[min(header_footer_dict[pagenum]['footer_index_list'])]
            if len(table_end) > 0:
                table_end_pos = table_end["top"]

    return table_start_pos, table_end_pos


def removing_empty_lists(table_data):
    empty_rows = []
    for row_index in range(len(table_data)):
        col_len = len(table_data[row_index])
        empty_count = 0
        for cell_index in range(len(table_data[row_index])):
            if table_data[row_index][cell_index] in ["", " ", "\n", " \n"] or table_data[row_index][
                cell_index] is None:
                empty_count += 1
        if empty_count == col_len:
            empty_rows.append(row_index)

    data = []
    for list_index in range(len(table_data)):
        if list_index not in empty_rows:
            data.append(table_data[list_index])
    if len(data) == 0:
        data = ["" for x in range(len(table_data[0]))]

    return data


def find_end_key_index(config_data, word_cords, coords, start_key_pos):
    end_key_pos = None
    end_key_pos = get_table_refstr_pos(word_cords, config_data['tableendstr'].split("||")[0], coords, start_key_pos + 1)
    if end_key_pos is None and len(config_data['tableendstr'].split("||")) > 1:
        end_key_pos = get_table_refstr_pos(word_cords, config_data['tableendstr'].split("||")[1], coords,
                                           start_key_pos + 1)

    return end_key_pos


# to handle when section is missing in form
def get_end_key_pos(word_cords, config_data, coords, start_key_pos):
    end_key_pos = None
    for end_string in config_data['tableendstr'].split("||"):
        end_key_pos = get_table_refstr_pos(word_cords, end_string, coords, start_key_pos + 1)
        if end_key_pos:
            break
    # if end string is not found then assume index of last word as end string index position
    if end_key_pos is None:
        end_key_pos = word_cords.index[word_cords['pageno'] == word_cords.iloc[start_key_pos]['pageno']].tolist()[
            -1]

    return end_key_pos


def apply_table_parser(config_data, word_cords, word_cords_all, req_folder, header_footer_dict, enhance_img):
    MIN_TABLE_HEIGHT = 100
    coords = ""
    table_data = []
    cell_pos_all = []
    table_type = find_table_type(config_data)
    start_key_pos = get_table_refstr_pos(word_cords, config_data['tablestartstr'].split("||")[0], coords, 0)
    if start_key_pos is None and len(config_data['tablestartstr'].split("||")) > 1:
        start_key_pos = get_table_refstr_pos(word_cords, config_data['tablestartstr'].split("||")[1], coords, 0)

    if start_key_pos:
        if config_data['tableendstr'] in ["Page end position", "page end position", ""]:
            word_cords_filtered = word_cords.iloc[start_key_pos:]
            page_num = word_cords_filtered.iloc[0]['pageno']
            end_key_pos = word_cords[word_cords['pageno'] == page_num].index[-1]
        else:
            end_key_pos = get_end_key_pos(word_cords, config_data, coords, start_key_pos)

        start_key_page = word_cords.iloc[start_key_pos]['pageno']
        end_key_page = word_cords.iloc[end_key_pos]['pageno']

        for pagenum in range(start_key_page, end_key_page + 1):
            img = cv2.imread(path.join(req_folder + "/png/form_png-" + str(pagenum) + ".png"), 0)
            if pagenum == start_key_page and start_key_page == end_key_page:
                if img in [None, ""]:
                    img = cv2.imread(path.join(req_folder + "/png/form_png.png"), 0)
                table_start_pos = word_cords.iloc[start_key_pos]['bottom']
                table_end_pos = word_cords.iloc[end_key_pos]['top']
                if config_data['tableendstr'] in ["Page end position", "page end position"]:
                    table_end_pos = img.shape[0] - 5  # ignoring last 5 pixels
                if config_data['tableheader'] in TRUE_CHECK:
                    table_pixels_to_ignore = int(float(config_data["annotcoords"].split(",")[3]))
                    table_start_pos = int(table_start_pos) + table_pixels_to_ignore
            elif pagenum < end_key_page and pagenum == start_key_page:
                table_start_pos, table_end_pos = get_pos_table_start_page(config_data, word_cords_all, word_cords,
                                                                          start_key_pos,
                                                                          pagenum, header_footer_dict)
            elif pagenum > start_key_page and pagenum < end_key_page:
                table_start_pos, table_end_pos = get_pos_table_intermediate_page(config_data, word_cords_all,
                                                                                 word_cords, header_footer_dict,
                                                                                 pagenum, coords)
            elif pagenum == end_key_page and start_key_page != end_key_page:
                table_start_pos, table_end_pos = get_pos_table_end_page(config_data, word_cords_all, word_cords,
                                                                        header_footer_dict, pagenum, coords,
                                                                        end_key_pos)
            width = img.shape[1]
            height = int(abs(int(float(table_end_pos)) - table_start_pos))
            table_img = img[int(table_start_pos):int(table_start_pos) + height, 0:width]  # format : img[y:y+h, x:x+w]

            table_img_path = path.join(req_folder, "cropped_table/" + config_data["name"] + "_" + str(height) + ".png")
            cv2.imwrite(table_img_path, table_img)

            if table_img.shape[0] > MIN_TABLE_HEIGHT:
                table_word_cords = word_cords[start_key_pos:end_key_pos]
                data, cell_pos_all = extract_data_from_table_image(req_folder, table_img, img, table_type,
                                                                   config_data, config_data["coltypes"],
                                                                   table_word_cords, table_start_pos, enhance_img)
                if len(data) > 0:
                    table_data.extend(data)

    if not table_data:
        table_data = ["" for i in range(len(config_data["coltypes"].split("||")))]

    return table_data, cell_pos_all


def get_matrix_data(config, extracted_data_json, png_filepaths, req_folder):
    config_matrix_data = config[config['annotationmatrix'] == True]

    config_freetext_matrix_data = config_matrix_data[(config_matrix_data['datastringtype'] == "freetext")]
    config_cb_matrixdata = config_matrix_data[(config_matrix_data['datastringtype'] == "image")]

    extracted_matrixdata_df = get_config_matrixdata_df(config_matrix_data, config_freetext_matrix_data, req_folder,
                                                       png_filepaths)
    extracted_cb_matrixdata_df = get_config_checkbox_in_matrixdata(config_cb_matrixdata, png_filepaths, form_config_params)

    extracted_data_json = get_extracted_data_json(config_freetext_matrix_data, extracted_matrixdata_df,
                                                  extracted_data_json)
    extracted_data_json = get_extracted_data_json(config_cb_matrixdata, extracted_cb_matrixdata_df,
                                                  extracted_data_json)

    return extracted_data_json


# this is the first method to call that will return a list of json
def get_imagepdf_data(form_id, png_filepaths, page_config_json, config, req_folder, enhance_img, form_config_params):
    word_cords_all = get_word_cords(req_folder, png_filepaths, page_config_json, form_id)
    header_footer_dict, header_footer_index_all = get_header_footer_position(word_cords_all, page_config_json)
    word_cords = word_cords_all.drop(word_cords_all.index[header_footer_index_all["index"]])
    word_cords = word_cords.reset_index(drop=True)
    word_cords_all.to_csv(req_folder + "/word_cords_all.csv")
    word_cords.to_csv(req_folder + "/word_cords_partial.csv")

    # save_surf_features(req_folder, form_id, png_filepaths) # to be used in future

    extracted_data_json = []
    extracted_data = ""
    for row_num in range(len(config)):
        config_data = config.iloc[row_num]
        json_data = {}
        json_data["AnnotID"] = config_data['annotid']
        json_data["class"] = config_data['name']

        if config_data['annotationmatrix'] in FALSE_CHECK:
            if config_data['datastringtype'] == "freetext":
                textType = "normal"
                if config_data['name'] in handwritten_sections:
                    textType = "handwritten"
                extracted_data = get_freetext_data(req_folder, png_filepaths, config_data, word_cords, page_config_json,
                                                   textType)
            elif config_data['datastringtype'] == "image":
                extracted_data = get_checkbox_values(req_folder, word_cords, config_data, png_filepaths, form_config_params)
                if len(extracted_data) == 1:
                    extracted_data = extracted_data[0]
            elif config_data['datastringtype'] == "keyvaluepairs":
                extracted_data = get_keyvalue_data(config_data, word_cords)
            elif config_data['datastringtype'] == "table":
                extracted_data, cell_pos_all = apply_table_parser(config_data, word_cords, word_cords_all, req_folder,
                                                                  header_footer_dict, enhance_img)
                if len(extracted_data) > 1:
                    extracted_data = removing_empty_lists(extracted_data)

        json_data["value"] = extracted_data
        extracted_data_json.append(json_data)

    # for matrixannotation
    if len(config[config['annotationmatrix'] == True]) > 0:
        extracted_data_json = get_matrix_data(config, extracted_data_json, png_filepaths, req_folder, form_config_params)

    return extracted_data_json
