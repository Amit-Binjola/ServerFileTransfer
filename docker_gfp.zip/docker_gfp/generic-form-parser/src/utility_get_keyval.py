#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr  6 14:40:17 2020

@author: aditya
"""

def utility_find_key(list_of_keys , value):
    keys_in_value  = [key for key in list_of_keys if key in value]
    return keys_in_value

def utility_find_startkey(list_of_keys , value):
    keys_in_value  = [key for key in list_of_keys if value.startswith(key)]
    return keys_in_value

def set_value_in_dict(list_of_keys,key_val_dict,text,current_key,has_start_key):
    keys_found = utility_find_key(list_of_keys , text)
    value = text
    if len(keys_found) == 0:
        if has_start_key == True:
            try:
                key_val_dict[current_key] = value
            except:
                pass
        else:
            try:
                key_val_dict[current_key] += value
            except:
                pass

    if len(keys_found) >0:
        key = keys_found[0]

        value_list = text.split(key)
        if len(value_list) ==2:
            if has_start_key == True:
                key_val_dict[current_key] = value_list[0]
            else:
                if current_key:
                    key_val_dict[current_key] += value_list[0]

            if key_val_dict[key] in ("",None):
                key_val_dict[key] = value_list[1]
            key_val_dict = set_value_in_dict(list_of_keys,key_val_dict,value_list[1],key,has_start_key)
        elif len(value_list) == 1:
            if key_val_dict[key] in ("",None):
                key_val_dict[key] = value_list[0]

    return key_val_dict

def get_dict_from_list(list_of_keys,list_of_text):
    list_of_keys = [key.strip() for key in list_of_keys]
    key_val_dict = {}
    previous_start_key = ''
    for key in list_of_keys:
        for text in list_of_text:
            if key in text:
                key_val_dict[key] = ''
                break

    for text_index , text in enumerate(list_of_text) :
        start_keys = utility_find_startkey(list_of_keys , text)
        value_already_present_flag = False

        if len(start_keys)>0:
            for key in key_val_dict.keys():
                if key_val_dict[start_keys[0]]:
                    value_already_present_flag = True
                    break
            if value_already_present_flag == False:
                previous_start_key = start_keys[0]
                key_val_dict = set_value_in_dict(list_of_keys,key_val_dict,text,start_keys[0],has_start_key = True)

        else:
            key_val_dict = set_value_in_dict(list_of_keys,key_val_dict,text,previous_start_key,has_start_key = False)

    #if "key" is present as part of the value, remove "key"
    for key,val in key_val_dict.items():
        if val:
            val = val.replace(key,"")
            key_val_dict[key] = val.strip()

    return key_val_dict


# list_of_text = ['Report Number2020-0023350 External ID', 'Receipt Date11/Feb/2020 StatusCompleted', 'Initial ReporterGreen, Joshua Country ofUS', 'Occurrence']
# list_of_keys = ['Report Number', 'External ID',
#                 'Receipt Date' ,'Status',
#                 'Initial Reporter','Country of' ,
#                                     'Occurrence']
#list_of_text = [
#                'NameJoshua Green GenderMale',
#                 'Addressinitial reporter / patient Phone(704) 891-2172',
#                 '1733 Proposal Ave. Contact',
#                 'Chester, SC 29706 Phone',
#                 'US',
#                 'Fax',
#                 'E-Mail',
#                 'ClassMOP TypeConsumer',
#                 'GreetingDear Salutation',
#                 'Degree'
#                ]
