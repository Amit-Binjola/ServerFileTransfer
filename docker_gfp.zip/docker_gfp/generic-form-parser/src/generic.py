#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 26 13:58:26 2019

@author: aditya
"""
import json, uuid, shutil, gc
from os import path, mkdir, getenv
# from flask_swagger_ui import get_swaggerui_blueprint
from requests import post
from flask import Flask, request, send_from_directory, send_file, jsonify
from common_utils import reading_json
from extract_data import create_extracted_data_json
from config import CONFIG_JSON, UPLOAD_FOLDER, TEMPLATE_FOLDER, logger
from populate_PVI_json import createFinalJson
from strike_off_text_detector import get_strike_off_data

METADATAJSON_UPLOAD_FOLDER = path.join(TEMPLATE_FOLDER + "metadata_json")
FORM_CONFIG_FOLDER = path.join(TEMPLATE_FOLDER, "form_configurations")

URL = CONFIG_JSON['base-url-internal']
PORT = CONFIG_JSON['form-process-service-port']
app = Flask(__name__)


def clc():
    gl = globals().copy()
    for var in gl:
        # if var[0] == '_': continue
        # if 'func' or 'class' in str(globals()[var]):continue  # uncomment this if you want to keep the methods
        # if 'module' in str(globals()[var]): continue
        del globals()[var]
    gc.collect()


# to check whether the extension of a file is from ALLOWED_EXTENSIONS
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ('docx', 'pdf', 'txt', 'csv')


# utility method to create the directories in the Request folder
def create_dir(REQUEST_UPLOAD_FOLDER):
    if path.exists(REQUEST_UPLOAD_FOLDER) == False:
        mkdir(REQUEST_UPLOAD_FOLDER)
    if path.exists(REQUEST_UPLOAD_FOLDER + "/ocr") == False:
        mkdir(REQUEST_UPLOAD_FOLDER + "/ocr")
    if path.exists(REQUEST_UPLOAD_FOLDER + "/png") == False:
        mkdir(REQUEST_UPLOAD_FOLDER + "/png")
    if path.exists(REQUEST_UPLOAD_FOLDER + "/checkboxes") == False:
        mkdir(REQUEST_UPLOAD_FOLDER + "/checkboxes")

    if path.exists(REQUEST_UPLOAD_FOLDER + "/tmp") == False:
        mkdir(REQUEST_UPLOAD_FOLDER + "/tmp")
        
    if path.exists(REQUEST_UPLOAD_FOLDER + "/cropped_images") == False:
        mkdir(REQUEST_UPLOAD_FOLDER + "/cropped_images")
    if path.exists(REQUEST_UPLOAD_FOLDER + "/form") == False:
        mkdir(REQUEST_UPLOAD_FOLDER + "/form")
    if path.exists(REQUEST_UPLOAD_FOLDER + "/cropped_table") == False:
        mkdir(REQUEST_UPLOAD_FOLDER + "/cropped_table")
    if path.exists(REQUEST_UPLOAD_FOLDER + "/cbox") == False:
        mkdir(REQUEST_UPLOAD_FOLDER + "/cbox")

    logger.info("DIRECTORIES CREATED")


# utility method to check whether all parameters in body form data received
def check_form_data(input_data):
    response = "success"
    for key, value_type in input_data.items():
        if (value_type == 'text' and key not in request.form) or (value_type == 'file' and key not in request.files):
            response = key + " not received"
            logger.error('%s not received', key)
            break
    return response


# api request for entry point into generic form parser when called from parent ML API
@app.route('/api/processForm', methods=['POST'])
def process_form():
    logger.info("*" * 20 + " processForm Request received " + "*" * 20)
    check_inputs_msg = check_form_data({'form_id': 'text', 'file1': 'file'})
    if "not received" in check_inputs_msg:
        response = json.dumps({'message': check_inputs_msg})
    else:
        logger.info("processForm - all parameters in body form data correctly received")

        if not allowed_file(request.files['file1'].filename):
            logger.error("file-type not supported")
            response = json.dumps({'message': "processForm - file-type not supported"})
        else:
            form_id, input_form = request.form['form_id'], request.files['file1']
            logger.info("filename : %s", input_form.filename)
            if not path.exists(path.join(FORM_CONFIG_FOLDER, form_id + ".json")):
                response = json.dumps({'message': "form configuration file not found for the formid"})
                logger.error("form configuration file not found for the formid")
            else:
                form_configpath = path.join(FORM_CONFIG_FOLDER, form_id + ".json")
                form_config = reading_json(form_configpath)
                doctype = form_config["formtype"]
                outputformat = form_config["outputformat"]
                form_config_str = json.dumps(form_config)

                post_data = {'form_id': form_id, 'enhance_img': "false", "form_config": form_config_str,
                             'outputformat': outputformat, 'doctype': doctype, 'metadata_config': ""}

                api_getKeyValues_url = "http://" + URL + ":" + str(PORT) + "/api/getKeyValues"
                logger.info("sending api/getKeyValues request at url : %s", api_getKeyValues_url)

                result = post(api_getKeyValues_url, files={'file1': input_form}, data=post_data)
                extracted_data_json = (result.json())[0]
                final_json = (result.json())[1]
                response = final_json 

                if response != {'message': "error in Parsing"}:
                    logger.info("Form parsed successfully")
    logger.info("*" * 20 + " processForm request completed " + "*" * 20)
    return jsonify(response)


# request for extracting all the data in the testing form and return the populated Json
@app.route('/api/getKeyValues', methods=['POST'])
def generate_json():
    logger.info("*" * 20 + " getKeyValues Request received " + "*" * 20)
    request_id = str(uuid.uuid4())
    logger.info("Request id assigned: %s", request_id)
    REQUEST_UPLOAD_FOLDER = path.join(UPLOAD_FOLDER, "Request-" + request_id)
    check_inputs_msg = check_form_data({'file1': 'file', 'doctype': 'text', 'form_id': 'text', 'enhance_img': 'text',
                                        'outputformat': 'text', 'form_config': 'text', 'metadata_config': 'text'})

    if "not received" in check_inputs_msg:
        response = json.dumps({'message': check_inputs_msg})
    else:
        logger.info("getKeyvalues - all parameters in body form data received")
        doctype, form_id, input_form = request.form['doctype'], request.form['form_id'], request.files['file1']
        outputformat, form_config = request.form['outputformat'], request.form['form_config']
        print("form_id=", form_id)
        enhance_img, metadata_config = request.form['enhance_img'], request.form["metadata_config"]

        logger.info("doctype : %s", doctype)
        logger.info("form id : %s", form_id)
        logger.info("outputformat : %s", outputformat)
        logger.info("filename : %s", input_form.filename)
        if metadata_config:
            metadata_config = eval(metadata_config.replace("false", "False").replace("true", "True"))

        create_dir(REQUEST_UPLOAD_FOLDER)
        form_config = json.loads(form_config)
        if type(form_config['configdefinition']) == str:
            form_config['configdefinition'] = json.loads(form_config["configdefinition"])
        if type(form_config['formsummary']) == str:
            form_config["formsummary"] = json.loads(form_config["formsummary"])
        try:
            if type(form_config['docxmetadata']) == str:
                form_config["docxmetadata"] = json.loads(form_config["docxmetadata"])
        except:
            response = {'message': 'docxmetadata is invalid.'}

        if "delimitedtext" in doctype or "csv" in doctype:
            input_form_path = path.join(REQUEST_UPLOAD_FOLDER, "form.txt")
        elif "pdf" in doctype:
            input_form_path = path.join(REQUEST_UPLOAD_FOLDER, "form.pdf")
        elif "docx" in doctype:
            input_form_path = path.join(REQUEST_UPLOAD_FOLDER, "form.docx")
        input_form.save(input_form_path)
        logger.info("input form saved")
        input_dict = {"request_folder": REQUEST_UPLOAD_FOLDER, "input_form_path": input_form_path, "doctype": doctype,
                      "form_id": form_id, "output_format": outputformat, "form_config": form_config,
                      "enhance_img": enhance_img, "metadata_config": metadata_config}
        try:
            response = create_extracted_data_json(input_dict)
        except:
            response = [{'message': "error in Parsing"},
                        {'message': "error in Parsing"}]
        shutil.rmtree(REQUEST_UPLOAD_FOLDER)
        logger.info("removed REQUEST FOLDER")

    logger.info("*" * 20 + " getKeyValues request completed : " + "*" * 20)
    return json.dumps(response)


# api request for IntermediateJSON
@app.route('/api/getIntermediateJSON', methods=['POST'])
def intermediate_json():
    logger.info("*" * 20 + " processForm Request received " + "*" * 20)
    check_inputs_msg = check_form_data({'form_id': 'text', 'file1': 'file'})
    if "not received" in check_inputs_msg:
        response = json.dumps({'message': check_inputs_msg})
    else:
        logger.info("processForm - all parameters in body form data correctly received")

        if not allowed_file(request.files['file1'].filename):
            logger.error("file-type not supported")
            response = json.dumps({'message': "processForm - file-type not supported"})
        else:
            form_id, input_form = request.form['form_id'], request.files['file1']
            logger.info("filename : %s", input_form.filename)
            if not path.exists(path.join(FORM_CONFIG_FOLDER, form_id + ".json")):
                response = json.dumps({'message': "form configuration file not found for the formid"})
                logger.error("form configuration file not found for the formid")
            else:
                form_configpath = path.join(FORM_CONFIG_FOLDER, form_id + ".json")
                form_config = reading_json(form_configpath)
                doctype = form_config["formtype"]
                outputformat = form_config["outputformat"]
                form_config_str = json.dumps(form_config)

                post_data = {'form_id': form_id, 'enhance_img': "false", "form_config": form_config_str,
                             'outputformat': outputformat, 'doctype': doctype, 'metadata_config': ""}

                api_getKeyValues_url = "http://" + URL + ":" + str(PORT) + "/api/getKeyValues"
                logger.info("sending api/getKeyValues request at url : %s", api_getKeyValues_url)

                result = post(api_getKeyValues_url, files={'file1': input_form}, data=post_data)
                extracted_data_json = (result.json())[0]
                final_json = (result.json())[1]
                response = extracted_data_json

                if response != {'message': "error in Parsing"}:
                    logger.info("Form parsed successfully")
    logger.info("*" * 20 + " processForm request completed " + "*" * 20)
    return jsonify(response)

@app.route('/api/populateJson', methods=['POST'])
def populate_json():
    logger.info("*" * 20 + " populateJson Request received " + "*" * 20)
    check_inputs_msg = check_form_data({'outputformat': 'text', 'extracted_data_json': 'text', 'form_id': 'text'})
    if "not received" in check_inputs_msg:
        response = json.dumps({'message': check_inputs_msg})
    else:
        logger.info("populateJson - all parameters in form data correctly received")
        outputformat, form_id = request.form['outputformat'], request.form['form_id']
        extracted_data_json = request.form['extracted_data_json']
        if type(extracted_data_json) == str:
            extracted_data_json = json.loads(extracted_data_json)

        if not path.exists(path.join(FORM_CONFIG_FOLDER, form_id + ".json")):
            response = json.dumps({'message': "form configuration file not found for the formid"})
            logger.error("form configuration file not found for the formid")
        else:
            form_configpath = path.join(FORM_CONFIG_FOLDER, form_id + ".json")
            form_config = reading_json(form_configpath)
            mapping_data = form_config["configdefinition"]

            final_populated_json = createFinalJson(mapping_data, extracted_data_json, outputformat, form_id)
            response = final_populated_json
            logger.info("Json populated successfully")

    logger.info("*" * 20 + " populateJson request completed " + "*" * 20)
    return response


# used to retrieve the png stored in the server using the url of the png
@app.route('/<name>', methods=['GET'])
def get_file(name):
    file = name
    FORM_FOLDER = TEMPLATE_FOLDER + "/forms/"
    PNG_FOLDER = TEMPLATE_FOLDER + "/png/"
    containing_folder = None
    for folder in [FORM_FOLDER, PNG_FOLDER, METADATAJSON_UPLOAD_FOLDER]:
        if path.isfile(folder + file):
            containing_folder = folder
            break
    if containing_folder:
        with open(containing_folder + file, 'rb') as static_file:
            response = send_file(containing_folder + file, as_attachment=False)
    else:
        response = json.dumps({"message": "Invalid URL"})
    return response


# request for getting the swagger.json file from /static directory
@app.route('/static/<path:path>', methods=['GET'])
def send_static(path):
    return send_from_directory('static', path)


@app.route('/api/strikethroughline', methods=['POST'])
def detect_strikethroughline():
    request_id = str(uuid.uuid4())
    input_form = request.files["form"]
    file_path = path.join(getenv("HOME"), "backendservice/utility/uploads/")
    REQUEST_UPLOAD_FOLDER = path.join(file_path, request_id)
    input_form_path = path.join(REQUEST_UPLOAD_FOLDER, "form.pdf")
    mkdir(REQUEST_UPLOAD_FOLDER)
    input_form.save(input_form_path)
    output = get_strike_off_data(input_form_path)
    shutil.rmtree(REQUEST_UPLOAD_FOLDER)
    return output


# swagger UI documentation
# SWAGGER_URL = '/swagger'
# API_URL = '/static/swagger.json'
# SWAGGERUI_BLUEPRINT = get_swaggerui_blueprint(
#     SWAGGER_URL,
#     API_URL,
#     config={
#         'app_name': "Generic Form Parser"
#     }
# )
# app.register_blueprint(SWAGGERUI_BLUEPRINT, url_prefix=SWAGGER_URL)

if __name__ == '__main__':
    app.run(URL, port=PORT, debug=False)
