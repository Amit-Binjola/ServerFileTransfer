#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun 13 11:40:29 2020

@author: aditya
"""
import copy
import time

import cv2, pdfplumber, re
import numpy as np
import pandas as pd
from copy import deepcopy
from utility_get_keyval import get_dict_from_list
from utility_convert_coord import get_calc_coord, convert_UI_coord_to_plumber
from config import CONFIG_JSON, logger, NULL_CHECK, FALSE_CHECK, TRUE_CHECK
from common_utils import get_all_occurences_data, get_header_footer_position, eliminate_header_rows_using_startrow, garbage_removed_data
from checkbox_classifier import checkbox_classifier
from regex_table_extraction import RegexBasedTableParser
from decimal import Decimal
from os import path

MIN_X0_DIFF = 2.5
BLOCK_SIZE = 25
THRESHOLD_CONSTANT = 0
MAX_ROW_SEP_WORDS = 7
GARBAGE_PIXELS_THRESH = 255
TABLE_CHECKBOX_ROW_LINE_SPLIT_THRESH = 8
BOTTOM_DIFF_THRES = 5


def get_key_start_index(word, sentence):
    return [n for n in range(len(sentence)) if sentence.find(word, n) == n]


# method to handle keys when it continues to next line
def get_textlist(list_of_keys, lists_of_text):
    lists_of_text = [text for text in lists_of_text if text]  # to remove empty string
    string_of_text = " ".join(lists_of_text)  # string of text
    key_start_indices = []
    for key in list_of_keys:
        key_start_indices.extend(get_key_start_index(key, string_of_text))

    key_start_indices.sort()
    final_list = []
    for key_index in range(len(key_start_indices)):
        if key_index < len(key_start_indices) - 1:
            final_list.append(
                string_of_text[key_start_indices[key_index]:key_start_indices[key_index + 1]].replace("  ", "").strip())
        else:
            final_list.append(string_of_text[key_start_indices[key_index]:].replace("  ", "").strip())
    return final_list


def remove_unwanted_keysfromlist(list_of_keys, lists_of_text):
    for listkey in list_of_keys:
        lists_of_text.replace(listkey, "")
    return lists_of_text.strip()


# get the words dataframe from pdfplumber
def get_dataframe(pdf_file, form_config_params):
    pdf = pdfplumber.open(pdf_file)
    all_text_list = []
    for page_indx in range(len(pdf.pages)):
        page_text = pdf.pages[page_indx].extract_words(y_tolerance=form_config_params["plumber_tolerance"]["PLUMBER_Y_TOLERANCE"], x_tolerance=form_config_params["plumber_tolerance"]["PLUMBER_X_TOLERANCE"])
        for word_indx in range(len(page_text)):
            page_text[word_indx]["pageno"] = page_indx
        all_text_list.extend(page_text)
    data = pd.DataFrame(all_text_list)
    return data, pdf


# remove header footer text(to be optimised)
def remove_header_footer_text(page_config_json, page_num, extracted_data):
    headers = []
    footers = []
    for page_config in page_config_json["pages"]:
        if page_config["pageheaderidentifier"]:
            headers.append(page_config["pageheaderidentifier"])
        if page_config["pagefooteridentifier"]:
            footers.append(page_config["pagefooteridentifier"])

    if len(headers) > 0:
        head_indx = [extracted_data.index(value) for value in extracted_data for header in headers if header in value]

    if len(footers) > 0:
        foot_indx = [extracted_data.index(value) for value in extracted_data for header in headers if header in value]

    word_indexes_to_remove = head_indx.extend(foot_indx)
    header_footer_filtered = [extracted_data[indx] for indx in range(len(extracted_data)) if
                              indx not in word_indexes_to_remove]

    return header_footer_filtered


# find the row index of the given string in the words dataframe  which is closest to the annot coordinates left
def get_key_row_position(words_df, word_string, coords, afterref_indx):
    word_index = None
    if len(words_df) > 0:
        page = words_df.iloc[afterref_indx]['pageno']
        if word_string in ("", None):
            word_index = list(words_df[words_df['pageno'] == page].iloc[-1:].index.values)[0]
        else:
            list_words = word_string.strip("\n").split(" ")
            words_df_filtered = words_df.iloc[afterref_indx:]
            givenkey = " ".join([str(elem) for elem in list_words])
            for indx in range(0, len(words_df_filtered)):
                concate_words = ""
                for no_indx in range(0, len(list_words)):
                    if no_indx + indx < len(words_df_filtered):
                        concate_words = " ".join([concate_words, words_df_filtered.iloc[no_indx + indx]['text']])
                if "regex" in givenkey:
                    find_str = re.compile(givenkey.replace("regex::", "").strip()).findall(concate_words.strip())
                    if len(find_str) > 0:
                        word_index = int(
                            str(words_df_filtered.iloc[indx]).split("Name:")[-1].split(', dtype')[0].strip())
                        break
                elif givenkey == concate_words.strip():
                    word_index = int(str(words_df_filtered.iloc[indx]).split("Name:")[-1].split(', dtype')[0].strip())
                    break

    return word_index


def find_occcurences(words_df, start_string, end_string):
    start_string_list = start_string.strip("\n").split(" ")
    occurence_indexes = []
    after_index = 0
    if len(start_string_list) > 0:
        while after_index < len(words_df) - 1:
            startstr_occurence_index = get_key_row_position(words_df, start_string, "", after_index)
            after_index += 1
            if startstr_occurence_index not in NULL_CHECK:
                endstr_occurence_index = get_key_row_position(words_df, end_string, "", startstr_occurence_index + 1)
                occurence_indexes.append([startstr_occurence_index, endstr_occurence_index])
                after_index = startstr_occurence_index + 1
            else:
                break

    return occurence_indexes


def find_index(word_cords, coords, reference_strings, index_start, before_or_after, header_footer_dict):
    search_string_pos = None
    matched = False
    # coords = coords.split("||"), will be used in future
    ref_strings = reference_strings.split("||")
    for search_string_indx in range(len(ref_strings)):
        search_string_pos = get_key_row_position(word_cords, ref_strings[search_string_indx], "", index_start)
        if search_string_pos not in NULL_CHECK:
            matched = True
            break
    if matched == False:
        if before_or_after == "before":  # before reference string or end string.
            end_page = word_cords.iloc[-1]["pageno"]
            if end_page in header_footer_dict.keys():
                search_string_pos = len(word_cords) - 1
                if header_footer_dict[end_page]["footer_index_list"]:
                    search_string_pos = header_footer_dict[end_page]["footer_index_list"][0]
            else:
                search_string_pos = len(word_cords) - 1
            search_string_indx = 0
    return search_string_pos, search_string_indx, matched


# placeholder method to  extract  delimited annotation data , will be completed when delimited data comes
def get_delimited_data(config_data, words_df, pdf, page_config_json, header_footer_dict):
    delimited_op = []
    return delimited_op


def remove_parent_keys(lists_of_text, start_key, end_key):
    s_key = " ".join(start_key)
    e_key = " ".join(end_key)
    text_filtered = []

    for text in lists_of_text:
        if text.startswith(s_key):
            filtered = text[len(s_key):]
            text_filtered.append(filtered.strip())
        elif text.startswith(e_key):
            filtered = text[len(s_key):]
            text_filtered.append(filtered.strip())
        else:
            text_filtered.append(text.strip())

    return text_filtered


# utility method to extract key value pair data
def extract_data_betweenkeys_for_keyval(start_key, end_key, start_position, end_position, words_df, annotcoords):
    data1 = words_df.iloc[start_position:end_position]
    data1 = data1.append(data1.iloc[-1])

    final_data = []
    partial_data = ""
    total_rows = len(data1) - 1
    for indx in range(0, total_rows):
        bottom_diff = abs(data1.iloc[indx + 1]['bottom'] - data1.iloc[indx]['bottom'])
        if bottom_diff >= 0 and bottom_diff < BOTTOM_DIFF_THRES:
            partial_data = " ".join([partial_data, data1.iloc[indx]["text"]])
        else:
            partial_data = " ".join([partial_data, data1.iloc[indx]["text"]])
            final_data.append(partial_data.strip())
            partial_data = ""
        if indx == total_rows - 1:
            final_data.append(partial_data)

    return final_data


# extraction of keyvalue pair annotation data
def get_keyvalue_data(config_data, words_df, pdf, page_config_json, header_footer_dict):
    # we are not using after/beforerefstring for keyvalue pairs
    key_val_op = []
    if config_data['annotationtype'] != "virtual":
        extract_start_str = config_data['extstartstr']
        extract_end_str = config_data['extendstr']
        start_position, matching_index, matched = find_index(words_df, "", config_data['extstartstr'], 0, "after",
                                                             header_footer_dict)

        if start_position:
            start_key_page = words_df.iloc[start_position]['pageno']
            end_position, matching_index, matched = find_index(words_df, "", config_data['extendstr'], start_position,
                                                               "before", header_footer_dict)
            if end_position is None:
                end_key_page = start_key_page
                end_position = len(words_df)  # words_df[words_df['pageno']==start_key_page]
            elif end_position:
                end_key_page = words_df.iloc[end_position]['pageno']

            lists_of_text = extract_data_betweenkeys_for_keyval(extract_start_str, extract_end_str, start_position,
                                                                end_position, words_df, config_data["annotcoords"])
            lists_of_text = remove_parent_keys(lists_of_text, extract_start_str, extract_end_str)

            lists_of_text = get_textlist(config_data['formkeylist'], lists_of_text)

            ''' remove header footer text
            if end_key_page != start_key_page and len(lists_of_text) > 0:
                lists_of_text = remove_header_footer_text(page_config_json, start_key_page, lists_of_text) '''

            if config_data['formkeylist']:
                if config_data["repeatableannot"] and config_data['recordseperator']:
                    key_val_op = []
                    section_data = get_all_occurences_data(lists_of_text, config_data['recordseperator'])
                    for list_of_text in section_data:
                        key_val_dict = get_dict_from_list(config_data['formkeylist'], list_of_text)
                        key_val_op.append(key_val_dict)
                else:
                    key_val_op = get_dict_from_list(config_data['formkeylist'], lists_of_text)

    return key_val_op


# def extract_repeatable_freetext_data(words_df, pdf, afterstr_indx, beforestr_indx, config_data):
#     data = []
#     afterstr_dict = words_df.iloc[afterstr_indx].to_dict()
#     startpage = afterstr_dict['pageno']
#     beforestr_dict = words_df.iloc[beforestr_indx].to_dict()
#     afterrefcoords = convert_plumber_coord_to_UI(afterstr_dict)
#     beforerefcoords = convert_plumber_coord_to_UI(beforestr_dict)
#     calc_annot_coord = get_calc_coord(afterrefcoords, beforerefcoords, config_data['annotcoords'],
#                                             afterstr_dict, beforestr_dict)
#
#     bbox = (calc_annot_coord['left'], calc_annot_coord['top'], calc_annot_coord['right'], calc_annot_coord['bottom'])
#     cropped_section = pdf.pages[startpage].crop(bbox)
#     # cropped_section.to_image().save(REQ_FOLDER + '/png/cropped_freetext.png',format = "png")
#     extracted_data = cropped_section.extract_text()
#     if extracted_data:
#         extracted_data = extracted_data.split("\n")
#         data.extend(extracted_data)
#
#     return data

# utility method to extract freetext data (if spanning across multiples pages also)
def extract_freetext_data(words_df, pdf, config_data, afterstr_indx, beforestr_indx, is_beforerefstring_present,
                          header_footer_dict, beforestr_matching_index, afterstr_matching_index, garbage_val, REQ_FOLDER,
                          form_config_params, config):

    pagewise_annot_list_freetext = []
    data = []
    plumber_annot = convert_UI_coord_to_plumber(config_data['annotcoords'])
    plumber_afterref = convert_UI_coord_to_plumber(config_data['afterrefcoords'].split("||")[afterstr_matching_index])

    plumber_beforeref = convert_UI_coord_to_plumber(
        config_data['beforerefcoords'].split("||")[beforestr_matching_index])

    afterstr_dict = words_df.iloc[afterstr_indx].to_dict()
    beforestr_dict = words_df.iloc[beforestr_indx].to_dict()
    start_page = afterstr_dict['pageno']
    end_page = beforestr_dict['pageno']
    bbox_left = afterstr_dict['left'] + 0.5
    bbox_right = plumber_annot['right']

    if is_beforerefstring_present:
        for page_no in range(start_page, end_page + 1):
            header_footer_flg = True
            if start_page == end_page:
                header_footer_flg = False
                isextendedannot = False
                if "__extended" in config_data["name"]:
                    isextendedannot = True
                bbox_dict = get_calc_coord(plumber_afterref, plumber_beforeref, plumber_annot, afterstr_dict,
                                           beforestr_dict, isextendedannot)
                bbox_left = bbox_dict['left']
                bbox_right = bbox_dict['right']
                bbox_top = bbox_dict['top']
                bbox_bottom = bbox_dict['bottom']

            elif page_no == start_page and start_page != end_page:
                bbox_top = afterstr_dict['top']

                btm_found = False
                if page_no in header_footer_dict.keys():
                    if header_footer_dict[page_no]["footer_index_list"]:
                        btm_found = True
                        bbox_bottom = words_df.iloc[header_footer_dict[page_no]["footer_index_list"][0]]['top'] - 0.5
                if not btm_found:
                    bbox_bottom = float(words_df[words_df['pageno'] == page_no].iloc[-1]['bottom'])
                # bottom : last row of a page

            elif page_no > start_page and page_no < end_page:
                top_found = False
                if page_no in header_footer_dict.keys():
                    if header_footer_dict[page_no]["header_index_list"]:
                        top_found = True
                        bbox_top = words_df.iloc[header_footer_dict[page_no]["header_index_list"][-1]]['bottom'] + 0.5
                if not top_found:
                    bbox_top = float(
                        words_df[words_df['pageno'] == page_no].iloc[0]['top'])  # top : first row of a page

                btm_found = False
                if page_no in header_footer_dict.keys():
                    if header_footer_dict[page_no]["footer_index_list"]:
                        bbox_bottom = words_df.iloc[header_footer_dict[page_no]["footer_index_list"][0]]['top'] - 0.5
                        btm_found = True
                if not btm_found:
                    bbox_bottom = float(words_df[words_df['pageno'] == page_no].iloc[-1]['bottom'])

            elif page_no > start_page and page_no == end_page:
                top_found = False
                if page_no in header_footer_dict.keys():
                    if header_footer_dict[page_no]["header_index_list"]:
                        top_found = True
                        bbox_top = words_df.iloc[header_footer_dict[page_no]["header_index_list"][-1]]['bottom'] + 0.5
                if not top_found:
                    bbox_top = float(words_df[words_df['pageno'] == page_no].iloc[0]['top'])

                bbox_bottom = beforestr_dict['top'] + 0.5

            bbox = (bbox_left, bbox_top, bbox_right, bbox_bottom)
            cropped_section = pdf.pages[page_no].crop(bbox)
            page_df = words_df[words_df['pageno'] == page_no]

            if form_config_params["multithread"] in TRUE_CHECK:
                pagewise_annot_list_freetext.append([config_data["annotid"], 'freetext', config_data, page_df.to_dict(), 100, int(page_no),
                     int(page_no), bbox, path.join(REQ_FOLDER, "form.pdf"), garbage_val,
                     form_config_params, {"config": config}, {"is_beforerefstring_present": is_beforerefstring_present}, ""])

            else:
                extracted_data = ""
                if garbage_val:
                    crp_text = cropped_section.extract_text()
                    if crp_text:
                        extracted_data = re.sub(garbage_val, "", crp_text)
                else:
                    extracted_data = cropped_section.extract_text()
                if extracted_data:
                    extracted_data = extracted_data.split("\n")
                    data.extend(extracted_data)
    else:
        bbox_top = afterstr_dict['top']
        last_word_bottom = float(words_df[words_df['pageno'] == start_page].iloc[-1]['bottom']) + 0.5
        bbox = (bbox_left, bbox_top, bbox_right, last_word_bottom)

        if form_config_params["multithread"] in TRUE_CHECK:
            page_df = words_df[words_df['pageno'] == start_page]
            pagewise_annot_list_freetext.append([config_data["annotid"], 'freetext', config_data, page_df.to_dict(), 100, int(start_page), int(start_page), bbox,
                   path.join(REQ_FOLDER, "form.pdf"), garbage_val, form_config_params, {"config": config},
                   {"is_beforerefstring_present": is_beforerefstring_present}, ""])
        else:
            cropped_section = pdf.pages[start_page].crop(bbox)
            if garbage_val:
                extracted_data = re.sub(garbage_val, "", cropped_section.extract_text())
            else:
                extracted_data = cropped_section.extract_text()
            if extracted_data:
                extracted_data = extracted_data.split("\n")
                data.extend(extracted_data)

    if form_config_params["multithread"] in TRUE_CHECK:
        data = pagewise_annot_list_freetext
    return data


# extraction of freetext annotation data
def get_freetext_data(config_data, pdf, words_df, header_footer_dict, garbage_val, REQ_FOLDER, form_config_params, config):
    section_raw_text = []
    if config_data['annotationtype'] != "virtual":
        is_beforerefstring_present = False
        afterstr_indx, afterstr_matching_index, afterstr_matched = find_index(words_df, config_data['afterrefcoords'],
                                                                              config_data['afterrefstr'], 0, "after",
                                                                              header_footer_dict)
        if afterstr_indx:
            beforestr_indx, beforestr_matching_index, beforestr_matched = find_index(words_df,
                                                                                     config_data['beforerefcoords'],
                                                                                     config_data['beforerefstr'],
                                                                                     afterstr_indx, "before",
                                                                                     header_footer_dict)
            if beforestr_indx:
                is_beforerefstring_present = True
            try:
                section_raw_text = extract_freetext_data(words_df, pdf, config_data, afterstr_indx, beforestr_indx,
                                                         is_beforerefstring_present, header_footer_dict,
                                                         beforestr_matching_index, afterstr_matching_index, garbage_val,
                                                         REQ_FOLDER, form_config_params, config)
            except:
                pass

    return section_raw_text


def ignoring_bounding_pixels(img, form_config_params):

    bw_thresh = form_config_params["checkbox"]["bw_thresh"]
    btm = int(img.shape[0] - form_config_params["checkbox"]["ignore_pixels_bottom"])
    top = int(form_config_params["checkbox"]["ignore_pixels_top"])
    right = int(img.shape[1] - form_config_params["checkbox"]["ignore_pixels_right"])
    left = int(form_config_params["checkbox"]["ignore_pixels_left"])
    img = img[top:btm, left:right]

    return img, bw_thresh


# utility method for giving a list of checboxes data using opencv
def cbox_in_table_column(img, checkboxType, form_config_params):

    if img is not None:
        img, bw_thresh = ignoring_bounding_pixels(img, form_config_params)
        ori_img = img.copy()

        img_bin = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, BLOCK_SIZE,
                                        THRESHOLD_CONSTANT)
        # Defining a kernel length
        kernel_length = int(img.shape[1] * 0.75)

        # A horizontal kernel of (kernel_length X 1), which will help to detect all the horizontal line from the image.
        hori_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_length, 1))

        horizontal_lines_img = cv2.dilate(img_bin, hori_kernel, iterations=6)
        img = cv2.add(img, horizontal_lines_img)
        cropping_pos = 0
        crp_pos = [0]
        checked_result = []
        h_line_indx = []
        index_temp = 0
        for row_num in range(0, img.shape[0]-3):
            if np.sum(255 - img[row_num, :]) > GARBAGE_PIXELS_THRESH:
                if row_num - index_temp > TABLE_CHECKBOX_ROW_LINE_SPLIT_THRESH:
                    h_line_indx.append(row_num)
                    index_temp = row_num
                    ori_img[row_num:row_num + 2, :] = 0
                    if cropping_pos < 4:
                        cropping_pos = cropping_pos + 3
                    cropped_cell_img = ori_img[cropping_pos:row_num - 1, 1:-1]
                    cropped_cell_img = cv2.resize(cropped_cell_img, None, fx=form_config_params["checkbox_scale_factor"]["CHECKBOX_X_SCALE_FACTOR"],
                                                  fy=form_config_params["checkbox_scale_factor"]["CHECKBOX_Y_SCALE_FACTOR"], interpolation=cv2.INTER_CUBIC)
                    result = checkbox_classifier(cropped_cell_img, "multiple_rectangular_checkbox", form_config_params)
                    if not result:
                        result = ["0"]
                    checked_result.append(result[0])
                    cropping_pos = row_num
                    crp_pos.append(cropping_pos)

    else:
        checked_result = []
    return checked_result


def get_checkbox_refstrings(config_data):
    checkbox_refstrings = {}
    for chref in config_data["chref"]:
        after_str = []
        before_str = []
        col_index = config_data["chref"].index(chref)
        for refstrings in chref["referencestring"]:
            after_str.append(refstrings["afterrefstring"])
            before_str.append(refstrings["beforerefstring"])
        checkbox_refstrings[col_index] = {"afterstr": after_str, "beforestr": before_str}

    return checkbox_refstrings


# utility method to extract the checkboxes status when all table columns has only checkboxes
def get_table_with_only_checkboxes(pdf, page_no, bbox, config_data, REQ_FOLDER, form_config_params, cropped_table_df):
    colsplit_top_padding = form_config_params["table_with_checkbox_parameters"].get("colsplit_top_padding", 0)
    colsplit_bottom_padding = form_config_params["table_with_checkbox_parameters"].get("colsplit_bottom_padding", 0)
    cbox_bottom_padding = form_config_params["table_with_checkbox_parameters"].get("cbox_bottom_padding", 0)
    cbox_x0_padding = form_config_params["table_with_checkbox_parameters"].get("cbox_x0_padding", 0)
    tablewithcheckbox_top_padding = form_config_params["table_with_checkbox_parameters"].get("tablewithcheckbox_top_padding", 0)
    tablewithcheckbox_bottom_padding = form_config_params["table_with_checkbox_parameters"].get("tablewithcheckbox_bottom_padding", 0)
    checkbox_refstrings = get_checkbox_refstrings(config_data)
    # checkboxType = config_data["imagetype"] # will be used in future
    bbox = list(bbox)
    bbox[1] = bbox[1]-tablewithcheckbox_top_padding
    bbox[3] = bbox[3]+tablewithcheckbox_bottom_padding
    cropped_table = pdf.pages[page_no].crop(bbox)
    cropped_table_df["x0"].apply(pd.to_numeric)
    cropped_table_df["top"].apply(pd.to_numeric)
    cropped_table_df["bottom"].apply(pd.to_numeric)
    cropped_table_df["x1"].apply(pd.to_numeric)
    checkbox_status_alL_columns = []
    for col_split_pos in config_data["matrix_coords"]:
        checkbox_status_single_column = []
        pos = col_split_pos.split(",")
        left = float(pos[0]) * (72 / 500)
        right = left + float(pos[2]) * (72 / 500)
        col_bbox = [left, float(cropped_table_df.iloc[0]["top"])-colsplit_top_padding, right, float(cropped_table_df.iloc[-1]["bottom"])+colsplit_bottom_padding]
        cropped_column_cell = cropped_table.crop(col_bbox)
        data_df = pd.DataFrame(cropped_column_cell.extract_words())
        if len(data_df) > 0:
            data_df["x0"].apply(pd.to_numeric).astype(float)
            data_df["top"].apply(pd.to_numeric).astype(float)
            data_df["bottom"].apply(pd.to_numeric).astype(float)
            data_df["x1"].apply(pd.to_numeric).astype(float)
            data_df["pageno"] = np.zeros(len(data_df))
            data_df["pageno"] = data_df["pageno"].astype(int)

            col_index = config_data["matrix_coords"].index(col_split_pos)
            afterstr_list = checkbox_refstrings[col_index]["afterstr"]  # will be used in future
            beforestr_list = checkbox_refstrings[col_index]["beforestr"]

            if len(beforestr_list) > 0:
                df_start_index = 0
                for beforestr in beforestr_list:
                    refstr_index = get_key_row_position(data_df, beforestr, "", df_start_index)
                    if df_start_index not in [None, ""] and refstr_index not in [None, ""]:
                        cbox_region_bbox = [left, float(data_df.iloc[refstr_index]['top']) , float(data_df.iloc[refstr_index]['x0']) - cbox_x0_padding, float(data_df.iloc[refstr_index]['bottom']) + cbox_bottom_padding]
                        cbox_region = cropped_column_cell.crop(cbox_region_bbox)
                        cbox_region = cv2.cvtColor(np.array(cbox_region.to_image().original), cv2.COLOR_BGR2GRAY)
                        cbox_region = cv2.resize(cbox_region, None, fx=form_config_params["checkbox_scale_factor"]["CHECKBOX_X_SCALE_FACTOR"],
                                                 fy=form_config_params["checkbox_scale_factor"]["CHECKBOX_Y_SCALE_FACTOR"], interpolation=cv2.INTER_CUBIC)
                        cbox_status = checkbox_classifier(cbox_region, "multiple_rectangular_checkbox", form_config_params)
                        if cbox_status in [[], None]:
                            cbox_status = ["0"]
                        checkbox_status_single_column.append(cbox_status[0])
                if checkbox_status_single_column:
                    checkbox_status_alL_columns.append(checkbox_status_single_column)

    return checkbox_status_alL_columns


# utility method to extract the table column checkboxes
def get_column_checkboxes(pdf, words_df, config_data, table_data, plumber_matrix_coords, tablestartstr_dict,
                          tableendstr_dict, REQ_FOLDER, header_footer_dict, form_config_params):

    checkboxType = "rectangle_checkbox"
    start_page = tablestartstr_dict['pageno']
    end_page = tableendstr_dict['pageno']

    for col_index, col_type in enumerate(config_data["coltypes"].split("||")):
        if col_type.lower() == "image":
            column_cb_op = []
            colheader = plumber_matrix_coords[col_index]
            bbox_left = colheader['left']
            bbox_right = colheader['right']
            for page_no in range(start_page, end_page + 1):
                if start_page == end_page:
                    top = tablestartstr_dict["bottom"]
                    if config_data["tableheader"] not in [None, "", 0.0]:
                        search_word = config_data["colnames"].split("|")[0]
                        top_index = get_key_row_position(words_df[words_df["pageno"] == page_no], search_word, "", 0)
                        if top_index not in NULL_CHECK:
                            top = words_df.iloc[top_index]["bottom"]
                    col_bbox = (bbox_left, top, bbox_right, tableendstr_dict["top"])

                elif page_no == start_page and start_page != end_page:
                    col_bbox = calculate_start_page_bbox(config_data, tablestartstr_dict, words_df, page_no, header_footer_dict,
                                              bbox_right)

                elif page_no > start_page and page_no < end_page:
                    col_bbox = calculate_middle_pages_bbox(words_df, page_no, config_data, header_footer_dict, bbox_right)

                elif page_no > start_page and page_no == end_page:
                    col_bbox, top_index = calculate_last_page_bbox(words_df, page_no, config_data, bbox_right, tableendstr_dict, header_footer_dict)

                col_bbox = (bbox_left, col_bbox[1], bbox_right+0.5, col_bbox[3])
                col_cbox_img = np.array(pdf.pages[page_no].crop(col_bbox).to_image().original)
                cbox_img = cv2.cvtColor(col_cbox_img, cv2.COLOR_BGR2GRAY)
                cbox_img = cv2.resize(cbox_img, None, fx=form_config_params["checkbox_scale_factor"]["CHECKBOX_X_SCALE_FACTOR"],
                                      fy=form_config_params["checkbox_scale_factor"]["CHECKBOX_Y_SCALE_FACTOR"],
                           interpolation=cv2.INTER_CUBIC)
                column_cb_op.extend(cbox_in_table_column(cbox_img, checkboxType, form_config_params))

            if len(column_cb_op) < len(table_data):
                column_cb_op.extend(["0"] * (len(table_data) - len(column_cb_op)))
            for row_index, row in enumerate(table_data):
                table_data[row_index][col_index] = column_cb_op[row_index]

    return table_data


# crop the tabular region and set the properties of the extract_tables() of pdfplumber
def crop_and_extract(pdf, page_no, bbox, config_data, plumber_matrix_coords):
    try:
        cropped_region = pdf.pages[page_no].crop((bbox))
        extraction_settings = {}
        if config_data['colsep'].lower() == "position" and plumber_matrix_coords:
            logger.info("virtually handling table : %s", config_data['name'])
            colsep_positions = []
            for matcoord in plumber_matrix_coords:
                colsep_positions.append(int(matcoord['left']))
                if matcoord == plumber_matrix_coords[-1]:
                    colsep_positions.append(int(matcoord['right']))
            extraction_settings = {"vertical_strategy": "explicit", "explicit_vertical_lines": colsep_positions}
            if len(cropped_region.extract_tables(table_settings=extraction_settings)) == 0:
                if pdf.pages[page_no].curves:
                    extraction_settings["horizontal_strategy"] = "explicit"
                    extraction_settings["explicit_horizontal_lines"] = colsep_positions

        data = cropped_region.extract_tables(table_settings=extraction_settings)
    except:
        data = [[[]]]
    return data


# extracting data from virtual tables
def virtual_table(cropped_table, colsep_positions, config_data, header_footer_dict, page_no, words_df, bbox, page_type,
                  tableendstr_dict, form_config_params):

    merge_cell = False
    data_df = pd.DataFrame(cropped_table.extract_words(x_tolerance=CONFIG_JSON["plumber_tolerance"]["PLUMBER_X_TOLERANCE"]))
    if len(data_df) > 0:
        data_df["x0"].apply(pd.to_numeric)
        data_df["top"].apply(pd.to_numeric)
        data_df["bottom"].apply(pd.to_numeric)
        data_df["x1"].apply(pd.to_numeric)
        data_df = data_df[data_df["top"] > bbox[1]]

        space_between_rows = form_config_params["MIN_ROW_PIXELS_DIFF"]
        row_pixels_diff = None
        if config_data["spacebetweenrows"]:
            row_pixels_diff = float(config_data["spacebetweenrows"].split(",")[-1].strip()) * (72 / 500)
        if row_pixels_diff not in NULL_CHECK:
            space_between_rows = row_pixels_diff
        if config_data["rowsep"].lower() == "position":
            rowsep_positions = get_row_sep_position(data_df, colsep_positions, space_between_rows)
        elif config_data["rowsep"].lower() == "regex":
            rowsep_positions, merge_cell = get_regex_based_row_sep_position(data_df, colsep_positions,
                                                                            config_data["rowdelimiter"],
                                                                            header_footer_dict, page_no, words_df,
                                                                            page_type, tableendstr_dict)

        rowsep_positions = list(set(rowsep_positions))
        extraction_settings = {"horizontal_strategy": "explicit", "explicit_horizontal_lines": rowsep_positions,
                               "vertical_strategy": "explicit", "explicit_vertical_lines": colsep_positions}

        if len(rowsep_positions) > 1:
            table_data = cropped_table.extract_tables(table_settings=extraction_settings)
        else:
            table_data = [[["" for indx in range(0, len(config_data["coltypes"].split("||")))]]]

    else:
        table_data = [[["" for indx in range(0, len(config_data["coltypes"].split("||")))]]]

    return table_data, merge_cell


def crop_and_extract_virtual(pdf, page_no, bbox, config_data, plumber_matrix_coords, header_footer_dict, words_df,
                             page_type, tableendstr_dict, form_config_params):
    cropped_region = pdf.pages[page_no].crop((bbox))
    colsep_positions = []
    for matcoord in plumber_matrix_coords:
        colsep_positions.append(int(matcoord['left']))
        if matcoord == plumber_matrix_coords[-1]:
            colsep_positions.append(int(matcoord['right']))
    data, merge_cell = virtual_table(cropped_region, colsep_positions, config_data, header_footer_dict, page_no,
                                     words_df, bbox, page_type, tableendstr_dict, form_config_params)
    return data, merge_cell


def get_position(data, row_pattern):
    row_pos = []
    for row_index in range(len(data["text"])):
        for indx in range(5):
            if row_index + indx < len(data["text"]):
                if len(row_pattern.findall(data.iloc[row_index + indx]["text"])) > 0:
                    row_pos.append(data.iloc[row_index]["top"] - 2)
                    break
    return row_pos


def get_row_sep_position(data, colsep_positions, MIN_ROW_PIXELS_DIFFERENCE):

    first_col_data = data[(data['x1'] < colsep_positions[1])]
    rowsep_positions = [Decimal(str(1))]  # default top row line

    for row_indx in range(len(first_col_data['top'])):
        if row_indx == 0:
            rowsep_positions.append(first_col_data.iloc[row_indx]['top'] - 2)
        elif row_indx > 0:
            if abs(first_col_data.iloc[row_indx - 1]['top'] - first_col_data.iloc[row_indx]['top']) > MIN_ROW_PIXELS_DIFFERENCE:
                rowsep_positions.append(Decimal(str(first_col_data.iloc[row_indx]['top'] - 2)))
    if len(data) > 0:
        rowsep_positions.append(data.iloc[-1]["bottom"] + Decimal(str(0.2)))

    return rowsep_positions


# identifying row separator position based on given regex pattern
def get_regex_based_row_sep_position(data, colsep_positions, row_regex, header_footer_dict, page_no, words_df,
                                     page_type, tableendstr_dict):
    merge_cell = False
    rowsep_positions = []
    first_col_data = data[(data['x1'] < colsep_positions[1])]
    row_patten_index = []
    if len(first_col_data) > 0:
        rowsep_positions = [data.iloc[0]["top"] - Decimal(str(0.01))]  # default top row line
        row_patten = re.compile(str(row_regex))
        for row_index in range(len(first_col_data)):
            for indx in range(MAX_ROW_SEP_WORDS):
                if row_index + indx <= len(first_col_data["text"]):
                    if len(row_patten.findall(" ".join(first_col_data.iloc[row_index:row_index + indx]["text"]))) > 0:
                        rowsep_positions.append(
                            Decimal(str(first_col_data.iloc[row_index]["top"] - Decimal(str(0.05)))))
                        if data.iloc[0]['x0'] < colsep_positions[1]:
                            row_patten_index.append(row_index)
                        break

        if page_type in ["first", "last", "middle"]:
            if header_footer_dict[page_no]["footer_index_list"]:
                indx = header_footer_dict[page_no]["footer_index_list"][0]
                rowsep_positions.append(Decimal(str(words_df.iloc[indx]['top'] - 0.3)))
            else:
                rowsep_positions.append(data.iloc[-1]["bottom"] + Decimal(str(3)))
        if page_type in ["last", "first/last"]:
            rowsep_positions.append(Decimal(str(tableendstr_dict["top"] - 0.3)))

        x0_diff = abs(data.iloc[0]['x0'] - colsep_positions[0])
        if page_type in ["middle", "last"] and x0_diff > MIN_X0_DIFF:
            if row_patten.findall(data.iloc[0]["text"]) == [] or ((len(row_patten.findall(data.iloc[0]["text"])) > 0)
                                                                  and data.iloc[0]['x0'] > colsep_positions[1]):
                merge_cell = True
    else:
        merge_cell = True
    if len(rowsep_positions) == 0:
        if len(data) > 0:
            rowsep_positions = [Decimal(str(1)), Decimal(str(data.iloc[0]["top"])) - Decimal("0.5"),
                                Decimal(str(data.iloc[-1]["bottom"])) + Decimal("0.5"),
                                Decimal(str(data.iloc[-1]["bottom"])) + Decimal("1")]
        # rowsep_positions = [Decimal(str(1)), Decimal(str(tableendstr_dict["bottom"]))]
    return rowsep_positions, merge_cell


# used to verify if the columns in the split tables match the column count mentioned in nestedtablemap
def verify_column_dimensions(table, columns):
    if len(table) == 0:
        return False
    else:
        for row in table:
            if len(row) != columns:
                return False
    return True


# used to verify if the rows in the split tables match the row count mentioned in nestedtablemap
def verify_row_dimensions(table, rows):
    if rows not in NULL_CHECK:
        if len(table) != rows:
            return False
    return True


# accepts and rejects rows on the basis of available conditions and scenarios
def process_table_data(given_map, table_data):
    curr_map_index = 0
    curr_group = []
    modified_table_data = []
    matched_regex = []
    for index, table in enumerate(table_data):
        curr_map_index = curr_map_index % len(given_map)
        if curr_map_index == 0:
            matched_regex = []
        matched_regex.append(table[0][0])
        # row correction
        if not verify_row_dimensions(table, given_map[curr_map_index][1]):
            temp_table = []
            curr_row_index = 0
            while not verify_row_dimensions(temp_table, given_map[curr_map_index][1]):
                curr_row = table[curr_row_index]
                # condition to combine rows in case if page break is found in terms of previous regex element
                if curr_row[0] in matched_regex[:-1]:
                    prev_row = temp_table.pop()
                    next_row = table[curr_row_index + 1]
                    temp_row = [ele1 + ele2 for ele1, ele2 in zip(prev_row, next_row)]
                    temp_table.append(temp_row)
                    curr_row_index += 2
                else:
                    temp_table.append(curr_row)
                    curr_row_index += 1
            table = deepcopy(temp_table)
        # column correction
        if not verify_column_dimensions(table, given_map[curr_map_index][2]):
            temp_table = []
            while not verify_column_dimensions(temp_table, given_map[curr_map_index][2]):
                # loop to drop rows with non-matching columns
                for curr_row in table:
                    if len(curr_row) == given_map[curr_map_index][2]:
                        temp_table.append(curr_row)
            table = deepcopy(temp_table)
        curr_group.append(table)
        curr_map_index += 1
        if len(curr_group) == len(given_map):
            modified_table_data.append(curr_group)
            curr_group = []
    return modified_table_data


# splits inner table on the basis of given nestedtablemap
def split_table_data(given_map, table_data):
    curr_map_index = 0
    modified_table_data = []
    curr_table = []
    matched_regex = []
    while table_data:
        curr_row = table_data.pop(0)
        curr_map_index = curr_map_index % len(given_map)
        if re.search(given_map[curr_map_index][0], curr_row[0]) and curr_row[0] not in matched_regex:
            if curr_table:
                modified_table_data.append(curr_table)
                matched_regex.append(curr_table[0][0])
            curr_table = []
            if curr_map_index == 0:
                matched_regex = []
            curr_map_index += 1
        curr_table.append(curr_row)
        if len(table_data) == 0:
            modified_table_data.append(curr_table)
    return modified_table_data


def get_footer_adapted_bbox(top_index, top, words_df, header_footer_dict, page_no, bbox_right):
    btm = words_df[words_df['pageno'] == page_no].iloc[-1]['bottom'] + 0.5
    if top_index not in NULL_CHECK:
        top = words_df.iloc[top_index]["bottom"]+0.2
    if page_no in header_footer_dict.keys():
        if header_footer_dict[page_no]["footer_index_list"] not in [None, "", []]:
            btm_index = header_footer_dict[page_no]["footer_index_list"][0]
            btm = words_df.iloc[btm_index]["top"]-0.2

    bbox = (0, top, bbox_right, btm)
    return bbox


def get_top_pos(words_df, page_no, header_footer_dict, top):
    if page_no in header_footer_dict.keys():
        if header_footer_dict[page_no]["header_index_list"] not in [None, "", []]:
            top_index = header_footer_dict[page_no]["header_index_list"][-1]
            top = words_df.iloc[top_index]['bottom']+0.2
    return top


def get_bottom_pos(words_df, page_no, header_footer_dict):
    btm = words_df[words_df['pageno'] == page_no].iloc[-1]['bottom'] + 0.5
    if page_no in header_footer_dict.keys():
        if header_footer_dict[page_no]["footer_index_list"] not in [None, "", []]:
            btm_index = header_footer_dict[page_no]["footer_index_list"][0]
            btm = words_df.iloc[btm_index]['top']-0.5
    return btm


# compute bbox for continuation pages excluding last page
def calculate_middle_pages_bbox(words_df, page_no, config_data, header_footer_dict, bbox_right):
    top = words_df[words_df["pageno"] == page_no].iloc[0]["top"]+0.2
    top_initial = copy.deepcopy(top)
    if config_data["repeatingtableheader"] in [1, 1.0, True]:
        search_word = config_data["colnames"].split("|")[0].split(" ")[0]
        top_index = get_key_row_position(words_df[words_df["pageno"] == page_no], search_word, "", 0)
        bbox = get_footer_adapted_bbox(top_index, top, words_df, header_footer_dict, page_no, bbox_right)
    elif config_data["repeatingsectionheader"] in [1, 1.0, True]:
        top_index = get_key_row_position(words_df[words_df["pageno"] == page_no],
                                         config_data["tablestartstr"].split("||")[-1], "", 0)
        bbox = get_footer_adapted_bbox(top_index, top, words_df, header_footer_dict, page_no, bbox_right)
    else:
        btm = get_bottom_pos(words_df, page_no, header_footer_dict)
        top = get_top_pos(words_df, page_no, header_footer_dict, top)
        bbox = (0, top, bbox_right, btm)
    if bbox[1] > bbox[3]:
        # it will be used in case repeating header is not found
        bbox = (bbox[0], top_initial, bbox[2], bbox[3])
    return bbox


# calculating bbox when table start and end strings are present in same page
def calculate_bbox_same_page_refstrings(tablestartstr_dict, tableendstr_dict, bbox_right, config_data, words_df, page_no):
    top = tablestartstr_dict['bottom']
    if config_data['name'].endswith('__top_pos'):
        top = tablestartstr_dict['top']-0.5
    bbox = (0, top, bbox_right, tableendstr_dict["top"]-0.5)
    if config_data["tableheader"] not in [None, "", 0.0]:
        search_word = config_data["colnames"].split("|")[0]
        top_index = get_key_row_position(words_df[words_df["pageno"] == page_no], search_word, "", 0)
        header_top = words_df.iloc[top_index]["bottom"]
        bbox = (bbox[0], header_top, bbox[2], bbox[3])
    if config_data["tableheaderheight"] not in [None, "", 0.0]:
        top = bbox[1] + float(config_data["tableheaderheight"].split(",")[-1]) * (72 / 500)
        bbox = [bbox[0], top, bbox[2], bbox[3]]
    if "__fixed" in config_data["name"].lower():
        height = float(config_data["annotcoords"].split(",")[3].strip()) * (72 / 500)
        bbox = [bbox[0], top, bbox[2], top + height]

    return bbox


# calculate bbox of table start page when table span across multiple pages
def calculate_start_page_bbox(config_data, tablestartstr_dict, words_df, page_no, header_footer_dict, bbox_right):
    top = tablestartstr_dict['bottom']
    if config_data['name'].endswith('__top_pos'):
        top = tablestartstr_dict['top']-0.5
    if config_data["tableheader"] not in [None, "", 0.0]:
        search_word = config_data["colnames"].split("|")[0]
        page_df = words_df[words_df["pageno"] == page_no]
        after_index_pos = list(page_df.index).index(tablestartstr_dict["start_string_index"])
        top_index = get_key_row_position(words_df[words_df["pageno"] == page_no], search_word, "", after_index_pos)
        if top_index not in [None, ""]:
            top = words_df.iloc[top_index]["bottom"]+0.2

    btm = get_bottom_pos(words_df, page_no, header_footer_dict)

    # this condition handles the scenario, when section header only present in start page and data are not present
    if tablestartstr_dict["start_string_index"] in header_footer_dict[page_no]["footer_index_list"]:
        top = words_df.iloc[-1]["top"] - 0.6
        btm = top + 0.2
    bbox = (0, top, bbox_right, btm)

    if config_data["tableheaderheight"] not in [None, "", 0.0]:
        top = bbox[1] + float(config_data["tableheaderheight"].split(",")[-1]) * (72 / 500)
        bbox = (bbox[0], top, bbox[2], bbox[3])

    return bbox


# compute bbox for table end page
def calculate_last_page_bbox(words_df, page_no, config_data, bbox_right, tableendstr_dict, header_footer_dict):
    top = words_df[words_df["pageno"] == page_no].iloc[0]["top"]  # default top position
    btm = tableendstr_dict["top"]-0.5
    top = get_top_pos(words_df, page_no, header_footer_dict, top)
    top_initial = copy.deepcopy(top)
    top_index = True
    if config_data["repeatingtableheader"] in [1, 1.0, True]:
        top_index = get_key_row_position(words_df[words_df["pageno"] == page_no], config_data["colnames"].split("|")[0], "", 0)
        if top_index not in NULL_CHECK:
            top = words_df.iloc[top_index]["bottom"]+0.2
    elif config_data["repeatingsectionheader"] in [1, 1.0, True]:
        top_index = get_key_row_position(words_df[words_df["pageno"] == page_no], config_data["tablestartstr"].split("||")[-1], "", 0)
        if top_index not in NULL_CHECK:
            top = words_df.iloc[top_index]["bottom"]+0.2
    if top > btm:
        top = top_initial
    if top > btm:
        top = btm - 0.5
    bbox = (0, top, bbox_right, btm)

    return bbox, top_index


def appending_virtual_table_data(table_data, data, merge_cell):
    if len(data) > 0:
        # cell merging happens here when a table cell data continue to next page
        if table_data and merge_cell:
            table_data[-1] = [table_data[-1][indx] + "\n" + data[0][0][indx] for indx in range(len(table_data[-1]))]
            table_data.extend(data[0][1:])
        else:
            table_data.extend(data[0])
    return table_data


def appending_tabledata(table_data, data, page_no, start_page, config_data):
    if data and page_no > start_page:
        if len(data[0]) < len(config_data["matrix_coords"]):
            if table_data:
                for col_index in range(0, len(table_data)):
                    table_data[col_index].extend(data[col_index])
            else:
                table_data.append(data)
        elif len(data[0]) == len(config_data["matrix_coords"]):
            table_data = data
    else:
        if data:
            table_data.extend(data)

    return table_data


def identify_tabletype_and_extractdata(config_data, pdf, page_no, bbox, REQ_FOLDER, form_config_params,
                                       table_data, start_page, plumber_matrix_coords,
                                       header_footer_dict, words_df, page_type, tableendstr_dict, tablestartstr_dict, page_config_json):
    # identify table type
    if config_data["borderedtable"] and "text" not in config_data["coltypes"].split("||") and "image" in \
            config_data["coltypes"].split("||"):

        cropped_table = pdf.pages[page_no].crop(bbox)
        cropped_table_df = pd.DataFrame(cropped_table.extract_words())
        if not cropped_table_df.empty:
            data = get_table_with_only_checkboxes(pdf, page_no, bbox, config_data, REQ_FOLDER, form_config_params,
                                                  cropped_table_df)
            table_data = appending_tabledata(table_data, data, page_no, start_page, config_data)

    elif config_data["borderedtable"] and "text" in config_data["coltypes"].split("||"):
        data = crop_and_extract(pdf, page_no, bbox, config_data, plumber_matrix_coords)
        if len(data) > 0:
            table_data.extend(data[0])
    elif config_data["virtualtable"] and config_data["colsep"].lower() == "position":
        data, merge_cell = crop_and_extract_virtual(pdf, page_no, bbox, config_data, plumber_matrix_coords,
                                                    header_footer_dict, words_df, page_type, tableendstr_dict,
                                                    form_config_params)
        table_data = appending_virtual_table_data(table_data, data, merge_cell)

    elif config_data["virtualtable"] and config_data["rowsep"] in ["Regex", "regex"] and config_data["colsep"] in [
        "Regex", "regex"]:

        left = float(config_data["annotcoords"].split(",")[0].strip()) * (72 / 500)
        right = left + float(config_data["annotcoords"].split(",")[2].strip()) * (72 / 500)
        bbox = [left, bbox[1] - 0.2, right, bbox[3] + 0.2]
        cropped_region = pdf.pages[page_no].crop((bbox))
        regex_text = cropped_region.extract_text(
            y_tolerance=form_config_params["plumber_tolerance"]["PLUMBER_Y_TOLERANCE"],
            x_tolerance=form_config_params["plumber_tolerance"]["PLUMBER_X_TOLERANCE"])
        data = []
        if regex_text:
            data = RegexBasedTableParser(regex_text, config_data)
        if len(data) > 0:
            table_data.extend(data)

    if config_data['startrow']:
        table_data = eliminate_header_rows_using_startrow(table_data, config_data)

    if config_data["coltypes"] and "image" in config_data["coltypes"].split("||") \
            and "text" in config_data["coltypes"].split("||") and plumber_matrix_coords:
        table_data = get_column_checkboxes(pdf, words_df, config_data, table_data, plumber_matrix_coords,
                                           tablestartstr_dict, tableendstr_dict, REQ_FOLDER, header_footer_dict,
                                           form_config_params)

    if config_data["nestedtablemap"] != "":
        nestedtablemap = config_data["nestedtablemap"]
        given_map = [each.split("__") for each in nestedtablemap.split("||")]
        given_map = [[int(each) if each.isdigit() else each for each in curr_map] for curr_map in given_map]
        table_data = [[each for each in row if each is not None] for row in table_data]
        table_data = split_table_data(given_map, table_data)
        table_data = process_table_data(given_map, table_data)
    table_data = garbage_removed_data(table_data, page_config_json)
    return table_data


# utility method to extract the data (if present on multiple pages also)
def extract_table_data(pdf, words_df, tablestartstr_dict, tableendstr_dict, plumber_annot, config_data, REQ_FOLDER,
                       header_footer_dict, page_config_json, form_config_params, pagewise_annot_list_table, config):

    start_page = tablestartstr_dict['pageno']
    end_page = tableendstr_dict['pageno']
    table_data = []
    plumber_matrix_coords = [convert_UI_coord_to_plumber(matcoord) for matcoord in config_data['matrix_coords'] if
                             len(matcoord.split(",")) == 4]

    for page_no in range(start_page, end_page + 1):
        bbox_right = min(pdf.pages[start_page].width, plumber_annot['right'])
        if start_page == end_page:
            page_type = "first/last"
            bbox = calculate_bbox_same_page_refstrings(tablestartstr_dict, tableendstr_dict, bbox_right, config_data, words_df, page_no)
        elif page_no == start_page and start_page != end_page:
            page_type = "first"
            bbox = calculate_start_page_bbox(config_data, tablestartstr_dict, words_df, page_no, header_footer_dict, bbox_right)
        elif page_no > start_page and page_no < end_page:
            page_type = "middle"
            bbox = calculate_middle_pages_bbox(words_df, page_no, config_data, header_footer_dict, bbox_right)
        elif page_no > start_page and page_no == end_page:
            page_type = "last"
            bbox, word_index = calculate_last_page_bbox(words_df, page_no, config_data, bbox_right, tableendstr_dict, header_footer_dict)
            if word_index in NULL_CHECK:
                break

        if form_config_params["multithread"] in TRUE_CHECK:
            page_df = words_df[words_df['pageno'] == page_no]
            pagewise_annot_list_table.append([config_data["annotid"], 'table', config_data, page_df.to_dict(), 100, page_no, page_no,
                   bbox, path.join(REQ_FOLDER, "form.pdf"), config_data.get('garbageremovalregex', ""),
                   form_config_params, {"config": config},
                   {"plumber_matrix_coords": plumber_matrix_coords, "page_type": page_type, "header_footer_dict":
                       header_footer_dict, "tablestartstr_dict": tablestartstr_dict, "tableendstr_dict": tableendstr_dict}, ""])

        else:
            table_data = identify_tabletype_and_extractdata(config_data, pdf, page_no, bbox, REQ_FOLDER, form_config_params,
                                               table_data, start_page, plumber_matrix_coords,
                                               header_footer_dict, words_df, page_type, tableendstr_dict,
                                               tablestartstr_dict, page_config_json)


    if form_config_params["multithread"] in TRUE_CHECK:
        table_data = pagewise_annot_list_table

    return table_data


# extraction of tabular annotations data
def get_tabular_data(config_data, words_df, pdf, page_config_json, REQ_FOLDER, header_footer_dict, form_config_params):
    table_data = []
    pagewise_annot_list_table = []
    if config_data['annotationtype'] != "virtual":
        plumber_annot = convert_UI_coord_to_plumber(config_data['annotcoords'])
        tablestartstr_indx, matching_index, matched = find_index(words_df, config_data['annotcoords'],
                                                                 config_data['tablestartstr'], 0, "after",
                                                                 header_footer_dict)
        if tablestartstr_indx not in NULL_CHECK:
            tablestartstr_dict = words_df.iloc[tablestartstr_indx].to_dict()
            tablestartstr_dict["start_string_index"] = tablestartstr_indx
            if config_data['tableendstr']:
                tableendstr_indx, matching_index, matched = find_index(words_df, config_data['annotcoords'],
                                                                       config_data['tableendstr'],
                                                                       tablestartstr_indx, "before", header_footer_dict)
                tableendstr_dict = words_df.iloc[tableendstr_indx].to_dict()
            else:
                tableendstr_dict = words_df.iloc[-1].to_dict()
                tableendstr_dict['top'] = tableendstr_dict['bottom'] + 5

            if config_data["repeatableannot"]:
                start_occurences = find_occcurences(words_df, config_data['tablestartstr'], config_data['tableendstr'])
                if start_occurences:
                    for occurence_indx, occurence in enumerate(start_occurences):
                        occurencestart_dict = words_df.iloc[occurence[0]].to_dict()
                        occurencestart_dict["start_string_index"] = occurence[0]
                        if occurence[0] != start_occurences[-1]:
                            occurenceend_dict = words_df.iloc[start_occurences[occurence_indx][1]].to_dict()
                        else:
                            occurenceend_dict = tableendstr_dict

                        occurence_table_data = extract_table_data(pdf, words_df, occurencestart_dict, occurenceend_dict,
                                                                  plumber_annot, config_data, REQ_FOLDER,
                                                                  header_footer_dict, page_config_json,
                                                                  form_config_params, pagewise_annot_list_table, config_data)

                        table_data.extend(occurence_table_data)

            else:
                table_data = extract_table_data(pdf, words_df, tablestartstr_dict, tableendstr_dict,
                                                plumber_annot, config_data, REQ_FOLDER, header_footer_dict,
                                                page_config_json, form_config_params, pagewise_annot_list_table, config_data)

    return table_data


# extraction of checkbox/image annotations data
def get_checkbox_data(config_data, words_df, pdf, page_config_json, REQ_FOLDER, header_footer_dict, form_config_params):
    PDFPLUMBER_TOIMAGE_RESOLUTION = form_config_params['checkbox_constants']['PLUMBER_TOIMAGE_RESOLUTION']
    checkbox_op = []
    pagewise_annot_list_checkbox = []
    plumber_annot = convert_UI_coord_to_plumber(config_data['annotcoords'])

    if config_data['annotationtype'] != "virtual":
        if config_data["repeatableannot"] in (False, "false"):
            afterstrindx, after_matching_index, matched = find_index(words_df, config_data['afterrefcoords'],
                                                                     config_data['afterrefstr'], 0, "after",
                                                                     header_footer_dict)

            if afterstrindx:
                afterstr_dict = words_df.iloc[afterstrindx].to_dict()
                beforestrindx, before_matching_index, matched = find_index(words_df, config_data['beforerefcoords'],
                                                                           config_data['beforerefstr'],
                                                                           afterstrindx, "before", header_footer_dict)
                beforestr_dict = words_df.iloc[beforestrindx].to_dict()
                plumber_afterref = convert_UI_coord_to_plumber(
                    config_data['afterrefcoords'].split("||")[after_matching_index])
                plumber_beforeref = convert_UI_coord_to_plumber(
                    config_data['beforerefcoords'].split("||")[before_matching_index])
                calc_annot = get_calc_coord(plumber_afterref, plumber_beforeref, plumber_annot,
                                            afterstr_dict, beforestr_dict, "")

                calc_annot_bottom = calc_annot['top'] + abs(plumber_annot['bottom'] - plumber_annot['top'])
                bbox = (calc_annot['left'] - 1, calc_annot['top'] - 1, calc_annot['right'], calc_annot_bottom + 0.5)
                page_no = afterstr_dict['pageno']
                if form_config_params["multithread"] in TRUE_CHECK:
                    pagewise_annot_list_checkbox.append([config_data["annotid"], 'image', config_data, words_df, 100,
                                page_no, page_no, bbox, path.join(REQ_FOLDER, "form.pdf"), "",
                                form_config_params, {"config": ""}, {"afterstr_dict": afterstr_dict, "beforestr_dict": beforestr_dict}, ""])
                else:
                    cbox_img = np.array(pdf.pages[afterstr_dict['pageno']].crop(bbox).to_image(resolution=PDFPLUMBER_TOIMAGE_RESOLUTION).original)
                    cbox_img = cv2.resize(cbox_img, None, fx=form_config_params["checkbox_scale_factor"]["CHECKBOX_X_SCALE_FACTOR"],
                                fy=form_config_params["checkbox_scale_factor"]["CHECKBOX_Y_SCALE_FACTOR"], interpolation=cv2.INTER_CUBIC)
                    checkbox_op = checkbox_classifier(cbox_img, "multiple_rectangular_checkbox", form_config_params)
                    if checkbox_op == []:
                        checkbox_op = ["0"]
        else:
            plumber_afterref = convert_UI_coord_to_plumber(config_data['afterrefcoords'].split("||")[0])
            plumber_beforeref = convert_UI_coord_to_plumber(config_data['beforerefcoords'].split("||")[0])
            afterref_occurences = find_occcurences(words_df, config_data['afterrefstr'].split("||")[0])
            beforeref_occurences = find_occcurences(words_df, config_data['beforerefstr'].split("||")[0])

            if len(afterref_occurences) > 0 and len(afterref_occurences) == len(beforeref_occurences):
                for occurence_indx in range(len(afterref_occurences)):
                    occurence_afterstr_dict = words_df.iloc[afterref_occurences[occurence_indx]].to_dict()
                    occurence_beforestr_dict = words_df.iloc[beforeref_occurences[occurence_indx]].to_dict()
                    calc_annot = get_calc_coord(plumber_afterref, plumber_beforeref, plumber_annot,
                                                occurence_afterstr_dict, occurence_beforestr_dict, "")
                    calc_annot_bottom = calc_annot['top'] + abs(plumber_annot['bottom'] - plumber_annot['top'])
                    bbox = (
                    calc_annot['left'] + 2, calc_annot['top'] - 2, calc_annot['right'] + 2, calc_annot_bottom + 2)

                    if form_config_params["multithread"] in TRUE_CHECK:
                        page_no = occurence_afterstr_dict['pageno']
                        pagewise_annot_list_checkbox.append([config_data["annotid"], 'image', config_data,
                                                            words_df, 100, page_no, page_no, bbox, path.join(REQ_FOLDER, "form.pdf"), "",
                                                                form_config_params, {"config": ""}, {"afterstr_dict":
                                    occurence_afterstr_dict, "beforestr_dict": occurence_beforestr_dict}, ""])

                    else:
                        cbox_img = np.array(pdf.pages[occurence_afterstr_dict['pageno']].crop(bbox).to_image().original)
                        cbox_img = cv2.resize(cbox_img, None, fx=form_config_params["checkbox_scale_factor"]["CHECKBOX_X_SCALE_FACTOR"],
                                 fy=form_config_params["checkbox_scale_factor"]["CHECKBOX_Y_SCALE_FACTOR"],
                                              interpolation=cv2.INTER_CUBIC)
                        occurence_checkbox_op = checkbox_classifier(cbox_img, "multiple_rectangular_checkbox",
                                                                    form_config_params)
                        if occurence_checkbox_op in ["", None, []]:
                            occurence_checkbox_op = 0
                        checkbox_op.append(occurence_checkbox_op)

    if form_config_params["multithread"] in TRUE_CHECK:
        checkbox_op = pagewise_annot_list_checkbox
    return checkbox_op


# main method called from ws1 for creation of extracted data json for digitalpdf
def get_digitalpdf_data(pdf_file, REQ_FOLDER, page_config_json, config, form_config_params):
    tt1 = time.time()
    words_df, pdf = get_dataframe(pdf_file, form_config_params)
    print("words df exe time = ", time.time()-tt1)
    garbage_regex = page_config_json.get("garbageremovalregex", "")
    if garbage_regex not in ['', None]:
        for row_index in range(len(words_df['text'])):
            words_df['text'][row_index] = re.sub(garbage_regex, '', words_df['text'][row_index])
            if words_df['text'][row_index] in ['', None]:
                words_df = words_df.drop(row_index)

    words_df.reset_index(drop=True, inplace=True)
    words_df['text'] = words_df['text'].str.strip()
    words_df = words_df.rename(columns={'x0': 'left', 'x1': 'right'}, index={'ONE': 'one'})
    words_df['left'] = pd.to_numeric(words_df['left'], downcast="float")
    words_df['right'] = pd.to_numeric(words_df['right'], downcast="float")
    words_df['top'] = pd.to_numeric(words_df['top'], downcast="float")
    words_df['bottom'] = pd.to_numeric(words_df['bottom'], downcast="float")
    words_df['pageno'] = pd.to_numeric(words_df['pageno'], downcast="integer")
    words_df.to_csv(REQ_FOLDER+"/sdata.csv")
    header_footer_dict, header_footer_index_all = get_header_footer_position(words_df, page_config_json)
    tt2 = time.time()
    extracted_data_json = []
    extracted_data = ""
    for indx in range(len(config)):
        config_data = config.iloc[indx]
        json_data = {}
        json_data["AnnotID"] = config_data['annotid']
        json_data["class"] = config_data['name']
        if config_data['datastringtype'] == "freetext":
            extracted_data = get_freetext_data(config_data, pdf, words_df, header_footer_dict,
                           page_config_json.get('garbageremovalregex', ""), REQ_FOLDER, form_config_params, config)
        elif config_data['datastringtype'] == "image":
            extracted_data = get_checkbox_data(config_data, words_df, pdf, page_config_json, REQ_FOLDER,
                                               header_footer_dict, form_config_params)
        elif config_data['datastringtype'] == "keyvaluepairs":
            extracted_data = get_keyvalue_data(config_data, words_df, pdf, page_config_json, header_footer_dict)
        elif config_data['datastringtype'] == "table":
            extracted_data = get_tabular_data(config_data, words_df, pdf, page_config_json, REQ_FOLDER,
                                              header_footer_dict, form_config_params)
        elif config_data['datastringtype'] == "delimited":
            extracted_data = get_delimited_data(config_data, words_df, pdf, page_config_json, header_footer_dict)
        json_data["value"] = extracted_data
        extracted_data_json.append(json_data)
    print("annotationwise time = ", time.time()-tt2)
    return extracted_data_json


'''
words_df = pd.read_csv("/home/akshatha/Desktop/test.csv", )
print(words_df)
word_string = "14. SUSPECT DRUG(S)"
coords = "385 , 2065 , 2733 , 160"
afterref_indx = 0
print(get_key_row_position(words_df, word_string, coords, afterref_indx))
'''

'''
lists_of_text = ['"|"Solicited - Post Mkt Surv"|"the', 'tion and was drinking alcohol.', 'hile. When he returned from vacation', 'twice nightly dose. Xywav was too', '23 Happy St"|"123-555-', 'REMS"', 'py St"|"123-555-', 'one"|"Consumer/Other Non-HCP"', '22nd AVE. N, NASHVILLE, TN', '|"physician"|"physician"', 'xy"', 'psy"', '20-Apr-2019"', 'Mar-2021"|"USA" |"sleep apnea"|"15-', 'aily"|"15-Mar-21"', 'ay"|"2010"', '0-Sep-2020"']
list_of_keys = "<AEHeaderInfo>|<PatientInfo>"
get_textlist(list_of_keys, lists_of_text)
'''

