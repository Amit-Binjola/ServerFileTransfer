#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug  8 11:58:53 2019

@author: aditya
"""
import time

import pandas as pd
from glob import glob
import json
from os import path
from common_utils import convert_pdf_to_png, get_mapping_type, reading_json, return_config
from populate_PVI_json import createFinalJson
from config import CONFIG_JSON, logger, TRUE_CHECK, FALSE_CHECK

form_config_params = {}
pd.options.mode.chained_assignment = None

# loading modules based on configuration set in the config file
########################################################################################################################
if CONFIG_JSON["supported-doctypes"]["digitalpdf"]:
    from digitalpdf_dataextraction import get_digitalpdf_data

if CONFIG_JSON["supported-doctypes"]["multithreaded_digitalpdf"]:
    from gfp_multithreading import get_multihread_digitalpdf

if CONFIG_JSON["supported-doctypes"]["imagepdf"]:
    from imagepdf_dataextraction import get_imagepdf_data

if CONFIG_JSON["supported-doctypes"]["docx"]:
    from docx_dataextraction import get_docx_data

if CONFIG_JSON["supported-doctypes"]["delimitedtext"]:
    from delimitedtext_dataextraction import get_delimited_textform_data
########################################################################################################################

def identifyPages(ocr_df, header_list, page_no):
    pagenum = -1
    df = ocr_df
    count = 0
    for identifiers in header_list:
        size = len(identifiers.split(" "))
        for index, row in df.iterrows():
            word = " ".join([df.word[x] for x in range(index, index + size) if index < len(df) - size])
            if word.lower() == identifiers.lower():
                print(word, identifiers)
                count += 1
                pagenum = row["page_no"]
                break
        if count == len(header_list):
            break
    return pagenum


# creating a dataframe from mapping data to store all the annotation related properties
def create_config_dataframe(mapping_data):
    config = pd.DataFrame()
    for group in mapping_data:
        for annotation in group["annotations"]:
            # freetext / keyvaluepairs / delimited / table / image
            datastringtype = get_mapping_type(annotation)
            annot = annotation["annotation"]
            datastring = annot["datastring"]
            keyval = datastring['keyvaluepairs']
            setofrows = datastring['setofrows']
            properties_dict = {
                "annotid": annot["annotid"], 'label': annot['annotid'], "annotcoords": annot['annotcoordinates'],
                "annotationtype": annot["annotationtype"], "afterrefcoords": annot['afterreferencecoordinates'],
                "beforerefcoords": annot['beforereferencecoordinates'], "afterrefstr": annot['afterreferencestring'],
                "beforerefstr": annot['beforereferencestring'], "textType": annot['annotationcontenttype'],
                "textLanguage": annot['annotationcontentlang'], "repeatableannot": annot["isrepeatableannot"],
                "matrix_coords": annot['matrixcoordinates'], "annotationmatrix": annot["annotationmatrix"],
                "pageno": annot['startpage'], "datastringtype": datastringtype, "imagetype": datastring["imagetype"],
                "name": datastring["name"], "colsep": setofrows['columnseparator'], "startrow": setofrows["startrow"],
                "tableheader": setofrows['tableheader'], "repeatingtableheader": setofrows['repeatingtableheader'],
                "tableheaderseparator": setofrows["tableheaderseparator"], "rowdelimiter": setofrows["rowdelimiter"],
                "columndelimiter": setofrows["columndelimiter"], "tableendstr": setofrows["tableendstring"],
                "tablestartstr": setofrows["tablestartstring"], "coltypes": setofrows['columntypes'],
                "borderedtable": setofrows["borderedtable"], "virtualtable": setofrows["virtualtable"], "nestedtablemap": setofrows.get("nestedtablemap", ""),
                "endrow": setofrows["endrow"], "rowsep": setofrows['rowseparator'], "transformtable": setofrows.get("transformtable", False),
                "rowtransformlength": setofrows.get("rowtransformlength", "1"), "celltransformlength": setofrows.get("celltransformlength", "1"),
                "colnames": setofrows['columnnames'], "formkeylist": keyval['formkeylist'],
                "extstartstr": keyval['extractionstartstring'], "extendstr": keyval['extractionendstring'],
                "keyvalseperator": keyval['keyvalueseperator'], "startpos": keyval['extractionstartposition'],
                "endpos": keyval['extractionendposition'], "recordseperator": keyval['recordseperator'],
                "tablereferenceid": annot.get("tablereferenceid", ""), "rowreferenceid": annot.get("rowreferenceid", None),
                "rowreferencelength": annot.get("rowreferencelength", "1"), "cellreferenceid": annot.get("cellreferenceid", None),
                "cellreferencelength": annot.get("cellreferencelength", "1"),
                "spacebetweenrows": setofrows.get("spacebetweenrows", ""),
                "tableheaderheight": setofrows.get("tableheaderregionsize", ""),
                "chref": setofrows.get("chref", ""), "repeatingsectionheader": setofrows.get("repeatingsectionheader", "")

            }

            if annot["annotationmatrix"] in TRUE_CHECK:
                for matrix_coord in annot['matrixcoordinates']:
                    if len(matrix_coord.split(",")) == 4:
                        properties_dict["annotcoords"] = matrix_coord
                        config = config.append(properties_dict, ignore_index=True)
            else:
                config = config.append(properties_dict, ignore_index=True)
    config["annotationmatrix"] = config["annotationmatrix"].astype(bool)
    config["transformtable"] = config["transformtable"].astype(bool)
    return config


# utlity method to save extracted_data_json to a fixed path
def save_extracted_data_json(req_folder, extracted_data_json):
    with open(path.join(req_folder, 'data.json'), "w") as outfile:
        try:
            outfile.write(json.dumps(extracted_data_json, indent=4))
        except:
            outfile.write(json.dumps(str(extracted_data_json), indent=4))


# starting method called from /api/getKeyValues call
def create_extracted_data_json(inputs):
    input_form_path = inputs["input_form_path"]
    req_folder = inputs["request_folder"]
    form_id = inputs["form_id"]
    doctype = inputs["doctype"]
    enhance_img = inputs["enhance_img"]
    mapping_data = inputs["form_config"]["configdefinition"]
    page_config_json = inputs["form_config"]["formsummary"]
    config = create_config_dataframe(mapping_data)

    global form_config_params
    form_config_params = return_config(form_id)

    if "docx" in doctype:
        docx_metadata_json = inputs["form_config"]["docxmetadata"]
        extracted_data_json = get_docx_data(input_form_path, docx_metadata_json, config)
    else:
        if doctype == "delimitedtext":
            extracted_data_json = get_delimited_textform_data(input_form_path, req_folder, page_config_json, config, form_config_params)
        elif doctype == "imagepdf":
            if convert_pdf_to_png(input_form_path, path.join(req_folder, "png/"), "form_png") == 0:
                png_filepaths = glob(path.join(req_folder, "png/*.png"))
                png_filepaths.sort()
            extracted_data_json = get_imagepdf_data(form_id, png_filepaths, page_config_json, config, req_folder, enhance_img, form_config_params)
        elif doctype == "digitalpdf" and form_config_params["multithread"] in FALSE_CHECK:
            ws1time = time.time()
            extracted_data_json = get_digitalpdf_data(input_form_path, req_folder, page_config_json, config, form_config_params)
            print("ws1 time =", time.time() - ws1time)
        elif (doctype == "multithreaded_digitalpdf" or doctype == "digitalpdf") and form_config_params["multithread"] in TRUE_CHECK:
            ws1time = time.time()
            extracted_data_json = get_multihread_digitalpdf(input_form_path, config, form_config_params,
                                                            page_config_json, req_folder)
            print("ws1 time =", time.time()-ws1time)
    #print("extracted_data_json = ", extracted_data_json)
    #logger.info(json.dumps(extracted_data_json, indent=2, sort_keys=True))
    ws2time = time.time()
    save_extracted_data_json(req_folder, extracted_data_json)
    print("ws2 time = ", time.time()-ws2time)

    pvi_json = createFinalJson(mapping_data, extracted_data_json, inputs["output_format"], form_id)

    return extracted_data_json, pvi_json

####################################### input paths for debugging #####################################################

# inputs = {}

# form_config = reading_json("/home/aditya/generic_poc/inputs/pdf/stdae/mapping-stdae-ui-reporter.json")
# file = "/home/aditya/generic_poc/inputs/pdf/stdae/SD 1.pdf"
# form_id = "b7569fac-b536-11ea-8070-12414bf81c8f"
# config = ""
# enhance_img = "false"
# docType = "digitalpdf"
# REQUEST_UPLOAD_FOLDER = "/home/aditya/backendservice/utility/uploads/temp1"
# outputformat = 'PVI_4.6'

# form_config = reading_json("/home/aditya/generic_poc/inputs/pdf/new_mnk/mapping-newmnk.json")
# file = "/home/aditya/generic_poc/inputs/pdf/new_mnk/new_forms/AE 2020-0037310 rec Friday, February 28, 2020.pdf"
# form_id = "b010f6f0-95da-11ea-b16d-12414bf81c8f"
# config = ""
# enhance_img = "false"
# docType = "digitalpdf"
# REQUEST_UPLOAD_FOLDER = "/home/aditya/backendservice/utility/uploads/temp1"
# outputformat = 'PVI_4.1'

# form_config = reading_json("/home/aditya/generic_poc/inputs/pdf/pfizer/mapping-pfizer.json")
# file = "/home/aditya/generic_poc/inputs/pdf/pfizer/example response_filled.pdf"
# form_id = "fefab75a-a3fa-11ea-9989-12414bf81c8f"
# config = ""
# enhance_img = "false"
# docType = "digitalpdf"
# REQUEST_UPLOAD_FOLDER = "/home/aditya/backendservice/utility/uploads/temp1"
# outputformat = 'PVI_4.6'

# form_config = reading_json("/home/aditya/generic_poc/inputs/pdf/MRP/mapping_MRP.json")
# file = "/home/aditya/generic_poc/inputs/pdf/MRP/3 - MRP.pdf"
# form_id = "ad14cfd8-a72a-11ea-ac70-12414bf81c8f"
# config = ""
# enhance_img = "false"
# docType = "digitalpdf"
# REQUEST_UPLOAD_FOLDER = "/home/aditya/backendservice/utility/uploads/temp1"
# outputformat = 'PVI_4.6'

# with open("/home/aditya/generic_poc/inputs/pdf/MRP/output.json", 'w') as outfile:
#     json.dump(pvi_json, outfile)
'''
form_config = reading_json("/home/suresh/Downloads/replimune_mapping.json")
file = "/home/suresh/backendservice/utility/uploads/Request-f3f97237-022d-4625-ad15-4b5ba5d73be5/form1.pdf"
form_id = "27f7d1a2-5ba1-11eb-97d3-12414bf81c8f"
config = ""
enhance_img = "false"
docType = "imagepdf"
REQUEST_UPLOAD_FOLDER = "/home/suresh/backendservice/utility/uploads/Request-f3f97237-022d-4625-ad15-4b5ba5d73be5"
outputformat = 'PVI_4.6'
'''

# form_config = reading_json("/home/aditya/generic_poc/inputs/pdf/NNI-release2/eml/nni_eml_ui.json")
# file = "/home/aditya/generic_poc/inputs/pdf/NNI-release2/eml/EML FORM 2.pdf"
# form_id = "b7569fac-b536-11ea-8070-12414bf81c8f"
# config = ""
# enhance_img = "false"
# docType = "digitalpdf"
# REQUEST_UPLOAD_FOLDER = "/home/aditya/backendservice/utility/uploads/temp1"
# outputformat = 'PVI_4.6'
#
'''
inputs = {}
inputs["input_form_path"] = file
inputs["request_folder"] = REQUEST_UPLOAD_FOLDER
inputs["form_id"] = form_id
inputs["doctype"] = docType
inputs["output_format"] = outputformat
inputs["form_config"] = form_config
pvi_json = json.loads(create_extracted_data_json(inputs))
'''
