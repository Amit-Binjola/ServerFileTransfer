import pdfplumber
import pandas as pd


# get the words dataframe from pdfplumber
def get_dataframe(pdf_file, form_config_params):
    pdf = pdfplumber.open(pdf_file)
    all_text_list = []
    for page_indx in range(len(pdf.pages)):
        page_text = pdf.pages[page_indx].extract_words(
            y_tolerance=form_config_params["plumber_tolerance"]["PLUMBER_Y_TOLERANCE"],
            x_tolerance=form_config_params["plumber_tolerance"]["PLUMBER_X_TOLERANCE"])
        for word_indx in range(len(page_text)):
            page_text[word_indx]["pageno"] = page_indx
        all_text_list.extend(page_text)
    data = pd.DataFrame(all_text_list)
    return data, pdf


def get_strike_off_data(pdf_file):
    strike_line_max_width_thresh = 75
    strike_line_min_width_thresh = 10
    bottom_thresh = 3
    strike_off_line_exist = False
    pageno = None
    form_config_params = {}
    form_config_params["plumber_tolerance"] = {"PLUMBER_X_TOLERANCE": 3, "PLUMBER_Y_TOLERANCE": 3}
    all_word_cords, pdf = get_dataframe(pdf_file, form_config_params)
    if len(all_word_cords) > 0:
        all_word_cords["text"] = all_word_cords["text"].astype(str)
        for pageno in range(0, len(pdf.pages)):
            line_ptn_coords = pdf.pages[pageno].lines
            if len(line_ptn_coords) > 0:
                line_ptn_coords_df = pd.DataFrame(line_ptn_coords)
                line_ptn_coords_df = line_ptn_coords_df[(line_ptn_coords_df["width"] < strike_line_max_width_thresh) \
                                                        & (line_ptn_coords_df["width"] > strike_line_min_width_thresh)]
                # filter words_df based on pageno
                pagewise_words_df = all_word_cords[all_word_cords["pageno"] == pageno]
                pagewise_words_df.reset_index(drop=True, inplace=True)
                # for every word in filtered words_df compare its coordinates with line's coordinates

                for word_indx in range(len(pagewise_words_df)):
                    word_data = pagewise_words_df.iloc[word_indx]
                    height = abs(word_data["bottom"] - word_data["top"]) / 3
                    line_ptn_coords_df_filtered = line_ptn_coords_df[ \
                        (line_ptn_coords_df["top"] > word_data["top"]) & \
                        (line_ptn_coords_df["top"] < word_data["top"] + height+bottom_thresh)]

                    if len(line_ptn_coords_df_filtered) > 0:
                        strike_off_line_exist = True
                        break
                if strike_off_line_exist:
                    break
            if strike_off_line_exist:
                break
    else:
        strike_off_line_exist = False
    if strike_off_line_exist is False:
        pageno = None

    return {"strikethrough_present": strike_off_line_exist, "pageno": pageno}

# pdf_file = "/home/suresh/Documents/Document1.pdf"
# pdf_file = "/home/suresh/Downloads/12.pdf"
# strike_off_line_exist, all_word_cords, word_indx, pagewise_words_df, pageno, line_ptn_coords_df_filtered = get_strike_off_data(pdf_file)
# print
