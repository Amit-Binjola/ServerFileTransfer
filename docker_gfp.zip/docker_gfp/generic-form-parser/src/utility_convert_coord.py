#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 14 15:14:28 2020

@author: aditya
"""
from config import TRUE_CHECK


# converts plumber coordinates back to the UI coordinates format , returns dict having UI coord
def convert_plumber_coord_to_UI(coordinates):
    left, right, top, bottom = float(coordinates['left']), float(coordinates['right']), float(
        coordinates['top']), float(coordinates['bottom'])
    UI_coord = {}
    conversion_factor = 500 / 72
    UI_coord['left'] = left * conversion_factor
    UI_coord['top'] = top * conversion_factor
    UI_coord['width'] = (right * conversion_factor) - UI_coord['left']
    UI_coord['height'] = (bottom * conversion_factor) - UI_coord['top']

    return UI_coord


# converts UI coordinates to the pdfplumber coordinates format , returns dict having pdfplumber format coord
def convert_UI_coord_to_plumber(coordinates):
    # left , y0, width,height = coordinates['left'] ,coordinates['y0'],coordinates['width'],coordinates['height']
    if type(coordinates) == str:
        left, top, width, height = coordinates.split(",")
    elif type(coordinates) == dict:
        left, top, width, height = coordinates['left'], coordinates['top'], coordinates['width'], coordinates['height']
    left, top, width, height = float(left), float(top), float(width), float(height)
    plumber_coord = {}
    conversion_factor = 72 / 500
    plumber_coord['left'] = left * conversion_factor
    plumber_coord['right'] = (left + width) * conversion_factor
    plumber_coord['top'] = top * conversion_factor
    plumber_coord['bottom'] = (top + height) * conversion_factor

    return plumber_coord


# utility method to calculate offsets between the given coordinates, returns dict having (left_offset,top_offset,width,bottom_offset)
def get_offsets(annotation_coord, afterref_dict, beforeref_dict):
    offsets = {}
    offsets['left_offset'] = annotation_coord['left'] - afterref_dict['left']
    offsets['top_offset'] = annotation_coord['top'] - afterref_dict['top']
    offsets['width'] = annotation_coord['right'] - annotation_coord['left']
    offsets['bottom_offset'] = beforeref_dict['top'] - annotation_coord['bottom']

    return offsets


# calculates the current annotation coordinates based on the offests between configured annotation coordinates and reference coordinates, returns dict having calculated pdfplumber coord
def get_calc_coord(afterrefcoord, beforerefcoord, annotcoord, calc_afterref_dict, calc_beforeref_dict, isextendedannot):
    calc_coord = {}
    offsets = get_offsets(annotcoord, afterrefcoord, beforerefcoord)
    calc_coord['left'] = calc_afterref_dict['left'] + offsets['left_offset']
    calc_coord['right'] = calc_coord['left'] + offsets['width']
    calc_coord['top'] = calc_afterref_dict['top'] + offsets['top_offset']
    if isextendedannot in TRUE_CHECK:
        calc_coord['bottom'] = calc_beforeref_dict["top"]
    else:
        calc_coord['bottom'] = calc_coord['top'] + abs(annotcoord['bottom'] - annotcoord['top'])

    return calc_coord


# calculates the current annotation coordinates based on the offests between configured annotation coordinates and reference coordinates, returns dict having calculated pdfplumber coord
def get_calc_coord_imagepdf(config_data, calc_afterref_dict, calc_beforeref_dict, afterstr_indx, beforestr_indx,
                            word_cords):
    calc_coord = {}
    annot_coords = config_data['annotcoords']
    afterstr_len = len(config_data['afterrefstr'].split(" "))

    left = word_cords.iloc[afterstr_indx]["left"]
    top = word_cords.iloc[afterstr_indx]["top"]
    width = abs(word_cords.iloc[afterstr_indx + afterstr_len]["right"] - left)
    height = abs(word_cords.iloc[afterstr_indx]["bottom"] - top)
    plumber_annot = convert_UI_coord_to_plumber(annot_coords)
    plumber_afterref = convert_UI_coord_to_plumber({"left": left, "top": top, "width": width, "height": height})

    beforestr_len = len(config_data['beforerefstr'].split(" "))
    left = word_cords.iloc[beforestr_indx]["left"]
    top = word_cords.iloc[beforestr_indx]["top"]
    try:
        width = abs(word_cords.iloc[beforestr_indx + beforestr_len]["right"] - left)
    except:
        width = abs(word_cords.iloc[beforestr_indx]["right"] - left)
    height = abs(word_cords.iloc[beforestr_indx]["bottom"] - top)
    plumber_beforeref = convert_UI_coord_to_plumber({"left": left, "top": top, "width": width, "height": height})
    plumber_calc_afterref_dict = convert_UI_coord_to_plumber(calc_afterref_dict)
    plumber_calc_beforeref_dict = convert_UI_coord_to_plumber(calc_beforeref_dict)
    offsets = get_offsets(plumber_annot, plumber_afterref, plumber_beforeref)

    calc_coord['left'] = plumber_calc_afterref_dict['left'] + offsets['left_offset']
    calc_coord['right'] = calc_coord['left'] + offsets['width']
    calc_coord['top'] = plumber_calc_afterref_dict['top'] + offsets['top_offset']
    calc_coord['bottom'] = calc_coord['top'] + abs(plumber_annot['bottom'] - plumber_annot['top'])
    bbox_dict = convert_plumber_coord_to_UI(calc_coord)

    return bbox_dict
