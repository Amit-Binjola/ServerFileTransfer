#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 12 10:35:37 2019

@author: aditya
"""
import sys, ast, json, re, datetime, copy
from os import path
from common_utils import get_mapping_type, reading_json
import virtualData
from utility_get_keyval import get_dict_from_list
from date_format import transform_date
from config import CUSTOMIZATION_FOLDER, REFERENCE_JSON_FOLDER, CONFIG_JSON, logger, TRUE_CHECK, NULL_CHECK

# loading address parser module based on configuration set in the config file
########################################################################################################################
if CONFIG_JSON["address-parser"]:
    from postal.parser import parse_address


########################################################################################################################


def handleVirtualTable(mapping_dict, annotation, elemental_string, all_annotations):
    multiple_elements = annotation["annotation"]["datastring"]["elements"]
    row_seperator = annotation["annotation"]["datastring"]["setofrows"]["rowseparator"]
    if row_seperator == 'solidline':
        row_seperator = '\n'
    datastrings = elemental_string.split(row_seperator)
    datastrings = [i for i in datastrings if i != '']
    parent_sequence = 0
    all_elements = multiple_elements
    for k in all_annotations:
        if k['annotation']['annotationtype'] == 'nested':
            all_elements = all_elements + k['annotation']['datastring']['elements']

    for datastring in datastrings:
        valdict = {}
        multiple_vals = virtualData.getMultipleElements(multiple_elements, datastring, all_annotations, valdict)
        if 'parentreferrence' in multiple_vals:
            parent_sequence = int(multiple_vals['parentreferrence']) - 1
        for element in all_elements:
            for splits, splits_val in multiple_vals.items():
                if splits == 'parentreferrence':
                    continue
                if element['elemententity'] + element['elementname'] == splits:
                    if type(splits_val) == list:
                        for i in splits_val:
                            mapping_dict = freeText_mapping(mapping_dict, element, i, parent_sequence)
                        break
                    mapping_dict = freeText_mapping(mapping_dict, element, splits_val, parent_sequence)

        parent_sequence = parent_sequence + 1
    return mapping_dict


def trim_group_values_using_group_operations(val_json, group_operations):
    for operation in group_operations:
        if operation["transformcase"] == "upper":
            val_json = val_json.upper()
        elif operation["transformcase"] == "lower":
            val_json = val_json.lower()
        if operation["transformdateformat"] != "none":
            val_json = datetime.strptime(val_json, operation["transformdateformat"])
            val_json = str(val_json)
    return val_json


def trim_annotation_values(value, datacleansing, datastring_name):
    val_json = {}
    if datacleansing['removeleadingstringmatching'] or datacleansing['removelaggingstringmatching']:
        if type(value) == list:
            for seg_indx, segment in enumerate(value):
                if type(segment) == list:
                    for element_indx, element_value in enumerate(segment):
                        element_value = str(element_value)
                        element_value = re.sub(datacleansing['removeleadingstringmatching'], '', element_value)
                        element_value = re.sub(datacleansing['removelaggingstringmatching'], '', element_value)
                        element_value = element_value.strip()
                        segment[element_indx] = element_value
                else:
                    segment = str(segment)
                    segment = re.sub(datacleansing['removeleadingstringmatching'], '', segment)
                    segment = re.sub(datacleansing['removelaggingstringmatching'], '', segment)
                    segment = segment.strip()
                    value[seg_indx] = segment
        elif type(value) == str:
            value = re.sub(datacleansing['removeleadingstringmatching'], '', value)
            value = re.sub(datacleansing['removelaggingstringmatching'], '', value)
            value = value.strip()
    val_json[datastring_name] = value
    return val_json


# Using regex to break element value based on first occurence of markerstring
def break_value_based_on_markerstring(element_value, markerstring):
    markerstring_regexp = re.compile(markerstring)
    occurences = [x.start() for x in re.finditer(markerstring_regexp, element_value)]
    if len(occurences) > 0:
        data_before_markerstring = element_value[0:occurences[0]]
        data_after_markerstring = element_value[occurences[0] + len(markerstring):]
        splitted_values_on_first_occur = [data_before_markerstring, data_after_markerstring]
    else:
        splitted_values_on_first_occur = [element_value]
    return splitted_values_on_first_occur


def trim_element_values(element, element_value):
    if element_value and type(element_value) == str:
        element_value = element_value.replace('\x00', '').replace('\u0000', '')

        if element["alwaysafter"]["aftermarkerstringflag"] in TRUE_CHECK:
            aftermarkerstring = element["alwaysafter"]["aftermarkerstring"]
            element_value = break_value_based_on_markerstring(element_value, aftermarkerstring)[-1]
            if element["alwaysafter"]["includemarkerflag"] in TRUE_CHECK:
                element_value = aftermarkerstring + " " + element_value

        if element["alwaysbefore"]["beforemarkerstringflag"] in TRUE_CHECK:
            beforemarkerstring = element["alwaysbefore"]["beforemarkerstring"]
            element_value = break_value_based_on_markerstring(element_value, beforemarkerstring)[0]
            if element["alwaysbefore"]["includemarkerflag"] in TRUE_CHECK:
                element_value = element_value + " " + beforemarkerstring

    return element_value


def get_all_virtual_annotations(annotations):
    virtual_annot_references = [element["virtualannotationreference"] for annotation in annotations
                                for element in annotation["annotation"]["datastring"]["elements"]
                                if element["elementtype"] == "virtual"]

    referred_annotations = [annotation for virtual_annotation in virtual_annot_references for annotation in annotations
                            if virtual_annotation == annotation["annotation"]["annotid"]]

    return referred_annotations


def get_annotationvalues_list(group_operations, annotations, key_val_json):
    annotation_list = []
    for keys in key_val_json:
        virtual_annotations = get_all_virtual_annotations(annotations)
        for annotation in annotations:
            if annotation["annotation"]["annotid"].lower() == keys["AnnotID"].lower():
                for virtual_annotation in virtual_annotations:
                    if annotation["annotation"]["annotid"] == virtual_annotation["annotation"]["annotid"]:
                        break
                value = keys["value"]
                datacleansing = annotation["annotation"]["datastring"]["datecleansing"]
                datastring_name = annotation["annotation"]["datastring"]["name"]
                val_json = trim_annotation_values(value, datacleansing, datastring_name)
                # val_json=trim_group_values_using_group_operations(val_json,group_operations)
                annotation_list.append(val_json)
    return annotation_list


def get_grandparent_entity(given_entity, current_index):
    grandparent_entity = None
    grand_parents = {}
    grand_parents["events.seriousnesses"] = "admin"
    grand_parents["productEventMatrix.relatednessAssessments.result"] = "productEventMatrix" + "." + str(current_index)

    # not completed yet , to be completed

    for entity, grandparent in grand_parents.items():
        if entity == given_entity:
            grandparent_entity = grandparent
            break
    if not grandparent_entity:
        grandparent_entity = given_entity

    return grandparent_entity


def get_parent_entity(given_entity, current_index):
    parent_entity = None
    parents = {}
    parents["events.seriousnesses"] = "events" + "." + str(current_index)
    parents["productEventMatrix.relatednessAssessments.result"] = "relatednessAssessments" + "." + str(current_index)

    # not completed yet , to be completed
    for entity, parent in parents.items():
        if entity == given_entity:
            parent_entity = parent
            break
    if not parent_entity:
        parent_entity = given_entity

    return parent_entity


def prepend_append_string(mapped_value, matchesvaluemap):
    if matchesvaluemap["prependstring"] not in NULL_CHECK:
        matchesvaluemap["prependstring"] = matchesvaluemap["prependstring"].replace("\\n", "\n")
        mapped_value = matchesvaluemap["prependstring"] + " " + mapped_value

    if matchesvaluemap["appendstring"] not in NULL_CHECK:
        matchesvaluemap["appendstring"] = matchesvaluemap["appendstring"].replace("\\n", "\n")
        mapped_value = mapped_value + " " + matchesvaluemap["appendstring"]

    return mapped_value


def handling_none_value_map(value, matchesvaluemap):
    final_value = value
    values_to_map = matchesvaluemap["simplevaluemap"].split("|")
    for val_map in values_to_map:
        if val_map.split("__")[0] in [None, "", " "]:
            final_value = val_map.split("__")[1]
            break
    return final_value

# used to map the value to their corresponding value being taken from simple value map if the value matches correctly
def simple_value_mapping(value, matchesvaluemap):
    final_value = copy.deepcopy(value)
    value_matched = False
    nomatchdefault = matchesvaluemap["nomatchdefault"]
    if value and matchesvaluemap["outputdateformat"]:
        final_value = transform_date(value, matchesvaluemap)
    elif value and matchesvaluemap["ismapped"] and matchesvaluemap["simplevaluemap"]:
        values_to_map = matchesvaluemap["simplevaluemap"].split("|")
        for mapping_value in values_to_map:
            value_to_match = mapping_value.split("__")[0]
            value_to_map = mapping_value.split("__")[-1]
            if matchesvaluemap["matchingtype"].lower() == "exact match" or value_to_match in (None, ""):
                regex_pattern = "^" + value_to_match + "$"
                value_to_match_regex = re.compile(regex_pattern)
            elif matchesvaluemap["matchingtype"].lower() in ("contains", ""):
                regex_pattern = value_to_match
                value_to_match_regex = re.compile(regex_pattern)
            elif matchesvaluemap["matchingtype"].lower() == "starts with":
                regex_pattern = "^" + value_to_match
                value_to_match_regex = re.compile(regex_pattern)
            elif matchesvaluemap["matchingtype"].lower() == "ends with":
                regex_pattern = value_to_match + "^"
                value_to_match_regex = re.compile(regex_pattern)
            if bool(re.search(value_to_match_regex, value)):
                value_matched = True
                break
        if value_matched:
            final_value = value_to_map
        else:
            if nomatchdefault not in NULL_CHECK:
                final_value = nomatchdefault
    elif value in [None, "", " "] and matchesvaluemap["simplevaluemap"] not in NULL_CHECK:
        final_value = handling_none_value_map(value, matchesvaluemap)
    if final_value not in [None, "", " "] or final_value not in NULL_CHECK:
        final_value = prepend_append_string(final_value, matchesvaluemap)
    return final_value


def set_secondaryvalue_in_finaljson(mapping_dict, target, value, associationoperation):
    if target not in mapping_dict.keys():
        mapping_dict[target] = ""
    if associationoperation not in NULL_CHECK:
        value = set_value_associationoperation(value, mapping_dict[target], associationoperation)
    mapping_dict[target] = value
    return mapping_dict


def set_value(mapping_dict, value, element, current_index, parent_index):
    parent_entity = element["parententity"]
    associationoperation = element["associationoperation"]

    if parent_index not in NULL_CHECK:
        if parent_index != -1:
            parent_entity = parent_entity + "." + str(parent_index)
    if element["entitytype"] == "repeatable":
        target = parent_entity + "." + element["elemententity"] + "." + str(current_index) + "." + element[
            "elementname"]

    else:
        target = parent_entity + "." + element["elemententity"] + "." + element["elementname"]

    if parent_entity in NULL_CHECK:
        if target.startswith("."):
            target = target.strip(".")

    if target not in mapping_dict.keys():
        mapping_dict[target] = ""
    if associationoperation not in NULL_CHECK:
        value = set_value_associationoperation(value, mapping_dict[target], associationoperation)
    mapping_dict[target] = value

    return mapping_dict


def set_value_associationoperation(source, target, associationoperation):
    if associationoperation.lower() == "overwrite if source value not null":
        if source not in NULL_CHECK:
            target = source

    elif associationoperation.lower() == "overwrite if target value null":
        if target in NULL_CHECK:
            target = source
        else:
            pass

    elif associationoperation.lower() == "overwrite if source greater than target":
        if target in NULL_CHECK:
            target = source
        else:
            if source.isdigit() and target.isdigit():
                source = int(source)
                target = int(target)
            if source >= target:
                target = source

    elif associationoperation.lower() == "overwrite if source lesser than target":
        if target in NULL_CHECK:
            target = source
        else:
            if source.isdigit() and target.isdigit():
                source = int(source)
                target = int(target)
            if source <= target:
                target = source

    elif associationoperation.lower() == "append to existing value":
        if source not in NULL_CHECK:
            if target and source:
                target += " " + source
            else:
                target = source

    elif associationoperation.lower() == "prepend to existing value":
        if target and source:
            target = source + " " + target
        else:
            target = source
    return target


def get_virtual_annotation(element, virtual_annotations):
    element_virtual_annotation_reference = element['virtualannotationreference']

    for virtual_annotation in virtual_annotations:
        if element_virtual_annotation_reference == virtual_annotation["annotation"]["annotid"]:
            element_virtual_annotation = virtual_annotation
            break
    return element_virtual_annotation


def break_address_into_components(address_str):
    parsed_address_tuple = parse_address(address_str)
    address_dict = {}
    for address_component in parsed_address_tuple:
        address_component_key = address_component[1]
        if address_component_key == 'house':
            address_component_key = 'building'
        if address_component_key == 'house_number':
            address_component_key = 'building_number'
        if address_component_key == 'road':
            address_component_key = 'street'
        address_dict[address_component_key] = address_component[0]

    for key, val in address_dict.items():
        if key == "country":
            address_dict[key] = val.upper()
        else:
            address_dict[key] = val.title()

    return address_dict


def get_tokenized_values(string_delimiters, value):
    tokenized_values = []
    tokens = []
    for delimiter in string_delimiters:
        tokens = value.split(delimiter)
        break

    for temp_token in tokens:
        tokenized = False
        for delimiter in string_delimiters:
            if delimiter in temp_token:
                temp_tokens = temp_token.split(delimiter)
                tokenized_values.extend(temp_tokens)
                tokenized = True

        if not tokenized:
            tokenized_values.append(temp_token.strip())

    return tokenized_values


def convert_element_value_for_virtual_annotation(element, element_value, virtual_annotations, parent_annotation_type,
                                                 parent_element_value):
    element_virtual_annotation = get_virtual_annotation(element, virtual_annotations)
    virtual_annotation_type = get_mapping_type(element_virtual_annotation)

    if parent_annotation_type == "freetext":
        if virtual_annotation_type == "table":
            row_delimiters = element_virtual_annotation["setofrows"]["rowdelimiter"].split("|")
            element_value = get_tokenized_values(row_delimiters, element_value)
            element_value = [[ele] for ele in element_value]

        elif virtual_annotation_type == "keyvaluepairs":
            element_value = element_value.split("\n")
            list_of_keys = element_virtual_annotation["annotation"]["datastring"]["keyvaluepairs"]["formkeylist"]
            element_value = get_dict_from_list(list_of_keys, element_value)
    elif parent_annotation_type == "table":
        if virtual_annotation_type == "table":
            row_start = element_virtual_annotation["annotation"]["datastring"]["setofrows"]["startrow"]
            row_end = element_virtual_annotation["annotation"]["datastring"]["setofrows"]["endrow"]
            if row_start.isdigit() and row_end.isdigit():
                row_start = int(row_start) - 1
                row_end = int(row_end)
                element_value = element_value[row_start:row_end]
        elif virtual_annotation_type == "freetext":
            row_start = int(element_virtual_annotation["annotation"]["rowreferenceid"]) - 1
            row_end = row_start + int(element_virtual_annotation["annotation"]["rowreferencelength"])
            cell_start = int(element_virtual_annotation["annotation"]["cellreferenceid"]) - 1
            cell_end = cell_start + int(element_virtual_annotation["annotation"]["cellreferencelength"])
            extracted_data = ""
            for curr_row_indx, row in enumerate(parent_element_value):
                row_data = ""
                if row_start <= curr_row_indx < row_end:
                    for curr_cell_indx, cell in enumerate(row):
                        if cell_start <= curr_cell_indx < cell_end:
                            row_data += cell
                    extracted_data += row_data
            element_value = extracted_data
    return element_value


def get_element_values(value, annotation, virtual_annotations):
    element_values = {}
    for element_index, element in enumerate(annotation["annotation"]["datastring"]["elements"]):
        element_value = value
        if get_mapping_type(annotation) == "freetext":
            if type(element_value) == list:
                element_value_str = ""
                for val in element_value:
                    element_value_str += val + "\n"
                element_value = element_value_str.strip()

            if element_value not in NULL_CHECK:

                if element["alwaysafter"]["afterelementflag"] in TRUE_CHECK:
                    afterelementid = element["alwaysafter"]["afterelementid"]
                    previous_element_value = element_values[afterelementid]
                    element_value = element_value.split(previous_element_value)[-1]

                if element["alwaysbefore"]["beforeelementflag"] in TRUE_CHECK:
                    beforeelementid = element["alwaysbefore"]["beforeelementid"]
                    next_element_value = element_values[beforeelementid]
                    element_value = element_value.split(next_element_value)[0]

                element_value = trim_element_values(element, element_value)

            if element['elementtype'] == "virtual" and element['virtualannotationreference'] not in NULL_CHECK:
                current_annotation_type = get_mapping_type(annotation)
                element_value = convert_element_value_for_virtual_annotation(element, element_value,
                                                                             virtual_annotations,
                                                                             current_annotation_type, value)

        elif get_mapping_type(annotation) == "image":
            if type(value) == list:
                if element_index < len(value):
                    element_value = [value[element_index]]
                else:
                    element_value = [0]

        element_values[element["elementid"]] = element_value

    return element_values


def update_indexes_for_table_elements(mapping_dict, element_metadata_list, element_indx, element, entity_indexes,
                                      value_indx):
    current_index, parent_index, = element["current_index"], element["parent_index"]
    entity_indexes[element['elemententity']] += current_index
    current_index_new = current_index + value_indx
    if element['parententity'] in entity_indexes.keys():
        parent_index_new = entity_indexes[element['parententity']]
        current_index_new = current_index
    else:
        parent_index_new = parent_index

    multi_annot_element_check = [
        True if element["elemententity"] == curr_element["elemententity"] and current_index != -1
        else False for curr_element in element_metadata_list[:element_indx]]
    if any(multi_annot_element_check):
        current_index_new, parent_index_new, grandparent_index = get_latest_indexes(mapping_dict, "simple", element)

    return current_index_new, parent_index_new


def check_record_index(max_current_index, max_parent_index, element, annotationtype):
    recordindex = element['recordindex']
    current_index = max_current_index
    parent_index = max_parent_index
    if recordindex in (NULL_CHECK, "new record"):
        if annotationtype == "virtual":
            current_index = max_current_index
        else:
            current_index = max_current_index + 1

    elif recordindex == "new parent record":
        parent_index = max_parent_index + 1
    # max_parent_index = max_parent_index + 1

    elif recordindex in ("last record", "last parent record"):
        pass

    elif recordindex == "first record":
        current_index = 0
    elif recordindex == "first parent record":
        parent_index = 0

    else:
        current_index = int(recordindex)

    if element['parententity'] in ("admin", "patient", "deathDetail", ""):
        parent_index = -1

    return current_index, parent_index


# latter corresponds to the right-side index in mapping dict keys
def update_latter_index(splitted_key):
    current_index = 0
    if splitted_key[-1].split(".")[0] == "" and len(splitted_key[0].split(".")) > 1:
        if splitted_key[-1].split(".")[1].isdigit():
            current_index = int(splitted_key[-1].split(".")[1])
    else:
        if splitted_key[-1].split(".")[0].isdigit():
            current_index = int(splitted_key[-1].split(".")[0])

    return current_index


# former corresponds to the left-side index in mapping dict keys
def update_former_index(splitted_key):
    current_index = 0
    if splitted_key[0].split(".")[-1] == "" and len(splitted_key[0].split(".")) > 1:
        if splitted_key[0].split(".")[-2].isdigit():
            current_index = int(splitted_key[0].split(".")[-2])
    else:
        if splitted_key[0].split(".")[-1].isdigit():
            current_index = int(splitted_key[0].split(".")[-1])

    return current_index


# gives the latest indexes of the element in the entity and entity in the parent entity
def get_latest_indexes(mapping_dict, annotationtype, element):
    entity = element['elemententity']
    parent_entity = element['parententity']
    grandparent_index = 0
    max_current_index = -1
    max_parent_index = -1
    if mapping_dict == {}:
        max_current_index = 0
        max_parent_index = 0
    else:
        for key, value in mapping_dict.items():
            if entity in key:
                splitted_key = key.split(entity)
                current_index = update_latter_index(splitted_key)
                parent_index = update_former_index(splitted_key)
            elif parent_entity not in NULL_CHECK and parent_entity != "admin" and parent_entity in key:
                splitted_key = key.split(parent_entity)
                parent_index = update_latter_index(splitted_key)
                current_index = -1
            else:
                current_index = -1
                parent_index = -1

            if current_index > max_current_index:
                max_current_index = current_index
            if parent_index > max_parent_index:
                max_parent_index = parent_index

    updated_current_index, updated_parent_index = check_record_index(max_current_index, max_parent_index, element,
                                                                     annotationtype)
    return updated_current_index, updated_parent_index, grandparent_index


# update index if multiple elements of an annotation mapping to same field
def update_index_for_similar_mapped_elements(annotation, element_metadata_list):
    element_entity_map = {}
    for element in annotation["annotation"]["datastring"]["elements"]:
        element_entity_map[element['elementid']] = element['elemententity'] + "." + element['elementname']

    entity_map_dict = {}
    for val in element_entity_map:
        if element_entity_map[val] in entity_map_dict:
            entity_map_dict[element_entity_map[val]].append(val)
        else:
            entity_map_dict[element_entity_map[val]] = [val]

    ####  entity_map_dict = {<entity.elementname> : [elementid1 , elementid2]}
    for entity, elementids in entity_map_dict.items():
        if len(elementids) > 1:
            for elementid in elementids[1:]:
                for element in element_metadata_list:
                    if element['elementid'] == elementid:
                        if element['recordindex'].lower() == "new record":
                            element['current_index'] += 1
                        break
    return element_metadata_list


def get_element_metadata(value, annotation, mapping_dict, virtual_annotations):
    element_metadata_list = []
    for element in annotation["annotation"]["datastring"]["elements"]:
        element_dict = element
        element_dict["element_indx"] = annotation["annotation"]["datastring"]["elements"].index(element)
        if element_dict["elementtype"] == "simple":
            element_dict["current_index"], element_dict["parent_index"], element_dict["grandparent_index"] = \
                get_latest_indexes(mapping_dict, annotation['annotation']['annotationtype'], element)

            if element_dict["current_index"] == -1:
                element_dict["current_index"] = 0

        element_dict["element_value"] = None
        element_metadata_list.append(element_dict)

    # update index if multiple elements of an annotation mapping to same field
    element_metadata_list = update_index_for_similar_mapped_elements(annotation, element_metadata_list)

    if get_mapping_type(annotation) in ("freetext", "image"):
        element_values = get_element_values(value, annotation, virtual_annotations)
        for element in element_metadata_list:
            for elementid, element_value in element_values.items():
                if elementid == element['elementid']:
                    element['element_value'] = element_value
                    break

    return element_metadata_list


def set_secondary_associations(mapping_dict, element, element_value, original_element_value, current_index,
                               parent_index):
    parent_entity = element["parententity"]
    for secondaryassociations in element['secondaryassociations']:
        if secondaryassociations["secondaryelement"] != "":
            secondary_element_value = secondaryassociations["secondaryelementvalue"]

            if secondaryassociations["secondaryelementvalue"] == "__LISTORDER":
                secondary_element_value = current_index + 1

            elif secondaryassociations["secondaryelementvalue"] == "__PRIMARY":
                secondary_element_value = element_value

            elif secondaryassociations["secondaryelementvalue"] == "__PRIMARY UNTRANSFORMED":
                secondary_element_value = original_element_value

            if element["entitytype"] == "repeatable":

                if "parent" in secondaryassociations["secondaryentity"].lower():
                    current_parent_entity = get_parent_entity(element["elemententity"], current_index)
                    target = current_parent_entity + "." + str(current_index) + "." + secondaryassociations[
                        "secondaryelement"]

                elif "grandparent" in secondaryassociations["secondaryentity"].lower():

                    current_grandparent_entity = get_grandparent_entity(element["elemententity"], current_index)
                    target = current_grandparent_entity + "." + str(current_index) + "." + secondaryassociations[
                        "secondaryelement"]

                else:
                    # if secondaryassociations["secondaryentity"] in ("currententity","",None,"null"):
                    target = parent_entity + "." + element["elemententity"] + "." + str(current_index) + "." + \
                             secondaryassociations["secondaryelement"]

            else:

                if "parent" in secondaryassociations["secondaryentity"].lower():
                    current_parent_entity = get_parent_entity(element["elemententity"], current_index)
                    target = current_parent_entity + "." + secondaryassociations["secondaryelement"]

                elif "grandparent" in secondaryassociations["secondaryentity"].lower():
                    current_grandparent_entity = get_grandparent_entity(element["elemententity"], current_index)
                    target = current_grandparent_entity + "." + secondaryassociations["secondaryelement"]

                else:
                    # if secondaryassociations["secondaryentity"] in ("currententity","",None,"null"):
                    target = parent_entity + "." + element["elemententity"] + "." + secondaryassociations[
                        "secondaryelement"]

            mapping_dict = set_secondaryvalue_in_finaljson(mapping_dict, target, secondary_element_value,
                                                           secondaryassociations["secondaryassociationoperation"])

    return mapping_dict


def image_mapping(value, annotation, mapping_dict, virtual_annotations):
    element_metadata_list = get_element_metadata(value, annotation, mapping_dict, virtual_annotations)
    for element in element_metadata_list:
        element_value_list = element['element_value']
        for value_indx in range(len(element_value_list)):
            element_value = element_value_list[value_indx]
            original_element_value = element_value
            element_value = simple_value_mapping(element_value, element["matchesvaluemap"])
            if element["elementtype"] == "simple":
                if element_value not in (None, ""):
                    current_index, parent_index, grandparent_index = get_latest_indexes(mapping_dict, "simple",element)

                    mapping_dict = set_value(mapping_dict, element_value, element, current_index, parent_index)
                    mapping_dict = set_secondary_associations(mapping_dict, element, element_value,
                                                              original_element_value, current_index, parent_index)
            else:
                element_virtual_annotation = get_virtual_annotation(element, virtual_annotations)
                mapping_dict = build_mapping_dict(element_value, element_virtual_annotation, mapping_dict,
                                                  virtual_annotations)

    return mapping_dict


def freeText_mapping(val, annotation, mapping_dict, virtual_annotations):
    element_metadata_list = get_element_metadata(val, annotation, mapping_dict, virtual_annotations)
    for element in element_metadata_list:
        element_value = element['element_value']
        original_element_value = element_value
        if element['elementtype'] == 'simple':

            element_value = simple_value_mapping(element_value, element["matchesvaluemap"])

            current_index, parent_index, = element["current_index"], element["parent_index"]

            mapping_dict = set_value(mapping_dict, element_value, element, current_index, parent_index)
            mapping_dict = set_secondary_associations(mapping_dict, element, element_value, original_element_value,
                                                      current_index, parent_index)
        else:
            element_virtual_annotation = get_virtual_annotation(element, virtual_annotations)
            mapping_dict = build_mapping_dict(element_value, element_virtual_annotation, mapping_dict,
                                              virtual_annotations)

    return mapping_dict


def table_mapping(value, annotation, mapping_dict, virtual_annotations):
    elements_in_annotation = len(annotation["annotation"]["datastring"]["elements"])
    elements_in_value = len(value[0])
    common_elements_count = min(elements_in_value, elements_in_annotation)
    if elements_in_value != elements_in_annotation:
        logger.warning("elements in annotations does not match elements in list for tabular annotation %s",
                       annotation["annotation"]["datastring"]["name"])

    element_metadata_list = get_element_metadata(value, annotation, mapping_dict, virtual_annotations)
    for value_indx in range(len(value)):
        entity_indexes = {}
        for element_indx in range(common_elements_count):
            element = element_metadata_list[element_indx]
            element_value = trim_element_values(element, value[value_indx][element_indx])
            original_element_value = element_value
            element_value = simple_value_mapping(element_value, element["matchesvaluemap"])

            entity_indexes[element['elemententity']] = value_indx
            if element["elementtype"] == 'simple':
                # element_value = get_element_values_table(element, element_value)
                current_index_new, parent_index_new = update_indexes_for_table_elements(mapping_dict,
                                                                                        element_metadata_list,
                                                                                        element_indx, element,
                                                                                        entity_indexes, value_indx)

                mapping_dict = set_value(mapping_dict, element_value, element, current_index_new, parent_index_new)
                mapping_dict = set_secondary_associations(mapping_dict, element, element_value, original_element_value,
                                                          current_index_new, parent_index_new)
            else:
                element_virtual_annotation = get_virtual_annotation(element, virtual_annotations)
                current_annotation_type = get_mapping_type(annotation)
                element_value = convert_element_value_for_virtual_annotation(element, element_value,
                                                                             virtual_annotations,
                                                                             current_annotation_type, value)
                mapping_dict = build_mapping_dict(element_value, element_virtual_annotation, mapping_dict,
                                                  virtual_annotations)

    return mapping_dict


def utility_keyvaluepairs_mapping(value, annotation, mapping_dict, virtual_annotations=[]):
    if type(value) == list:
        for value_keyvalue in value:
            mapping_dict = keyvaluepairs_mapping(value_keyvalue, annotation, mapping_dict, virtual_annotations)
    else:
        mapping_dict = keyvaluepairs_mapping(value, annotation, mapping_dict, virtual_annotations)
    return mapping_dict


def keyvaluepairs_mapping(value, annotation, mapping_dict, virtual_annotations):
    if type(value) == str:
        try:
            value = ast.literal_eval(value)  # Converting String representation of a Dictionary to a dictionary
        except:
            pass

    value_delimiter = annotation["annotation"]["datastring"]["keyvaluepairs"]["keyvalueseperator"]
    element_metadata_list = get_element_metadata(value, annotation, mapping_dict, virtual_annotations)
    if annotation['annotation']['datastring']['keyvaluepairs']['useaddressmacro'] in TRUE_CHECK:
        value = break_address_into_components(value)

    for element in element_metadata_list:
        form_key = element["jsonkeyname"]
        if form_key in value:
            element_value = trim_element_values(element, value.get(form_key, ""))

            if value_delimiter not in NULL_CHECK and element["absoluteposition"] not in NULL_CHECK:
                try:
                    element_value = element_value.split(value_delimiter)[int(element["absoluteposition"])-1]
                except:
                    element_value = ""
            original_element_value = element_value
            element_value = simple_value_mapping(element_value, element["matchesvaluemap"])

            if element["elementtype"] == "simple":
                current_index, parent_index = element["current_index"], element["parent_index"]

                mapping_dict = set_value(mapping_dict, element_value, element, current_index, parent_index)
                mapping_dict = set_secondary_associations(mapping_dict, element, element_value, original_element_value,
                                                          current_index, parent_index)
            else:
                element_virtual_annotation = get_virtual_annotation(element, virtual_annotations)
                mapping_dict = build_mapping_dict(element_value, element_virtual_annotation, mapping_dict,
                                                  virtual_annotations)

    return mapping_dict


# I1,I2,I3 and I4
def delimited_mapping(value, annotation, mapping_dict, virtual_annotations):
    string_delimiters = annotation['annotation']['datastring']['stringdelimiters']
    element_metadata_list = get_element_metadata(value, annotation, mapping_dict, virtual_annotations)
    tokenized_values = get_tokenized_values(string_delimiters, value)

    for element in element_metadata_list:
        element_tokenized_position = int(element['absoluteposition']) - 1
        if element_tokenized_position < len(tokenized_values):
            element_value = tokenized_values[element_tokenized_position]
            element_value = trim_element_values(element, element_value)
            original_element_value = element_value

            element_value = simple_value_mapping(element_value, element["matchesvaluemap"])

            if element['elementtype'] == 'simple':
                parent_index = element["parent_index"]
                current_index = element["current_index"]

                mapping_dict = set_value(mapping_dict, element_value, element, current_index, parent_index)
                mapping_dict = set_secondary_associations(mapping_dict, element, element_value,
                                                          original_element_value, current_index, parent_index)
            else:
                element_virtual_annotation = get_virtual_annotation(element, virtual_annotations)
                mapping_dict = build_mapping_dict(element_value, element_virtual_annotation, mapping_dict,
                                                  virtual_annotations)
    return mapping_dict


def construct_pvi_dict(mapping_dict, pvi_dict):
    for key, value in mapping_dict.items():
        if type(value) == list:
            for seq in range(len(value)):
                splitted_key = key.split(".")
                splitted_key[-2] = splitted_key[-2] + "." + str(seq)
                pvi_key = ".".join(x for x in splitted_key)
                pvi_dict[pvi_key] = value[seq]
        else:
            pvi_dict[key] = value
    return pvi_dict


def build_mapping_dict(value, annotation, mapping_dict, virtual_annotations):
    mapping_type = get_mapping_type(annotation)
    if mapping_type == "image":
        mapping_dict = image_mapping(value, annotation, mapping_dict, virtual_annotations)

    elif mapping_type == "freetext":
        mapping_dict = freeText_mapping(value, annotation, mapping_dict, virtual_annotations)

    elif mapping_type == "delimited":
        mapping_dict = delimited_mapping(value, annotation, mapping_dict, virtual_annotations)

    elif mapping_type == "table":
        if len(value) > 0:
            mapping_dict = table_mapping(value, annotation, mapping_dict, virtual_annotations)

    elif mapping_type == "keyvaluepairs":
        mapping_dict = utility_keyvaluepairs_mapping(value, annotation, mapping_dict, virtual_annotations)

    return mapping_dict


def process_group(group, group_list):
    mapping_dict = {}
    virtual_annotations = get_all_virtual_annotations(group["annotations"])
    for vals in group_list:
        for key in vals.keys():
            for annotation in group["annotations"]:
                if key == annotation["annotation"]["datastring"]["name"]:
                    if annotation["annotation"]["annotationtype"] != "virtual":
                        if annotation["annotation"]["annotationmatrix"] not in TRUE_CHECK:
                            mapping_dict = build_mapping_dict(vals[key], annotation, mapping_dict, virtual_annotations)
                        else:
                            for matrix_index in range(len(vals[key])):
                                mapping_dict = build_mapping_dict(vals[key][matrix_index], annotation, mapping_dict,
                                                                  virtual_annotations)

    return mapping_dict


def findIndex(target, key):
    for indx in range(len(target)):
        if target[indx] == key:
            return target[indx + 1]


def recursively_populate_PVIJson(pvi_json_template, pvi_json, target, template_target, value):
    for path in target:
        if path in pvi_json:
            if type(pvi_json[path]) == list:
                struct = pvi_json[path]
                index = int(findIndex(target, path))
                if index < len(struct):
                    struct = copy.deepcopy(struct[index])
                else:
                    if len(template_target) == 1:
                        struct_copy = copy.deepcopy(pvi_json_template[template_target[0]][0])
                    elif len(template_target) == 2:
                        struct_copy = copy.deepcopy(pvi_json_template[template_target[0]][template_target[1]][0])
                    elif len(template_target) == 3:
                        struct_copy = copy.deepcopy(
                            pvi_json_template[template_target[0]][template_target[1]][template_target[2]][0])
                    struct.append(struct_copy)
                    struct = copy.deepcopy(struct[index])
                target = target[target.index(path) + 2:]

                ''' recusive call  with subsections of the pvi json and target
                to incrementally build  the pvi json '''
                struct = recursively_populate_PVIJson(pvi_json_template, struct, target, template_target, value)
                pvi_json[path][index] = copy.deepcopy(struct)

            elif type(pvi_json[path]) == dict:
                struct = pvi_json[path]
                target = target[target.index(path) + 1:]

                ''' recusive call  with subsections of the pvi json and target
                to incrementally build  the pvi json '''
                struct = recursively_populate_PVIJson(pvi_json_template, struct, target, template_target, value)
                pvi_json[path] = struct

            else:
                pvi_json[path] = copy.deepcopy(value)
    return pvi_json


def build_target_template(target):
    target_template = target
    target_template_final = []
    if target_template[0] == 'admin':
        target_template.pop(0)

    for indx, tgt in enumerate(target_template):
        try:
            target_template[indx] = int(target_template[indx])
            target_template[indx] = 0
        except:
            pass

    for indx, tgt in enumerate(target_template[::-1]):
        if type(tgt) == int:
            break_indx = len(target_template) - indx - 1
            target_template = target_template[:break_indx]
            break

    all_occurences = []
    for tgt in target_template:
        for indx in range(len(target_template)):
            if target_template[indx] == tgt:
                all_occurences.append(indx)
                break
    all_occurences.sort()
    first_occurences = set(all_occurences)

    for occurence in first_occurences:
        target_template_final.append(target_template[occurence])

    return target_template_final


def postprocess(pvi_json, form_id, extracted_data_json):
    if path.exists(path.join(CUSTOMIZATION_FOLDER, "postprocessing_" + str(form_id) + ".py")):
        if CUSTOMIZATION_FOLDER not in sys.path:
            sys.path.append(CUSTOMIZATION_FOLDER)

        postprocessing_file = "postprocessing_" + str(form_id)
        postprocessing = __import__(postprocessing_file)
        try:
            pvi_json = postprocessing.get_postprocessed_json(pvi_json, extracted_data_json)
        except Exception as e:
            logger.error("Error in Post Processing file\n %s", e)
            pass
    else:
        logger.warning("Post PRocessing File Not found for the formid %s", form_id)
    return pvi_json


def createFinalJson(mapping_json, key_val_json, outputformat, form_id):
    PVI_mapping_dict = {}
    reference_json_path = path.join(REFERENCE_JSON_FOLDER, str(outputformat) + "_reference.json")
    pvi_json = reading_json(reference_json_path)
    pvi_json_template = copy.deepcopy(pvi_json)

    for group in mapping_json:
        group_operations = group["groupoperations"]
        annotations = group["annotations"]
        group_list = get_annotationvalues_list(group_operations, annotations, key_val_json)
        PVI_mapping_dict.update(process_group(group, group_list))


    for key, value in PVI_mapping_dict.items():
        if value not in ("", None, " "):
            if type(value) == str:
                value = value.replace("\\n", "\n").strip()
            PVI_mapping_dict[key] = value
    logger.info("final_mapping_dict")
    # logger.info(json.dumps(PVI_mapping_dict, indent=2, sort_keys=True))

    for key, value in PVI_mapping_dict.items():
        target = key.split(".")
        target_template = build_target_template(copy.deepcopy(target))
        try:
            pvi_json = recursively_populate_PVIJson(pvi_json_template, pvi_json, target, target_template, value)
        except:
            pass
    pvi_json = postprocess(pvi_json, form_id, key_val_json)

    try:
        # replace empty string with none
        replace_empty_str = json.dumps(pvi_json).replace('""', 'null')
        pvi_json = json.loads(replace_empty_str)
    except:
        pass

    return pvi_json


# 1 ) Cipla US Tablet (P-COUMARIC ACID 100 g) Injection, 100 millimole {Lot # 12345; Exp.Dt. 01-SEP-2016}

# mapping_file = "/home/aditya/generic_poc/inputs/pdf/NNI-release2/eml/nni_eml_ui.json"
# mapping_json = reading_json(mapping_file)['configdefinition']
# key_val_json = reading_json("/home/aditya/generic_poc/inputs/pdf/NNI-release2/eml/data.json")
# docType = 'digitalpdf'
# outputformat = 'PVI_4.6'
# pvi_json = createFinalJson(mapping_json, key_val_json, 'PVI_4.6', '6230f386-1b40-11eb-9bbc-12414bf81c8f')
# with open("/home/aditya/generic_poc/inputs/pdf/NNI-release2/final_json.json", 'w') as outfile:
#     json.dump(pvi_json, outfile)


# mapping_file = "/home/aditya/generic_poc/inputs/pdf/novo/mapping-novo.json"
# mapping_json = reading_json(mapping_file)['configdefinition']
# key_val_json = reading_json("/home/aditya/generic_poc/inputs/pdf/novo/data.json")
# docType = 'digitalpdf'
# pvi_json = createFinalJson(mapping_json, key_val_json, docType, 'PVI_4.6', 'fefab75a-a3fa-11ea-9989-12414bf81c8f')
# with open("/home/aditya/generic_poc/inputs/pdf/novo/final_json.json", 'w') as outfile:
#     json.dump(pvi_json, outfile)

# mapping_file = "/home/aditya/generic_poc/inputs/pdf/pfizer/mapping-pfizer.json"
# mapping_json = reading_json(mapping_file)['configdefinition']
# key_val_json = reading_json("/home/aditya/backendservice/utility/data.json")
# docType = 'digitalpdf'
# pvi_json = createFinalJson(mapping_json, key_val_json, docType, 'PVI_4.6', 'fefab75a-a3fa-11ea-9989-12414bf81c8f')

# mapping_file = "/home/aditya/generic_poc/inputs/pdf/MRP/mapping_MRP.json"
# mapping_json = reading_json(mapping_file)['configdefinition']
# key_val_json = reading_json("/home/aditya/backendservice/utility/data.json")
# docType = 'digitalpdf'
# pvi_json = createFinalJson(mapping_json,key_val_json,docType,'PVI_4.6','fefab75a-a3fa-11ea-9989-12414bf81c8f')
#

# mapping_file = "/home/aditya/generic_poc/inputs/pdf/new_mnk/newmnk_4_May.json"
# mapping_json = reading_json(mapping_file)['configdefinition']
# key_val_json = reading_json("/home/aditya/generic_poc/inputs/pdf/new_mnk/data.json")
# docType = 'digitalpdf'
# pvi_json = createFinalJson(mapping_json,key_val_json,docType,'PVI_4.1','2bbe38ee-7fb5-11ea-9d1a-309c23285c95')

# mapping_file = "/home/aditya/generic_poc/inputs/pdf/novo/novo_mapping_11May.json"
# mapping_json = reading_json(mapping_file)['configdefinition']
# key_val_json = reading_json("/home/aditya/generic_poc/inputs/pdf/novo/data.json")
# docType = 'digitalpdf'
# pvi_json = createFinalJson(mapping_json,key_val_json,docType,'PVI_4.6')

# mapping_file = "/home/aditya/generic_poc/inputs/docx/merckariesmapping_28_Mar.json"
# mapping_json = reading_json(mapping_file)
# key_val_json = reading_json("/home/aditya/generic_poc/inputs/docx/merckAries/retjson.json")
# docType = 'docx'
# mapping_dict = createFinalJson(mapping_json,key_val_json,docType)

# mapping_file = "/home/aditya/generic_poc/inputs/pdf/amgen/AmgenNew-01_24_mar_full_matrix_akshatha_latest_suresh_template2.json"
# mapping_json = reading_json(mapping_file)
# key_val_json = reading_json("/home/aditya/generic_poc/inputs/pdf/amgen/one_pagepdf_retjson.json")
# docType = 'imagepdf'
# mapping_dict = createFinalJson(mapping_json,key_val_json,docType)

'''
mapping_file = "/home/suresh/Downloads/cioms1_mapping.json"
mapping_json = reading_json(mapping_file)
key_val_json = reading_json("/home/suresh/backendservice/utility/uploads/Request-6732dfc5-30bd-4409-8c6d-01baf2266a04/data.json")
docType = 'digitalpdf'
print("mapping_json= ", mapping_json)
mapping_dict = createFinalJson(mapping_json, key_val_json, "PVI_4.6", "123")
print("mapping_dict = ", mapping_dict)
'''