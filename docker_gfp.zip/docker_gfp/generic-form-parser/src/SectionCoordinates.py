#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 14:56:56 2019

@author: sahib
"""

import re
import numpy as np
import pandas as pd

def compute_sectionheadercoords(config, word_cords_df):
    word_cords_df['length'] = word_cords_df.word.str.len()
    word_cords_df['end'] = word_cords_df.length.cumsum()-1+range(word_cords_df.shape[0])
    word_cords_df['start'] = word_cords_df.end - word_cords_df.length+1
    growth = word_cords_df.word.astype(str).str.cat(sep=' ')
    out = []
    for row_index, row in config.iterrows():
        begin = [m.start() for m in re.finditer(row['text'],growth)]
        stop = [m.end() for m in re.finditer(row['text'],growth)]   
        for begin_index in range(0,len(begin)):
            seq = (word_cords_df.start >= begin[begin_index]) & (word_cords_df.end <= stop[begin_index])        
            out.append([row['text'],seq[seq==True].index.tolist()[0], seq[seq==True].index.tolist()[-1]])
    if(out!=[]):
        df_sec_cords = pd.DataFrame(out, columns = ['label', 'start', 'end'])
        df_sec_cords['pageno'] = ""
        for section_index in range(0,len(df_sec_cords)):
            start_position = df_sec_cords.at[section_index,'start']
            df_sec_cords.iloc[section_index,3] = int(word_cords_df.at[start_position, 'page_no'])
        df_sec_cords = df_sec_cords.reset_index(drop=True)
        return(df_sec_cords)
    else:
        return (None) 

def handling_sections_present_in_last_page(section_index,df_section_coords,df_hocr,df_final):
        #add the section from last page
    if(section_index==(len(df_section_coords)-1)):
        start_cords_df = df_section_coords.at[section_index,'start']
        end_cords_df = df_section_coords.at[section_index,'end']
        df_hocr_filtered = df_hocr.loc[(df_hocr['page_no'] == df_hocr.at[start_cords_df, 'page_no']) & (df_hocr['rownum'] >= df_hocr.at[start_cords_df, 'rownum']) & (df_hocr['bottom'] >= df_hocr.at[start_cords_df, 'bottom']) & (df_hocr['top'] > df_hocr.at[end_cords_df, 'top'])]
        df_hocr_filtered['right'] = pd.to_numeric(df_hocr_filtered['right'])
        df_final = df_final.append({
                     "label":df_section_coords.at[section_index,'label'],
                     "page_no":int(df_section_coords.at[section_index,'pageno']),                              
                     "left": df_hocr_filtered.left.min(),
                     "top": df_hocr_filtered.top.min(),
                     "right":df_hocr.right.max(),
                     "bottom":df_hocr_filtered.bottom.max(),
                     "width":df_hocr_filtered.iloc[[-1]].width.values[0],
                     "height":df_hocr_filtered.iloc[[-1]].height.values[0],  
                     "rownum":df_hocr.at[start_cords_df, 'rownum']
                      }, ignore_index=True) 
    return df_final

def handling_mulitple_labels_present_within_a_page(df_section_coords,section_index,df_hocr,start_cords_df,df_final,start_cords_df_next,end_cords_df):   
    #if more than one label starting and ending in  one page
    if(int(df_section_coords.at[section_index, 'pageno'])==int(df_section_coords.at[section_index+1, 'pageno'])): 
        df_hocr_filtered = df_hocr.loc[(df_hocr['rownum'] >= df_hocr.at[start_cords_df, 'rownum']) & (df_hocr['rownum'] <= df_hocr.at[start_cords_df_next, 'rownum']) & (df_hocr['bottom'] >= df_hocr.at[start_cords_df, 'bottom']) & (df_hocr['top'] > df_hocr.at[end_cords_df, 'top']) ]
        if(int(df_hocr.at[start_cords_df, 'page_no'])!=0):                                                                 
            df_final = df_final.append({
                             "label":df_section_coords.at[section_index,'label'],
                             "page_no":int(df_section_coords.at[section_index, 'pageno']),                            
                             "left": df_hocr_filtered.left.min(),
                             "top": df_hocr_filtered.top.min(),
                             "right":df_hocr.right.max(),
                             "bottom":df_hocr_filtered.bottom.max(),
                             "width":df_hocr.iloc[[-1]].width.values[0],
                             "height":df_hocr.iloc[[-1]].height.values[0],  
                             "rownum":df_hocr.at[start_cords_df, 'rownum']
                             }, ignore_index=True)
    return df_final

def handling_label_present_within_a_page(df_section_coords,df_hocr,df_final,section_index,start_cords_df):
    #if only one label starting and ending in complete one page
    if(int(df_section_coords.at[section_index, 'pageno'])!=int(df_section_coords.at[section_index+1, 'pageno'])):
        df_hocr_filtered = df_hocr.loc[(df_hocr['page_no'] == df_hocr.at[start_cords_df, 'page_no']) & (df_hocr['rownum'] >= df_hocr.at[start_cords_df, 'rownum']) & (df_hocr['bottom'] >= df_hocr.at[start_cords_df, 'bottom'])]
        df_hocr_filtered['right'] = pd.to_numeric(df_hocr_filtered['right'])
        df_final = df_final.append({
                     "label":df_section_coords.at[section_index,'label'],
                     "page_no":int(df_section_coords.at[section_index,'pageno']),                              
                     "left": df_hocr_filtered.left.min(),
                     "top": df_hocr_filtered.top.min(),
                     "right":df_hocr.right.max(),
                     "bottom":df_hocr_filtered.bottom.max(),
                     "width":df_hocr_filtered.iloc[[-1]].width.values[0],
                     "height":df_hocr_filtered.iloc[[-1]].height.values[0],  
                     "rownum":df_hocr.at[start_cords_df, 'rownum']
                      }, ignore_index=True)
    return df_final

def extract_sections(df_section_coords,df_hocr):   
    df_hocr[["confidence", "page_no","left","top","right","bottom","width","height","rownum","length","end","start"]] = df_hocr[["confidence", "page_no","left","top","right","bottom","width","height","rownum","length","end","start"]].apply(pd.to_numeric)
    df_final = pd.DataFrame( columns=['label',"left","top","right","bottom",'width','height','rownum'])
    df_hocr['word'].replace(' ', np.nan, inplace=True)
    df_hocr = df_hocr.dropna(subset=['word'])
    for section_index in range(0,len(df_section_coords)):
        if (section_index+1<len(df_section_coords)):  
            start_cords_df = df_section_coords.at[section_index,'start']          
            end_cords_df = df_section_coords.at[section_index,'end']        
            start_cords_df_next = df_section_coords.at[section_index+1,'start']            
            df_final = handling_label_present_within_a_page(df_section_coords,df_hocr,df_final,section_index,start_cords_df)
            df_final = handling_mulitple_labels_present_within_a_page(df_section_coords,section_index,df_hocr,start_cords_df,df_final,start_cords_df_next,end_cords_df)
            df_final = handling_sections_present_in_last_page(section_index,df_section_coords,df_hocr,df_final)    
    df_final = prepare_final_df(df_final)
    return df_final

def prepare_final_df(df_final):
    row_num = df_final[df_final["label"]=="ADMINISTRATIVE NOTES"]
    if len(row_num)!=0:
        row_num = row_num.index[0]
        df_final = df_final.drop([row_num])
    df_final.dropna(axis="rows", how='any')
    if len(df_final)>0:
        df_final = df_final.sort_values('page_no')
        df_final['page'] = df_final.page_no
        df_final = df_final.drop(columns=['rownum', 'page_no'])
        df_final['left'] = df_final.left.astype(int)
        df_final['top'] = df_final.top.astype(int)
        df_final['right'] = df_final.right.astype(int)
        df_final['bottom'] = df_final.bottom.astype(int)
        df_final = df_final.drop(columns=['width', 'height'])
    return df_final
    
def getSectionCoordinates(section_headers,word_cords_df):
    section_coords = pd.DataFrame( columns=['label',"left","top","right","bottom",'width','height','rownum'])
    config = pd.DataFrame(section_headers,columns=["text"])
    word_cords_df['rownum'] = word_cords_df.reset_index().index    
    df_section_coords = compute_sectionheadercoords(config, word_cords_df)
    if(len(df_section_coords)>0):
        section_coords = extract_sections(df_section_coords,word_cords_df)
    return section_coords
   