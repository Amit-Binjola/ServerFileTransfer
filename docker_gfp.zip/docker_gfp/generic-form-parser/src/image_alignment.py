#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  8 09:39:41 2021

@author: suresh
"""

import cv2
from os import path
import imutils
import numpy as np
import pandas as pd
from PIL import Image
from config import CONFIG_JSON
from tesserocr import PyTessBaseAPI, PSM, OEM
from common_utils import get_table_refstr_pos

if CONFIG_JSON["ocr"]["required"]:
    OCR_tool = CONFIG_JSON["ocr"]["tools"][0].lower()
    if OCR_tool == "tesserocr":
        from tesserocr_utilities import extract_text_tesserOCR, generate_hocr
    elif OCR_tool == "abbyy":
        from AbbyyExtract import getmultizonal, getZonalOCR, generate_abbyy_hocr


def get_wordcords(image, req_folder, angle):
    image_path = path.join(req_folder, "image.png")
    cv2.imwrite(image_path, image)
    if OCR_tool == "tesserocr":
        word_cords = generate_hocr(req_folder, [image_path])
    elif OCR_tool == "abbyy":
        word_cords = generate_abbyy_hocr(req_folder, [image_path])

    word_cords["word"] = word_cords.word.str.strip()
    word_cords["pageno"] = word_cords["pageno"].apply(pd.to_numeric)
    word_cords["left"] = word_cords["left"].apply(pd.to_numeric)
    word_cords["top"] = word_cords["top"].apply(pd.to_numeric)
    word_cords["width"] = word_cords["width"].apply(pd.to_numeric)
    word_cords["height"] = word_cords["height"].apply(pd.to_numeric)
    word_cords.to_csv(req_folder + str(angle) + ".csv")
    return word_cords


def find_word_existance(word_cords, search_word, coord_pos, word_exist):
    start_key_pos = get_table_refstr_pos(word_cords, search_word, "", 0)
    left_diff = 0
    top_diff = 0
    thresh = 300
    left = 0
    top = 0
    if start_key_pos != None:
        left = word_cords.iloc[start_key_pos]["left"]
        top = word_cords.iloc[start_key_pos]["top"]
        ref_left = int(float(coord_pos.split(",")[0]))
        ref_top = int(float(coord_pos.split(",")[1]))
        top_adj = top - thresh
        if top_adj < 0:
            top_adj = 0
        left_adj = left - thresh
        if left_adj < 0:
            left_adj = 0
        if ref_top <= top + thresh:  # and ref_top >= top_adj:
            if ref_left <= left + thresh:  # and ref_left >= left_adj:
                word_exist = True
                left_diff = ref_left - left
                top_diff = ref_top - top

    return word_exist, [left, top], [left_diff, top_diff]


# shifting pixels left-right or right to left (horizontal shift)
def shift_pixels_by_xy_axis(image, pixels_to_shift, axis):
    for row_index in range(image.shape[1] - 1, image.shape[1] - pixels_to_shift, -1):
        image = np.roll(image, -1, axis)
        if axis == 0:
            image[-1, :] = 0
        else:
            image[:, -1] = 0
    cv2.imwrite("img.png", image)

    return image


def deskew(image):
    cv2.imwrite("image.png", image)
    with PyTessBaseAPI(psm=PSM.AUTO_OSD) as api:
        open_image = Image.open("image.png")
        api.SetImage(open_image)
        api.Recognize()
        it = api.AnalyseLayout()
        orientation, direction, order, deskew_angle = it.Orientation()
    if deskew_angle:
        image = imutils.rotate(image, deskew_angle)
    return image


def rotate_bound(image, angle):
    (height, width) = image.shape[:2]
    (center_x, center_y) = (width // 2, height // 2)
    rotation_matrix = cv2.getRotationMatrix2D((center_x, center_y), -angle, 1.0)
    cos = np.abs(rotation_matrix[0, 0])
    sin = np.abs(rotation_matrix[0, 1])
    new_width = int((height * sin) + (width * cos))
    new_height = int((height * cos) + (width * sin))
    rotation_matrix[0, 2] += (new_width / 2) - center_x
    rotation_matrix[1, 2] += (new_height / 2) - center_y
    return cv2.warpAffine(image, rotation_matrix, (new_width, new_height))


def align_image(req_folder, image, search_word, coord_pos, image_shape):
    word_exist = False
    for angle in [0, 90, 180, 270]:
        #image = imutils.rotate(image, angle)
        rows, cols = image.shape
        M = cv2.getRotationMatrix2D((cols / 2, rows / 2), angle, 1)
        image = cv2.warpAffine(image, M, (cols, rows))
        #image = rotate_bound(image, angle)
        #image = cv2.resize(image, image_shape)
        im_path = path.join(req_folder, str(angle) + ".png")
        cv2.imwrite(im_path, image)
        image = cv2.imread(im_path, 0)
        word_cords = get_wordcords(image, req_folder, angle)
        word_exist, coords, pixels_to_shift = find_word_existance(word_cords, search_word,
                                                                  coord_pos, word_exist)

        if word_exist:
            break

    return word_exist, angle, image, pixels_to_shift


# , "SUSPECT ADVERSE": "572, 345, 1247, 398"   672	4069	712	4250

# 4407	46	4695	87

# left, top, right, height
reference_strings_dict = {0: {"CIOMS FORM": "3406, 60, 3850, 113"}}  # , "CIOMS FOF": "3406, 60, 3850, 113"}} #,
# 1: {"ADDITIONAL INFORMATION": "1655,262,2078,315"}}

img_paths = [
    "/home/suresh/backendservice/utility/uploads/Request-cacb0003-e071-4c7c-bb33-151abb78bbff/png/form_png-0.png"]
# ,
#             "/home/suresh/backendservice/utility/uploads/Request-cacb0003-e071-4c7c-bb33-151abb78bbff/png/form_png-1.png"]

req_folder = "/home/suresh/backendservice/utility/uploads/Request-cacb0003-e071-4c7c-bb33-151abb78bbff/"

image_shape = cv2.imread(img_paths[0], 0).shape

for img_path in img_paths:
    img_index = img_paths.index(img_path)
    image = cv2.imread(img_path, 0)
    for search_word in list(reference_strings_dict[img_index].keys()):
        coord_pos = reference_strings_dict[img_index][search_word]
        word_exist, angle, image, pixels_to_shift = align_image(req_folder, image, search_word, coord_pos, image_shape)
        if word_exist:
            #image = rotate_bound(image, angle)
            #image = cv2.resize(image, image_shape)
            rows, cols = image_shape

            M = cv2.getRotationMatrix2D((cols / 2, rows / 2), angle, 1)
            image = cv2.warpAffine(image, M, (cols, rows))
            # 1 -> horizontal pixels shift,  0 -> vertical pixels shift
            #image = shift_pixels_by_xy_axis(image, pixels_to_shift[0], 0)
            #image = shift_pixels_by_xy_axis(image, pixels_to_shift[1], 1)
            cv2.imwrite(img_path + "_" + search_word + "_" + str(angle) + ".png", image)
            break

'''
import cv2

img = cv2.imread("/home/suresh/backendservice/utility/uploads/Request-cacb0003-e071-4c7c-bb33-151abb78bbff/tmp/form_png-0.png",0)
image = rotate_bound(img, -90)
image = cv2.resize(image, image.shape)
cv2.imwrite("/home/suresh/backendservice/utility/uploads/Request-cacb0003-e071-4c7c-bb33-151abb78bbff/png/form_png-0.png",image)

'''


# 1. find given page is fixed or not
# 2.
