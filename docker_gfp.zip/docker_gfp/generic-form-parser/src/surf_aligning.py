import cv2
import pickle
import numpy as np
from os import path
from config import TEMPLATE_FOLDER


def save_surf_features(form_id, png_filepaths):
    for img_path in png_filepaths:
        surf = cv2.xfeatures2d.SURF_create()
        surf.setHessianThreshold(350)
        keypoints_list, features = surf.detectAndCompute(cv2.imread(img_path, 0), None)
        with open(path.join(TEMPLATE_FOLDER, form_id + "_" + str(png_filepaths.index(img_path)) + ".pickle"),
                  'wb') as fh:
            surf_data_all = []
            for keypoints in keypoints_list:
                surf_data = [keypoints.pt, keypoints.size, keypoints.angle, keypoints.response, keypoints.octave,
                             keypoints.class_id, features]
                print("surf_data = ",
                      [keypoints.pt, keypoints.size, keypoints.angle, keypoints.response, keypoints.octave,
                       keypoints.class_id])
                surf_data_all.append(surf_data)
            pickle.dump(surf_data_all, fh)


def load_surf_pickle(form_id, img_id):
    with open(path.join(TEMPLATE_FOLDER, form_id + "_" + str(img_id) + ".pickle"), 'rb') as pickle_file:
        data = pickle.load(pickle_file)
        keypoints_list = []
        for keypoints in data:
            surf_data = cv2.KeyPoint(keypoints[0][0], keypoints[0][1], keypoints[1], keypoints[2], keypoints[3],
                                     keypoints[4],
                                     keypoints[5])
            keypoints_list.append(surf_data)
        features = data[-1][6]

    return keypoints_list, features


def align_images(img1, form_id, img_id, img2):
    im1Reg = img1
    MIN_MATCH_COUNT = 10
    surf = cv2.xfeatures2d.SURF_create()
    surf.setHessianThreshold(350)
    # To be used in future
    #keypoints_tempate_img, features_template_img = load_surf_pickle(form_id, img_id)
    keypoints_img1, feactures_img1 = surf.detectAndCompute(img1, None)
    keypoints_img2, feactures_img2 = surf.detectAndCompute(img2, None)



    flann = cv2.FlannBasedMatcher()
    matches = flann.knnMatch(feactures_img1, feactures_img2, k=2)
    matches = sorted(matches, key=lambda x: x[0].distance)

    good = []
    for m, n in matches:
        if m.distance < 0.7 * n.distance:
            good.append(m)
    if (len(good) > MIN_MATCH_COUNT):
        src_pts = np.float32([keypoints_img1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        dst_pts = np.float32([keypoints_img2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
        M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
        height, width = img2.shape
        im1Reg = cv2.warpPerspective(img1, M, (width, height))

    return im1Reg


'''
from glob import glob

form_id = "8d4ec7b4-411f-11eb-b767-12414bf81c8f"
png_filepaths = glob(
    "/home/suresh/backendservice/utility/uploads/Request-d3d29bd0-9eda-4938-b741-cac4bfcebd36/png/*.png")
png_filepaths.sort()
# save_surf_features(form_id, png_filepaths)

img_id = "0"
keypoints, features = load_surf_pickle(form_id, img_id)
'''