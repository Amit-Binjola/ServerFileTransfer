#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 29 12:38:17 2020

@author: aditya
"""
from tesserocr import PyTessBaseAPI, PSM, OEM
from PIL import Image
import numpy as np
from os import path , system
from lxml import etree
import pandas as pd

# generate df from the hocr file
def generate_df_using_hocr(filepath):
    doc = etree.parse(filepath)
    words = []
    wordConf = []
    left_position = []
    top_position = []
    right_position = []
    bottom_position = []
    page_no = []
    width = []
    height = []
    page = []
    for doc_path in doc.xpath('//*'):
        if 'ocr_page' in doc_path.values():
            w, h = doc_path.values()[2].split('bbox 0 0 ')[1].split(';')[0].split(" ")
            width.append(w)
            height.append(h)
            page.append(doc_path.values()[1].split('_')[1])
        if 'ocrx_word' in doc_path.values():
            conf = [val for val in doc_path.values() if 'x_wconf' in val][0]
            wordConf.append(int(conf.split('x_wconf ')[1]))
            words.append(doc_path.text)
            cords = conf.split('; x_wconf ')[0].split('bbox ')[1].split(" ")
            left, top, right, bottom = cords
            left_position.append(left)
            top_position.append(top)
            right_position.append(right)
            bottom_position.append(bottom)
            page_no.append(doc_path.values()[1].split('word_')[1].split('_')[0])
    hocr_df = pd.DataFrame(
        {'word': words, 'confidence': wordConf, 'pageno': page_no, 'left': left_position, 'top': top_position,
         'right': right_position, 'bottom': bottom_position})
    pages_to_merge = pd.DataFrame({'width': width, 'height': height, 'pageno': page})
    hocr_df = pd.merge(hocr_df, pages_to_merge, on=['pageno'])
    hocr_df = hocr_df[['word', 'confidence', 'pageno', 'left', 'top', 'right', 'bottom', 'width', 'height']]
    hocr_df[hocr_df.columns[1:]] = hocr_df[hocr_df.columns[1:]].apply(pd.to_numeric, errors='coerce', axis=1)
    hocr_df['rownum'] = hocr_df.reset_index().index
    return (hocr_df)


def generate_hocr(req_folder, png_filepaths):
    hocr_df = pd.DataFrame()
    ocr_folder = path.join(req_folder, "ocr")
    for png_indx in range(len(png_filepaths)):
        png_filepath = png_filepaths[png_indx]
        output_hocr = path.join(ocr_folder, "form_" + str(png_indx))
        hocr_pdf_generator(png_filepath, output_hocr, dpi=300)
        output_hocr = output_hocr + ".hocr"
        if len(hocr_df) == 0:
            
            hocr_df = generate_df_using_hocr(output_hocr)
            hocr_df.pageno[0::] = int(png_indx)
        else:
            new_df = generate_df_using_hocr(output_hocr)
            new_df.pageno[0::] = int(png_indx)
            hocr_df = hocr_df.append(new_df)
    hocr_df = hocr_df.dropna(axis=0, how='any').reset_index(drop=True)

    return hocr_df


def hocr_pdf_generator(input_tiff, output_pdf, dpi=300):
    cmd = 'tesseract --dpi'
    cmd = cmd + ' ' + str(dpi)
    cmd = cmd + ' ' + input_tiff
    cmd = cmd + ' ' + output_pdf
    cmd = cmd + ' ' + 'pdf'
    cmd = cmd + ' ' + 'hocr'
    system(cmd)
    return "hocr and readable pdf file generated"


def apply_tesserocr(config_df, req_folder):
    splitted_coords = config_df.annotcoords.split(",")
    api = PyTessBaseAPI(psm=PSM.SINGLE_BLOCK)
    image_file = req_folder + "/png/form_png-" + str(int(config_df.pageno)) + ".png"
    image = Image.open(image_file)
    api.SetImage(image)
    api.SetRectangle(int(splitted_coords[0].strip()), int(splitted_coords[1].strip()), int(splitted_coords[2].strip()),
                     int(splitted_coords[3].strip()))
    ocrResult = ""
    if api.GetUTF8Text():
        ocrResult = api.GetUTF8Text().strip("\n")
    return ocrResult


def set_image_for_tesserocr_api(img):
    tess_ocr_api = PyTessBaseAPI(psm=PSM.AUTO, oem=OEM.LSTM_ONLY)
    tess_ocr_api.SetImage(img)
    return tess_ocr_api


# to extract text using text using tesserocr api
def extract_text_tesserOCR(png_file_path, coordinates_array):
    api = PyTessBaseAPI(psm=PSM.SINGLE_BLOCK)
    image = Image.open(png_file_path)
    api.SetImage(image)
    api.SetRectangle(coordinates_array['left'], coordinates_array['top'], coordinates_array['width'], coordinates_array['height'])
    ocr_result = api.GetUTF8Text()
    return ocr_result


def get_text_using_tesserocr(img, crop_region, tess_ocr_api):
    if type(img) is not np.ndarray:
        img = np.asarray(img)
    addition_pixels_to_consider = 8
    tess_ocr_api.SetRectangle(crop_region[0], crop_region[1], crop_region[2], crop_region[3])
    text = tess_ocr_api.GetUTF8Text()
    if text == "":
        tess_ocr_api.SetRectangle(crop_region[0] - addition_pixels_to_consider,
                                  crop_region[1] - addition_pixels_to_consider, crop_region[2],
                                  crop_region[3] + addition_pixels_to_consider)
        text = tess_ocr_api.GetUTF8Text()
    return text
