#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 17:25:15 2019

@author: suresh
"""

import cv2, re
import numpy
from config import CONFIG_JSON

PIXELS_TO_IGNORE = 2

def find_delimiter_string_existance(table_word_cords, row_delimiter, rownum):
    draw_row_line = False
    for iter_num in range(1, 4):
        given_word = " ".join(table_word_cords.iloc[rownum:rownum + iter_num]['word'])
        if given_word:
            if len(re.findall(row_delimiter, given_word.strip())) > 0:
                draw_row_line = True
                break
    return draw_row_line

# to draw row split line if row delimiter is given
def row_splitter_using_delimiter(ori_img, row_delimiter, table_word_cords, column_line_position, table_start_pos):
    EMPTY_SPACE = 15
    ADDITIONAL_COL_PIXELS = 75
    draw_row_line = False
    for rownum in range(len(table_word_cords)):
        if table_word_cords.iloc[rownum]['word']:
            if table_word_cords.iloc[rownum]['left'] < column_line_position[0][0] + ADDITIONAL_COL_PIXELS:
                draw_row_line = find_delimiter_string_existance(table_word_cords, row_delimiter, rownum)

        if draw_row_line:
            try:
                top = abs(table_word_cords.iloc[rownum]['top'] - table_start_pos)
                ori_img[top - EMPTY_SPACE, PIXELS_TO_IGNORE:-PIXELS_TO_IGNORE] = 0
            except:
                pass
            draw_row_line = False

    return ori_img


def draw_col_lines(img):
    IGNORE_PIXELS = 1
    for col_index in range(img.shape[1]):
        if numpy.count_nonzero(255-img[:, col_index]) > img.shape[0] * 0.5:
            img[IGNORE_PIXELS:-IGNORE_PIXELS, col_index-3:col_index] = 0
    return img


def row_splitter(original_img, binary_img, config_data, column_split_position):
    ROW_END = 10
    ROW_START = 13
    black_pixels = 0  # empty line space
    black_space_size = []
    IGNORE_COLUMN_PIXEL = 2
    row_indices_to_draw_line = []
    LINE_WIDTH = 6

    # finding empty space size among rows
    for row_no in range(0, binary_img.shape[0] - 1):
        if numpy.sum(binary_img[row_no, :]) < 255*LINE_WIDTH*len(column_split_position):
            black_pixels = black_pixels + 1
        else:
            if black_pixels != 0:
                black_space_size.append(black_pixels)
                row_indices_to_draw_line.append(row_no)
            black_pixels = 0

    # draw row split lines
    if len(black_space_size) == 1:
        original_img[row_indices_to_draw_line[0] - ROW_START:row_indices_to_draw_line[0] - ROW_END,
        IGNORE_COLUMN_PIXEL:-IGNORE_COLUMN_PIXEL] = 0
    elif len(black_space_size) > 1:
        for row_no in range(0, len(row_indices_to_draw_line)):
            draw = black_space_size[row_no]
            if draw >= config_data["spacebewteenrows"]:
                original_img[row_indices_to_draw_line[row_no] - ROW_START:row_indices_to_draw_line[row_no] - ROW_END,
                IGNORE_COLUMN_PIXEL:-IGNORE_COLUMN_PIXEL] = 0

    original_img[1:3, 2:-2] = 0  # drawing default top line

    return original_img


def table_with_column_lines(img, column_split_position, config_data, table_word_cords, table_start_pos):
    col_datatype = config_data["coltypes"]
    START_ROW = 2
    COLUMN_SKIP_PIXELS = 2
    END_ROW = 5
    SHAPE_THRESH = 4
    SKIP_PIXELS = 3
    try:
        img_cpy = ori_img = img.copy()
        thresh, bw_img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

        BLOCK_SIZE, THRESHOLD_CONSTANT = 25, 1
        if config_data['rowdelimiter'] in ['regex', 'Regex', 'REGEX']:
            ori_img = row_splitter_using_delimiter(img, config_data['rowdelimiter'], table_word_cords, column_split_position,
                                                   table_start_pos)
        else:
            ori_img = row_splitter(img, bw_img, config_data, column_split_position)
        ori_img = draw_col_lines(ori_img)
        # default top row line
        ori_img[START_ROW:END_ROW, COLUMN_SKIP_PIXELS:-COLUMN_SKIP_PIXELS] = 0
        # default bottom row line
        ori_img[-END_ROW:-START_ROW, COLUMN_SKIP_PIXELS:-COLUMN_SKIP_PIXELS] = 0
    except:
        ori_img = False

    return ori_img

'''
img = cv2.imread("0.8981274003524593/.png", 0)
thresh, binary_img = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
cv2.imwrite("/home/suresh/backendservice/utility/uploads/Request-adbaffb1-ff41-4f72-a8d1-4b6bf7d143f9/cropped_table/op1.png", binary_img)
bw_img = row_splitter(img, binary_img, "")
bw_img = draw_col_lines(bw_img)
cv2.imwrite("/home/suresh/backendservice/utility/uploads/Request-adbaffb1-ff41-4f72-a8d1-4b6bf7d143f9/cropped_table/op2.png", bw_img)
'''