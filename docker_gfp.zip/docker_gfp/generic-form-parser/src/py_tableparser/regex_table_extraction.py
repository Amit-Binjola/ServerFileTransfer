import pytesseract
import re

# this is to split given OCR text into rows
def RegexBasedTableRowSplitter(text, row_pattern):
    row_list = []
    flag = True
    table_raw_data = text.split("\n")
    table_raw_data = list(filter(None, table_raw_data))
    if table_raw_data!=[]:
        if row_pattern == "\n" or row_pattern == "\\n":
            row_list = table_raw_data
        else:
            row = ""
            for row_data in table_raw_data:
                row_match = re.search(row_pattern, row_data)
                if row_match:
                    if flag:
                        row = row_data
                        flag = False
                    else:
                        row_list.append(row)
                        row = row_data
                else:
                    if flag == False:
                        row = row + " " + row_data
            row_list.append(row)
    return row_list

# this is to split given OCR text into columns
def RegexBasedTableColumnSplitter(row_list, column_pattern):
    table_list = []
    patterns = column_pattern.split("||")
    for row_data in row_list:
        col_data = []
        for col_pattern in patterns:
            matched_col_data = re.search(col_pattern, row_data)
            if matched_col_data == None:
                value = ""
            else:
                value = matched_col_data.group()
            col_data.append(value)
        table_list.append(col_data)
    return table_list


# method calling starts form here
def RegexBasedTableParser(image, config_data):
    row_pattern = config_data["rowdelimiter"].replace("regex::", "")
    column_pattern = config_data["columndelimiter"].replace("regex::", "")
    text = pytesseract.image_to_string(image)
    row_list = RegexBasedTableRowSplitter(text, row_pattern)
    table_data = RegexBasedTableColumnSplitter(row_list, column_pattern)
    return table_data


"""
image1 = Image.open("/home/akshatha/Desktop/img3.png")
image2 = Image.open("/home/akshatha/Desktop/img2.png")
Table_data1 = RegexBasedTableParser(image1, "^#\d{1,2}\s*\)", "(^#\d{1,2}\s*\))||\).*\(||\(.*\)||;.*$")
Table_data2 = RegexBasedTableParser(image2, "\n", "^.*\s\[||\s\[.*$")
print(Table_data1)
print(Table_data2)
"""