#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 15 16:46:29 2020

@author: suresh
"""

import re
import cv2
import numpy as np
from os import path
from config import CONFIG_JSON

if CONFIG_JSON["ocr"]["required"]:
    OCR_tool = CONFIG_JSON["ocr"]["tools"][0].lower()
    if OCR_tool == "tesserocr":
        from tesserocr_utilities import extract_text_tesserOCR, generate_hocr
    elif OCR_tool == "abbyy":
        from AbbyyExtract import getmultizonal, getZonalOCR, generate_abbyy_hocr


def regex_based_row_column_split(img, row_pattern, column_patten):
    ocr_text = ""
    output = []
    for row_text in ocr_text:
        output.append(re.split("[[]", row_text))
    return output

# to draw row split line if row delimiter is given
def row_splitter_using_delimiter(req_folder, config_data, ori_img, row_delimiter, table_word_cords, table_start_pos):
    img_path = path.join(req_folder, "img.png")
    cv2.imwrite(img_path, ori_img)
    if OCR_tool == "tesserocr":
        table_word_cords = generate_hocr(req_folder, [img_path])
    elif OCR_tool == "abbyy":
        table_word_cords = generate_abbyy_hocr(req_folder, [img_path])

    PADDING_SPACE = 5  # this values should come from UI
    draw_row_line = False
    LEFT_MARGIN_THRESH = 150
    for rownum in range(len(table_word_cords)):
        if table_word_cords.iloc[rownum]['word'] and table_word_cords.iloc[rownum]['left'] < LEFT_MARGIN_THRESH:
            if rownum + 2 < len(table_word_cords):
                given_word = " ".join(table_word_cords.iloc[rownum:rownum + 3]['word']).strip().replace("  ", " ")
            elif rownum + 1 < len(table_word_cords):
                given_word = " ".join(table_word_cords.iloc[rownum:rownum + 2]['word']).strip().replace("  ", " ")
            else:
                given_word = " ".join(table_word_cords.iloc[rownum:rownum + 1]['word']).strip().replace("  ", " ")

            if len(re.findall(row_delimiter, given_word, re.IGNORECASE)) > 0:
                draw_row_line = True

        if draw_row_line:
            try:
                top = abs(table_word_cords.iloc[rownum]['top']) - PADDING_SPACE
                ori_img[top, 2:-2] = 0
            except:
                pass
            draw_row_line = False

    return ori_img


def remove_header_underline(binary_img):
    START_ROW = 1
    IGNORE_COLUMN_PIXEL = 2
    NUMBER_OF_ROWS_AFTER = 3
    NUMBER_OF_ROWS_BEFORE = 3
    header_underline_indx = 0
    BOTTOM_ROWS_TO_IGNORE = 5
    MIN_ROW_SIZE_THRESHOLD = 10
    WHITE_PIXEL_INTENSITY = 255
    ROW_THRESH = 0.3
    COLUMN_THRESH = 0.7
    for row_no in range(START_ROW, binary_img.shape[0] - BOTTOM_ROWS_TO_IGNORE):
        if np.sum(WHITE_PIXEL_INTENSITY - binary_img[row_no, int(binary_img.shape[1] * ROW_THRESH):int(
                binary_img.shape[1] * COLUMN_THRESH)]) == 0:
            if row_no > MIN_ROW_SIZE_THRESHOLD:
                header_underline_indx = row_no
                binary_img[row_no - NUMBER_OF_ROWS_BEFORE:row_no + NUMBER_OF_ROWS_AFTER,
                IGNORE_COLUMN_PIXEL:-IGNORE_COLUMN_PIXEL] = 0
                break
    return binary_img, header_underline_indx


def get_img_with_column_lines(img, column_split_position):
    column_line_position = []
    LINE_WIDTH = 1
    for position in column_split_position:
        column_line_position.append(position[0])
        img[:, position[0]] = 0
    # appending last column line position
    if len(column_split_position) > 0:
        last_line_position = column_split_position[-1][0] + column_split_position[-1][2]
        img[:, last_line_position - 1] = 0
        column_line_position.append(last_line_position)
    return img, column_line_position


def row_splitter(original_img, binary_img, config_data):
    ROW_END = 10
    ROW_START = 13
    black_pixels = 0  # empty line space
    black_space_size = []
    IGNORE_COLUMN_PIXEL = 2
    row_indices_to_draw_line = []

    # finding empty space size among rows
    for row_no in range(0, binary_img.shape[0] - 1):
        if np.sum(binary_img[row_no]) == 0:
            black_pixels = black_pixels + 1
        else:
            if black_pixels != 0:
                black_space_size.append(black_pixels)
                row_indices_to_draw_line.append(row_no)
            black_pixels = 0

    # draw row split lines
    if len(black_space_size) == 1:
        original_img[row_indices_to_draw_line[0] - ROW_START:row_indices_to_draw_line[0] - ROW_END,
        IGNORE_COLUMN_PIXEL:-IGNORE_COLUMN_PIXEL] = 0
    elif len(black_space_size) > 1:
        #threshold = min(black_space_size)
        for row_no in range(0, len(row_indices_to_draw_line)):
            draw = black_space_size[row_no]
            #if draw > threshold + config_data["spacebewteenrows"]:
            if draw >= config_data["spacebewteenrows"]:
                original_img[row_indices_to_draw_line[row_no] - ROW_START:row_indices_to_draw_line[row_no] - ROW_END,
                IGNORE_COLUMN_PIXEL:-IGNORE_COLUMN_PIXEL] = 0

    original_img[1:3, 2:-2] = 0  # drawing default top line

    return original_img


def table_without_lines(req_folder, config_data, img, is_header_underline_exist, column_split_position,
                        table_word_cords, table_start_pos):
    LINE_WIDTH = 2
    ori_img = img.copy()
    thresh, binary_img = cv2.threshold(img, 10, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    header_underline_index = 0
    if is_header_underline_exist:
        binary_img, header_underline_index = remove_header_underline(binary_img)

    if header_underline_index:
        ori_img[header_underline_index - LINE_WIDTH:header_underline_index + LINE_WIDTH, LINE_WIDTH:-LINE_WIDTH] = 0
        binary_img[header_underline_index - LINE_WIDTH:header_underline_index + LINE_WIDTH, LINE_WIDTH:-LINE_WIDTH] = 0

    ori_img, column_line_position = get_img_with_column_lines(img, column_split_position)

    if "regex" in config_data['rowdelimiter']:
        row_delimiter = config_data['rowdelimiter'].replace("regex::", "")
        column_delimiter = config_data['columndelimiter'].replace("regex::", "")
        ori_img = row_splitter_using_delimiter(req_folder, config_data, ori_img, row_delimiter, table_word_cords, table_start_pos)
    else:
        ori_img = row_splitter(ori_img, binary_img, config_data)

    return ori_img
