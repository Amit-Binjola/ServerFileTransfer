#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 14:03:57 2019

@author: suresh
"""

import cv2
import numpy
from config import CONFIG_JSON


def morphing_image(img):
    # Detect vertical and horizontal lines
    original_img = img.copy()
    BLOCK_SIZE = 25
    THRESHOLD_CONSTANT = 0
    PIXELS_TO_IGNORE = 2
    ADDITIONAL_PIXELS_TO_CONSIDER = 1
    DRAW_ROW_LINE_SPACE_THRESH = 12

    img_bin = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, BLOCK_SIZE,
                                    THRESHOLD_CONSTANT)

    # A horizontal kernel of (kernel_length X 1), which will help to detect all the horizontal line from the image.
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (
        img.shape[1] // CONFIG_JSON["table_constants"]["KERNEL_LENGTH"],
        CONFIG_JSON["table_constants"]["KERNEL_HEIGHT"]))

    # Morphological operation to detect horizontal lines from an image
    horizontal_lines_img = cv2.dilate(img_bin, horizontal_kernel, iterations=6)
    img = cv2.add(img, horizontal_lines_img)

    # draw row lines
    index_tmp = 0
    for row_index in range(0, img.shape[0]):
        if numpy.sum(255 - img[row_index, :]) > 0:  # 255 means WHITE color pixel
            if abs(row_index - index_tmp) > DRAW_ROW_LINE_SPACE_THRESH:
                index_tmp = row_index
                original_img[row_index:row_index + ADDITIONAL_PIXELS_TO_CONSIDER,
                PIXELS_TO_IGNORE:-PIXELS_TO_IGNORE] = 0

    return original_img


def draw_column_splitter_lines(img, column_split_line_pos):
    for pos in column_split_line_pos:
        img[:, pos[0] - 1:pos[0] + 1] = 0
    if len(column_split_line_pos) > 0:
        right_most_col_line = column_split_line_pos[-1][0] + column_split_line_pos[-1][2]
        img[:, right_most_col_line] = 0
    return img


def table_with_hlines(img, column_split_line_pos):
    PIXELS_TO_IGNORE = 2
    SHAPE_THRESHOLD = 1.8

    if img is not None:
        img = morphing_image(img)
        img_cpy = img.copy()
        thresh, binary_img = cv2.threshold(img, 10, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        binary_img = 255 - binary_img

        # draw row splitter lines
        for row_num in range(binary_img.shape[0]):
            if numpy.sum(binary_img[row_num,
                         int(img.shape[0] / SHAPE_THRESHOLD):-int(img.shape[0] / SHAPE_THRESHOLD)]) == 0:
                binary_img[row_num - 1, PIXELS_TO_IGNORE:-PIXELS_TO_IGNORE] = 0
                img_cpy[row_num - PIXELS_TO_IGNORE:row_num + PIXELS_TO_IGNORE, PIXELS_TO_IGNORE:-PIXELS_TO_IGNORE] = 255

        img = draw_column_splitter_lines(img, column_split_line_pos)

        # default top and bottom horizontal line
        img[PIXELS_TO_IGNORE, PIXELS_TO_IGNORE:-PIXELS_TO_IGNORE] = 0
        img[-PIXELS_TO_IGNORE, PIXELS_TO_IGNORE:-PIXELS_TO_IGNORE] = 0
        # right column line
        img[PIXELS_TO_IGNORE:-PIXELS_TO_IGNORE, -PIXELS_TO_IGNORE] = 0
    else:
        img = False

    return img
