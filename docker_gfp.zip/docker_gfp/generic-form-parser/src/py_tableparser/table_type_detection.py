#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 14:47:31 2019

@author: suresh
"""

import cv2
import numpy
from config import CONFIG_JSON

THRESHOLD_CONSTANT = CONFIG_JSON["table_type_detector_params"]["THRESHOLD_CONSTANT"]
BLOCK_SIZE = CONFIG_JSON["table_type_detector_params"]["BLOCK_SIZE"]

def no_of_columns(bw_img, pixels_to_ignore):
    column_line_count = 0
    index_flg = 0
    for row_num in range(0, bw_img.shape[1]-30):
        if numpy.sum(bw_img[pixels_to_ignore:-pixels_to_ignore, row_num]) == 0:
            if row_num - index_flg > 10:                
                column_line_count = column_line_count+1
            index_flg = row_num
    return column_line_count


def no_of_rows(bw_img, pixels_to_ignore, table_header_separator): 
    row_line_count = 0
    index_flg = 0
    NEXT_ROW_FINDER_THRESHOLD = 10
    START_PIXEL_THRESH = 0.8
    start_pixel = bw_img.shape[0] - int(bw_img.shape[0]*START_PIXEL_THRESH)
    end_pixel = bw_img.shape[0]
                    
    if end_pixel > 1:
        for row_num in range(start_pixel, end_pixel):            
            if numpy.sum(bw_img[row_num, pixels_to_ignore:-pixels_to_ignore]) == 0:
                if row_num - index_flg > NEXT_ROW_FINDER_THRESHOLD:
                    row_line_count = row_line_count+1
                index_flg = row_num

    return row_line_count


def find_table_type(table_img, table_header_separator):
    if table_img is not None:
        if type(table_img) != numpy.ndarray:
            table_img = numpy.ndarray(table_img)
            
        table_info = {}
        table_type = ""
        row_line_count = ""
        column_line_count = ""
        
        bw_img = morphing_table_image(table_img, BLOCK_SIZE, THRESHOLD_CONSTANT)
        pixels_to_ignore = 3
        
        column_line_count = no_of_columns(bw_img, pixels_to_ignore)
        row_line_count = no_of_rows(bw_img, pixels_to_ignore, table_header_separator)
        table_type = ""
        if row_line_count > 0 and column_line_count > 0:
            # table with Vertical and Horizontal lines
            table_category = [1,1]
            table_type = 'gridded'
        
        elif row_line_count > 0 and column_line_count == 0:
            # table with Horizontal lines
            table_category = [1,0]
            table_type = 'horizontal'
            
        elif row_line_count == 0 and column_line_count > 0:
            # table with Vertical lines
            table_category = [0,1]
            table_type = 'vertical'
        
        elif (row_line_count == -1 or row_line_count == 0) and column_line_count == 0:
            # table without V_H lines
            table_category = [0,0]
            table_type = 'virtual'
        else:
            table_type = "table not found"
            table_category = 0    
    else:
        table_category = "Unable to read image, try again"
    
    table_info['table'] = table_type
    table_info['table_type'] = table_category
    table_info['no_of_rows'] = row_line_count
    table_info['no_of_columns'] = column_line_count
    
    return table_info


def morphing_table_image(img, BLOCK_SIZE, THRESHOLD_CONSTANT):
    # Detect vertical and horizontal lines
    img_bin = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, BLOCK_SIZE, THRESHOLD_CONSTANT)   
    img_bin = 255-img_bin  # Invert the image
    KERNEL_SIZE_THRESHOLD = 50
    # Defining a kernel length
    kernel_length = img.shape[1]//KERNEL_SIZE_THRESHOLD
    # A verticle kernel of (1 X kernel_length), which will detect all the verticle lines from the image.
    verticle_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, kernel_length))
    
    # A horizontal kernel of (kernel_length X 1), which will help to detect all the horizontal line from the image.
    hori_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_length, 1))
    
    # A kernel of (3 X 3) ones.
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    
    # Morphological operation to detect verticle lines from an image
    img_temp1 = cv2.erode(img_bin, verticle_kernel, iterations=2)
    
    verticle_lines_img = cv2.dilate(img_temp1, verticle_kernel, iterations=15)
    #cv2.imwrite("verticle_lines.jpg",verticle_lines_img)

    # Morphological operation to detect horizontal lines from an image
    img_temp2 = cv2.erode(img_bin, hori_kernel, iterations=2)
    horizontal_lines_img = cv2.dilate(img_temp2, hori_kernel, iterations=15)
    #cv2.imwrite("horizontal_lines.jpg",horizontal_lines_img)
    
    # Weighting parameters, this will decide the quantity of an image to be added to make a new image.
    alpha = 0.5
    beta = 1.0 - alpha
    # This function helps to add two image with specific weight parameter 
    #to get a third image as summation of two image.
    img_final_bin = cv2.addWeighted(verticle_lines_img, alpha, horizontal_lines_img, beta, 0.0)
    img_final_bin = cv2.erode(~img_final_bin, kernel, iterations=2)
    
    (thresh, img_final_bin) = cv2.threshold(img_final_bin, 120, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    
    return img_final_bin

    