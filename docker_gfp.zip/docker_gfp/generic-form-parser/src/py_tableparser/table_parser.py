#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb  6 10:26:13 2020

@author: suresh
"""

import cv2
import sys
import numpy as np
from os import path
from PIL import Image
from random import random
from config import CONFIG_JSON, TRUE_CHECK

if "/".join(path.dirname(path.abspath(__file__)).split("/")[:-1]) not in sys.path:
    sys.path.append("/".join(path.dirname(path.abspath(__file__)).split("/")[:-1]))
from checkbox_classifier import checkbox_classifier

if CONFIG_JSON["ocr"]["required"]:
    OCR_tool = CONFIG_JSON["ocr"]["tools"][0].lower()
    table_OCR_tool = CONFIG_JSON["table_parameters"]["ocr"][0].lower()
    table_checkbox_OCR_tool = CONFIG_JSON["table_parameters"]["table_checkbox_OCR_tool"][0].lower()
    if OCR_tool == "tesserocr" or table_OCR_tool == "tesserocr":
        from tesserocr_utilities import get_text_using_tesserocr, set_image_for_tesserocr_api
    if OCR_tool == "abbyy" or table_checkbox_OCR_tool == "abbyy":
        from AbbyyExtract import getZonalOCR, getCheckMark


# returns the index of columns that contains checkbox, checkbox type
def find_checkbox_column_indices(col_datatype):
    col_type = col_datatype.split("||")
    indices = []
    cbox_type = []
    text_and_cbox_column = []
    for col_num in range(0, len(col_type)):
        if col_type[col_num].lower() in ["checkbox", "rectangle_checkbox", "rectanglecheckbox", "rectangle checkbox",
                                         "circle checkbox",
                                         "unusual-round-hand-drawn-y", "unusual-round-hand-drawn-n",
                                         "uneven_circle_checkbox_handwritten"]:
            indices.append(col_num)
            cbox_type.append(col_type[col_num])
        elif col_type[col_num].lower() in ["text_and_checkbox"]:
            text_and_cbox_column.append(col_num)

    return indices, cbox_type, text_and_cbox_column


def columnwise_OCR_text(table_img, cbox_column, col_wise_bbox, tess_ocr_api):
    all_column_text = []
    for col_num in range(0, len(col_wise_bbox)):
        if col_num not in cbox_column:
            row_text = []
            for row_pos in range(0, len(col_wise_bbox[col_num])):
                text = get_text_using_tesserocr(table_img, col_wise_bbox[col_num][row_pos], tess_ocr_api)
                row_text.append(text)
            all_column_text.append(row_text)
    return all_column_text


def columnwise_bbox_pos(boundingbox_pos):
    col_wise_bbox = []
    temp = []
    for bbox_index in range(0, len(boundingbox_pos) - 1):
        if abs(boundingbox_pos[bbox_index + 1][0] - boundingbox_pos[bbox_index][0]) < CONFIG_JSON["table_constants"][
            "ROW_BREAKER_THRESHOLD"]:
            temp.append(boundingbox_pos[bbox_index])
        else:
            temp.append(boundingbox_pos[bbox_index])
            col_wise_bbox.append(temp)
            temp = []
    return col_wise_bbox


def get_columnwise_checkbox_status(req_folder, table_img, columnwise_bbox, cbox_columns, checkbox_type):
    table_img = np.array(table_img)
    columnwise_cbox_status = []
    cbox_type_index = 0
    for c_index in cbox_columns:
        cbox_temp = []
        for index in range(0, len(columnwise_bbox[c_index])):
            cbox_pos = columnwise_bbox[c_index][index]
            cbox_img = table_img[cbox_pos[1]:cbox_pos[1] + cbox_pos[3], cbox_pos[0]:cbox_pos[0] + cbox_pos[2]]
            cbox_path = path.join(req_folder, "checkboxes/" + str(cbox_pos) + ".png")
            cv2.imwrite(cbox_path, cbox_img)

            if table_checkbox_OCR_tool == "abbyy":
                x1 = 1
                y1 = 1
                x2 = cbox_img.shape[1]
                y2 = cbox_img.shape[0]
                cbox_status = getCheckMark(cbox_path, x1, y1, x2, y2)
            else:
                cbox_status = checkbox_classifier(cbox_img, checkbox_type[cbox_type_index])
                if cbox_status == []:
                    cbox_status = "0"
                if type(cbox_status) != int:
                    if len(cbox_status) > 0:
                        cbox_status = cbox_status[0]

            if cbox_status:
                cbox_status = str(cbox_status)
            cbox_temp.append(cbox_status)
        columnwise_cbox_status.append(cbox_temp)
        cbox_type_index = cbox_type_index + 1

    return columnwise_cbox_status


def get_rowwise_bbox(boundingbox_pos):
    temp = []
    all_pos = []
    pos_list = []  # row wise bbox list
    box_index = 0
    boundingbox_pos.append(boundingbox_pos[-1])
    for position in boundingbox_pos:
        position = list(position)
        all_pos.append(position)
        if box_index == 0:
            temp.append(position)
        elif box_index > 0 and box_index < len(boundingbox_pos) - 1:
            if abs(position[1] - all_pos[box_index - 1][1]) <= CONFIG_JSON["table_constants"]["ROW_BREAKER_THRESHOLD"]:
                position[1] = all_pos[box_index - 1][1]
                temp.append(position)
            else:
                pos_list.append(temp)
                temp = []
                temp.append(position)
        elif box_index == len(boundingbox_pos) - 1:
            pos_list.append(temp)
        box_index = box_index + 1

    return pos_list


def get_column_width(column_split_position):
    cell_width_size_all = []
    for pos in column_split_position:
        cell_width_size_all.append(abs(float(pos[2]) - float(pos[0])))
    width_max = max(cell_width_size_all) + 30
    width_min = min(cell_width_size_all) - 30
    return width_min, width_max


def filtering_unwanted_cells(boundingbox_pos, column_split_position):
    width_min, width_max = get_column_width(column_split_position)
    bbox_pos = []
    for pos in boundingbox_pos:
        if 0 not in pos:
            if pos[3] >= CONFIG_JSON["table_constants"]["HEIGHT_MIN"]:
                if abs(float(pos[2]) - float(pos[0])) >= width_min and abs(
                        float(pos[2]) - float(pos[0])) <= width_max and abs(float(pos[1]) - float(pos[3])) >= \
                        CONFIG_JSON["table_constants"]["HEIGHT_MIN"]:
                    bbox_pos.append(pos)
    return bbox_pos


def morphing_image(img, BLOCK_SIZE, THRESHOLD_CONSTANT):
    # Detect vertical and horizontal lines
    img = np.array(img)
    img_bin = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, BLOCK_SIZE,
                                    THRESHOLD_CONSTANT)
    img_bin = 255 - img_bin  # Invert the image
    kernel_length = int(img.shape[1] // CONFIG_JSON["table_constants"]["KERNEL_LENGTH"])
    vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, kernel_length))
    horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_length, 1))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    img_temp1 = cv2.erode(img_bin, vertical_kernel, iterations=1)
    vertical_lines_img = cv2.dilate(img_temp1, vertical_kernel, iterations=1)
    img_temp2 = cv2.erode(img_bin, horizontal_kernel, iterations=1)
    horizontal_lines_img = cv2.dilate(img_temp2, horizontal_kernel, iterations=1)

    alpha = 0.5
    beta = 1.0 - alpha
    img_final_bin = cv2.addWeighted(vertical_lines_img, alpha, horizontal_lines_img, beta, 0.0)
    img_final_bin = cv2.erode(~img_final_bin, kernel, iterations=1)
    (thresh, img_final_bin) = cv2.threshold(img_final_bin, 120, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

    return img_final_bin


def apply_columnwise_ocr(req_folder, table_img, columnwise_bbox_text, tess_ocr_api):
    ocr_text = []
    for col_num in range(len(columnwise_bbox_text)):
        col_text = []
        for cell_num in range(len(columnwise_bbox_text[col_num])):
            if table_OCR_tool.lower() == "tesserocr" or table_OCR_tool.lower() == "":
                table_cell_pos = columnwise_bbox_text[col_num][cell_num]
                cv2.imwrite(path.join(req_folder, str(table_cell_pos) + ".png"), np.asarray(table_img)[table_cell_pos[1]:
                                                                        table_cell_pos[1] + table_cell_pos[3],
                                                         table_cell_pos[0]: table_cell_pos[0] + table_cell_pos[2]])
                ocr_output = get_text_using_tesserocr(table_img, table_cell_pos, tess_ocr_api)
            elif table_OCR_tool.lower() == 'abbyy':
                bbox_dict = {'left': columnwise_bbox_text[col_num][cell_num][0],
                             'top': columnwise_bbox_text[col_num][cell_num][1],
                             'width': columnwise_bbox_text[col_num][cell_num][2],
                             'height': columnwise_bbox_text[col_num][cell_num][3]}
                if type(table_img) != np.array:
                    table_img = np.array(table_img)
                cell_img_path = path.join(req_folder, "bbox_region.png")
                cv2.imwrite(cell_img_path, table_img)
                ocr_output = getZonalOCR(cell_img_path, bbox_dict, "normal", "zonal", "English")
            ocr_output = ocr_output.replace("\n", "").replace("  ", " ")
            if ocr_output == "  ":
                ocr_output = ""
            col_text.append(ocr_output)
        ocr_text.append(col_text)
    return ocr_text


def draw_row_column_lines(img_final_bin, column_split_position):
    given_col_split_pos = []
    for pos in column_split_position:
        given_col_split_pos.append(int(float(pos[0])))
        if pos == column_split_position[-1]:
            given_col_split_pos.append(int(float(pos[0])) + int(float(pos[2])))

    pos_all = []
    for pos in given_col_split_pos:
        pos_all.append(pos)
        for val in range(pos, pos + 25):
            pos_all.append(val)
        start_pos = pos-25
        if start_pos < 0:
            start_pos = 0
        for val in range(start_pos, pos):
            pos_all.append(val)

    binimg = np.ones((img_final_bin.shape[0], img_final_bin.shape[1])) * 255
    # draw column lines
    SKIP_INDEX = 0
    LINE_WIDTH = 1

    for index in range(SKIP_INDEX, img_final_bin.shape[1] - SKIP_INDEX):
        total_cnt = list(~img_final_bin[:, index]).count(255)
        if total_cnt >= img_final_bin.shape[0] * 0.65:
            if index in pos_all:
                binimg[LINE_WIDTH:-LINE_WIDTH, index] = 0

    # draw row lines
    for index in range(1, img_final_bin.shape[0] - SKIP_INDEX):
        total_cnt = list(~img_final_bin[index, :]).count(255)
        if total_cnt >= img_final_bin.shape[1] * 0.65:
            binimg[index, LINE_WIDTH:-LINE_WIDTH] = 0

    binimg[1:-1, -2] = 0
    binimg[1:-1, 2] = 0
    return binimg


# to handle cells which contains both freetext and checkbox
# custom method for amgen
def hangling_text_and_checkbox_cell(req_folder, table_img, columnwise_bbox, text_and_cbox_column_index):
    table_img = np.array(table_img)
    checkbox_type = "rectangle_checkbox"
    classification = []
    if len(text_and_cbox_column_index) > 0:
        cbox_pos = columnwise_bbox[text_and_cbox_column_index[0]]
        for c_index in range(0, len(cbox_pos)):
            cbox_img = table_img[cbox_pos[c_index][1]:cbox_pos[c_index][1] + cbox_pos[c_index][3],
                       cbox_pos[c_index][0]:cbox_pos[c_index][0] + cbox_pos[c_index][2]]
            row = int(cbox_img.shape[0] * 0.3)
            col = int(cbox_img.shape[1] * 0.4)
            cbox_img = cbox_img[row + 180:-50, 80:col + 10]
            table_cb_img_path = path.join(req_folder,
                                          "table_checkbox_" + str(c_index) + "_" + str(cbox_pos[c_index]) + ".png")
            cv2.imwrite(table_cb_img_path, cbox_img)
            if table_OCR_tool == "abbyy":
                x1 = 1
                y1 = 1
                x2 = cbox_img.shape[1]
                y2 = cbox_img.shape[0]
                status = getCheckMark(table_cb_img_path, x1, y1, x2, y2)

            elif table_OCR_tool == "tesserocr":
                status = checkbox_classifier(cbox_img, checkbox_type)

            if status == []:
                status = "0"
            elif len(status) > 0:
                status = status[0]
            if status:
                status = str(status)
            classification.append(status)

    return classification

# convert disjoint row/columne line to joint lines
def handling_disjoint_row_lines(table_img):
    LINE_WIDTH = 1
    table_img_bin = cv2.Canny(table_img, 100, 200)

    for index in range(1, table_img.shape[0] - 1):
        if list(table_img_bin[index, :]).count(255) >= table_img.shape[1] * 0.65:
            table_img[index:index + 2, LINE_WIDTH:-LINE_WIDTH] = 0

    for index in range(1, table_img.shape[1] - 1):
        if list(table_img_bin[:, index]).count(255) >= table_img.shape[0] * 0.65:
            table_img[LINE_WIDTH:-LINE_WIDTH, index:index + 2] = 0

    # Drawing default top row line
    table_img[1, LINE_WIDTH:-LINE_WIDTH] = 0
    table_img[-3:-1, LINE_WIDTH:-LINE_WIDTH] = 0

    # Drawing default column lines
    table_img[LINE_WIDTH:-LINE_WIDTH, 1:3] = 0
    table_img[LINE_WIDTH:-LINE_WIDTH, -3:-1] = 0

    return table_img


def get_contours(req_folder, img_final_bin, neighborhood_pixel_diameter, column_split_position):
    COL_TOP_INDEX = ROW_TOP_INDEX = 1
    COL_BOTTOM_INDEX = ROW_BOTTOM_INDEX = -3
    LINE_WIDTH = 2
    # DRAWING DEFAULT TOP AND BOTTOM ROW LINES
    img_final_bin[ROW_TOP_INDEX, LINE_WIDTH:-LINE_WIDTH] = 0
    img_final_bin[ROW_BOTTOM_INDEX, LINE_WIDTH:-LINE_WIDTH] = 0
    # DRAWING DEFAULT LEFT AND RIGHT COLUMN LINES
    img_final_bin[LINE_WIDTH:-LINE_WIDTH, COL_TOP_INDEX] = 0
    img_final_bin[LINE_WIDTH:-LINE_WIDTH, COL_BOTTOM_INDEX] = 0
    bin_img_path = path.join(req_folder + "/cropped_images/" + str(column_split_position[0][1]) + "_" + str(
        column_split_position[0][2]) + "_" +
                             str(neighborhood_pixel_diameter) + "_final.png")
    cv2.imwrite(bin_img_path, img_final_bin)
    img_final_bin = cv2.imread(bin_img_path, 0)
    #cv2.imshow("img_final_bin", img_final_bin)
    #cv2.waitKey(0)
    #cv2.destroyWindow("img_final_bin")

    # Find contours for image, which will detect all the boxes (table cells)
    try:
        image_filtered, contours, hierarchy = cv2.findContours(img_final_bin, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    except:
        contours, hierarchy = cv2.findContours(img_final_bin, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Sort all the contours by top to bottom
    boundingbox_pos = [cv2.boundingRect(c) for c in contours]  # left, top, width, height
    pos_all = [pos for pos in boundingbox_pos if 0 not in pos]

    return pos_all


def row_bbox_filtered(row_wise_bbox_pos, col_len):
    # remove rows when its column count is not equal to actual no of columns in table
    row_wise_bbox_pos_filtered = []
    for row in row_wise_bbox_pos:
        row.sort()
        if len(row) == col_len:
            row_wise_bbox_pos_filtered.append(row)
    return row_wise_bbox_pos_filtered


def height_pos_updated(row_wise_bbox_pos_filtered):
    # to merge cells
    bbox_height_updated = []
    for row in row_wise_bbox_pos_filtered:
        height_all = []
        for height in row:
            height_all.append(height[-1])
        height_mean = np.mean(height_all)
        height_max = max(height_all)

        height_updated_rows = []
        for value in row:
            if value[-1] < height_mean:
                value[-1] = height_max
            height_updated_rows.append(value)
        bbox_height_updated.append(height_updated_rows)
    return bbox_height_updated


def get_boundingbox_pos_filtered(boundingbox_pos, column_split_position):
    WIDTH_PADDING_THRESH = 30
    WIDTH_MAX_PADDING_THRESH = 310
    cell_width_size_all = [float(pos[2]) for pos in column_split_position]
    width_max = max(cell_width_size_all) + WIDTH_MAX_PADDING_THRESH
    width_min = min(cell_width_size_all) - WIDTH_PADDING_THRESH
    LEFT_MARGIN = 30
    boundingbox_pos_filtered = []
    for pos in boundingbox_pos:
        if 0 not in pos and float(pos[3]) >= CONFIG_JSON["table_constants"]["HEIGHT_MIN"]:
            if float(pos[2]) >= width_min and float(pos[2]) <= width_max:
                if pos[0] >= float(column_split_position[0][0]) - LEFT_MARGIN:
                    boundingbox_pos_filtered.append(pos)

    return boundingbox_pos_filtered


def get_columnwise_bbox(col_len, row_wise_bbox_pos_filtered, bbox_pos):
    if len(bbox_pos) == 0:
        bbox_pos = row_wise_bbox_pos_filtered

    columnwise_bbox = []
    for col_index in range(0, col_len):
        col = []
        for index in range(0, len(bbox_pos)):
            col.append(bbox_pos[index][col_index])
        col.sort(key=lambda x: x[1])
        columnwise_bbox.append(col)

    return columnwise_bbox


def draw_default_lines(table_img):
    table_img[1:3, 1:-1] = 0  # 1st column line
    table_img[-3:-1, 1:-1] = 0  # last column line
    table_img[1:-1, 1:3] = 0  # 1 row line
    table_img[1:-1, -3:-1] = 0  # last row line
    return table_img


def get_rowwise_data(extracted_columnwise_text):
    rowwise_data = []
    for col_index in range(len(extracted_columnwise_text[0])):
        col = []
        for index in range(len(extracted_columnwise_text)):
            col.append(extracted_columnwise_text[index][col_index])
        rowwise_data.append(col)

    return rowwise_data


def apply_image_filtering(table_img, enhance_img, neighborhood_pixel_diameter):
    if type(table_img) is np.ndarray:
        if enhance_img in TRUE_CHECK:
            table_img = cv2.bilateralFilter(table_img, neighborhood_pixel_diameter, 75, 75)
        table_img = Image.fromarray(table_img)

    return table_img


def get_extracted_columnwise_text(text_and_cbox_column_index, extracted_columnwise_text, cell_with_cbox_and_text):
    for col_index in text_and_cbox_column_index:
        column = extracted_columnwise_text[col_index]
        for cell_num in range(len(column)):
            text = extracted_columnwise_text[col_index][cell_num] + "||" + str(
                cell_with_cbox_and_text[cell_num])
            extracted_columnwise_text[col_index][cell_num] = text

    return extracted_columnwise_text


# This code assumes table (input table image) as gridded table
def Table_Data_Extraction(req_folder, table_img, column_split_position, col_datatype,
                          row_start_index, row_end_index, checkbox_type, enhance_img, neighborhood_pixel_diameter,
                          table_type):
    col_len = len(column_split_position)
    table_img = draw_default_lines(table_img)
    cv2.imwrite(req_folder + "/initial_" + str(random()) + ".png", table_img)
    table_img = handling_disjoint_row_lines(table_img)
    cv2.imwrite(req_folder + "/" + str(random()) + ".png", table_img)
    output = []
    BLOCK_SIZE = 25
    THRESHOLD_CONSTANT = 1
    rowwise_data = []
    columnwise_bbox = []

    cbox_columns, cbox_type, text_and_cbox_column_index = find_checkbox_column_indices(col_datatype)
    table_img = apply_image_filtering(table_img, enhance_img, neighborhood_pixel_diameter)

    tess_ocr_api = ""
    if OCR_tool == "tesserocr":
        tess_ocr_api = set_image_for_tesserocr_api(table_img)

    img_final_bin = morphing_image(table_img, BLOCK_SIZE, THRESHOLD_CONSTANT)
    cv2.imwrite(req_folder + "/cropped_images/" + str(column_split_position[0][1]) + "_" +
                str(column_split_position[0][2]) + "_bin_initial.png", img_final_bin)
    if table_type != "gridded":
        img_final_bin = draw_row_column_lines(img_final_bin, column_split_position)
    #cv2.imshow("i", img_final_bin)
    #cv2.waitKey(0)
    #cv2.destroyWindow("i")

    img_final_bin = draw_default_lines(img_final_bin)
    boundingbox_pos = get_contours(req_folder, img_final_bin, neighborhood_pixel_diameter, column_split_position)
    boundingbox_pos_filtered = get_boundingbox_pos_filtered(boundingbox_pos, column_split_position)
    if len(boundingbox_pos_filtered) > 0:
        row_wise_bbox_pos = get_rowwise_bbox(boundingbox_pos_filtered)
        row_wise_bbox_pos_filtered = row_bbox_filtered(row_wise_bbox_pos, col_len)
        bbox_height_updated = height_pos_updated(row_wise_bbox_pos_filtered)
        columnwise_bbox = get_columnwise_bbox(col_len, row_wise_bbox_pos_filtered, bbox_height_updated)
        extracted_columnwise_text = apply_columnwise_ocr(req_folder, table_img, columnwise_bbox, tess_ocr_api)

        if len(cbox_columns) > 0:
            extracted_columnwise_cbox = get_columnwise_checkbox_status(req_folder, table_img, columnwise_bbox,
                                                                       cbox_columns, cbox_type)
            for col in range(len(cbox_columns)):
                extracted_columnwise_text[cbox_columns[col]] = extracted_columnwise_cbox[col]

        if len(text_and_cbox_column_index) > 0:
            cell_with_cbox_and_text = hangling_text_and_checkbox_cell(req_folder, table_img, columnwise_bbox,
                                                                      text_and_cbox_column_index)
            extracted_columnwise_text = get_extracted_columnwise_text(text_and_cbox_column_index,
                                                                      extracted_columnwise_text,
                                                                      cell_with_cbox_and_text)

        rowwise_data = get_rowwise_data(extracted_columnwise_text)
        output = [row_data for row_data in rowwise_data if len(row_data) == col_len]

    return output, columnwise_bbox
